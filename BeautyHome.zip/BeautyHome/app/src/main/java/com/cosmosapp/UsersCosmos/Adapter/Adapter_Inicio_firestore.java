package com.cosmosapp.UsersCosmos.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.pedidos.Domicilio_data;
import com.cosmosapp.UsersCosmos.Entidades_fire.pedidos.Productos_carrito;
import com.cosmosapp.UsersCosmos.holder.Holde_inicio_servicios;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class Adapter_Inicio_firestore extends FirestoreRecyclerAdapter<Productos_carrito, Holde_inicio_servicios > {


    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public Adapter_Inicio_firestore(@NonNull FirestoreRecyclerOptions<Productos_carrito> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull final Holde_inicio_servicios holder, int position, @NonNull final Productos_carrito model) {



        holder.getCount1().setVisibility(View.GONE);
        holder.getCount2().setVisibility(View.GONE);
        holder.getCount3().setVisibility(View.GONE);

        holder.getMas1().setVisibility(View.GONE);
        holder.getMas2().setVisibility(View.GONE);
        holder.getMas3().setVisibility(View.GONE);

        holder.getMen1().setVisibility(View.GONE);
        holder.getMen2().setVisibility(View.GONE);
        holder.getMen3().setVisibility(View.GONE);
        ///////////////////////////////////////////////////

        holder.getCategoria_titulo().setText(model.getNombre());
        holder.getPreciodesde().setText(model.getPrecio());

        /////////////////////////////



        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (model.getProductolist().size()>0) {

                    if (model.getProductolist().get(0).getCodigo() != null) {

                        holder.getCount1().setVisibility(View.VISIBLE);
                        holder.getMas1().setVisibility(View.VISIBLE);
                        holder.getMen1().setVisibility(View.VISIBLE);

                        holder.getCount1().setText(model.getProductolist().get(0).getNombre());

                    }
                    if (model.getProductolist().get(1).getCodigo() != null) {

                        holder.getCount2().setVisibility(View.VISIBLE);
                        holder.getMas2().setVisibility(View.VISIBLE);
                        holder.getMen2().setVisibility(View.VISIBLE);

                        holder.getCount2().setText(model.getProductolist().get(1).getNombre());

                    }
                }


                if (model.getProductolist().size()>3){
                if (model.getProductolist().get(2).getCodigo()!=null){

                    holder.getCount3().setVisibility(View.VISIBLE);
                    holder.getMas3().setVisibility(View.VISIBLE);
                    holder.getMen3().setVisibility(View.VISIBLE);


                }}



            }
        });

    }

    @NonNull
    @Override
    public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_servicios, parent, false);

        return new Holde_inicio_servicios(view);
    }
}
