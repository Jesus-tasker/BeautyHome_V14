package com.cosmosapp.UsersCosmos.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra.Dialog_Bottonshape_fragmt;
import com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav.Inicio_pedidos;
import com.cosmosapp.UsersCosmos.holder.Holde_inicio_servicios;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class Adapter_fire_servicio extends FirestoreRecyclerAdapter<Servicio_p1, Holde_inicio_servicios > {

    String cateforia_producto;
    String nombre;
    String codigo;
    String precio;

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public Adapter_fire_servicio(@NonNull FirestoreRecyclerOptions<Servicio_p1> options) {
        super(options);
    }

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param
     */

    @Override
    protected void onBindViewHolder(@NonNull final Holde_inicio_servicios holder, int position, @NonNull final Servicio_p1 model) {

        final int precio2_int;
        if (model.getCateforia_producto()!=null) {
            cateforia_producto=model.getCateforia_producto();
        }
        if (model.getNombre()!=null) {
            nombre=model.getCateforia_producto();
        }
        if (model.getCodigo()!=null) {
            codigo=model.getCodigo();

        }
        if (model.getPrecio()!=null) {
            cateforia_producto=model.getPrecio();
        }
        if (model.getPrecio2_int()!=0) {

            precio2_int=model.getPrecio2_int();

        }else {precio2_int=0;}



        holder.getCount1().setVisibility(View.GONE);
        holder.getCount2().setVisibility(View.GONE);
        holder.getCount3().setVisibility(View.GONE);

        holder.getMas1().setVisibility(View.GONE);
        holder.getMas2().setVisibility(View.GONE);
        holder.getMas3().setVisibility(View.GONE);

        holder.getMen1().setVisibility(View.GONE);
        holder.getMen2().setVisibility(View.GONE);
        holder.getMen3().setVisibility(View.GONE);
        ///////////////////////////////////////////////////

        holder.getCategoria_titulo().setText(model.getNombre());
        holder.getPreciodesde().setText(model.getPrecio());

        /////////////////////////////



        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        //si toca inicia el primero libre
                        holder.getCount1().setVisibility(View.VISIBLE);
                        holder.getMas1().setVisibility(View.VISIBLE);
                        holder.getMen1().setVisibility(View.VISIBLE);

                        holder.getMas1().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                /*
                                Bundle bundle=new Bundle();
                                bundle.getString("categoria",model.getCateforia_producto());
                                bundle.getString("nombre",model.getNombre());
                                bundle.getString("codigo",model.getCodigo());
                                bundle.getString("precio_string",model.getPrecio());
                                bundle.getString("precio_num",model.getCateforia_producto());

                                 */

                                Inicio_pedidos f1 = new Inicio_pedidos();

                                Bundle bundle=new Bundle();
                                bundle.putString("categoria",cateforia_producto);
                                bundle.putString("nombre",nombre);
                                bundle.putString("codigo",codigo);
                                bundle.putString("precio_string",precio);
                                bundle.putInt("precio_int",precio2_int);

                                Intent intent=new Intent(view.getContext(), Dialog_Bottonshape_fragmt.class);
                                intent.putExtra("serv",bundle);

                               //Dialog_Bottonshape_fragmt dialog=new Dialog_Bottonshape_fragmt();

                               // llamardialog_shapefragmetn(view.getContext());
                                f1.setArguments(bundle);
                               // view.getContext().startActivity(intent);
                                //dialog_bottonshape_fragmt.recibe_datos(cont,totalventa);
                                // //.show(getSupportFragmentManager(),"dialog_bottonshape_fragmt");

                             //   FragmentManager fragmentManager = getSupportFragmentManager();
                               // fragmentManager.beginTransaction().replace(R.id.swipe_container, fragment).commit();







                            }
                        });



                         holder.getMen1().setOnClickListener(new View.OnClickListener() {
                             @Override
                        public void onClick(View view) {

                         }
                          });






            }
        });

    }

    @NonNull
    @Override
    public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_servicios, parent, false);

        return new Holde_inicio_servicios(view);
    }


    private void llamardialog_shapefragmetn(Context context){

        /*
        new BottomSheetDialog(this,R.style.BottomSheetstiletheme);
        View buttonview=LayoutInflater.from(context).inflate(R.layout.item_boton_flotante,
                (LinearLayout)findViewById(R.id.contenedor_butonsheep));

        Dialog_Bottonshape_fragmt dialog_bottonshape_fragmt=new Dialog_Bottonshape_fragmt();
        // Toast.makeText(CrearPromocion.this, "productos:"+cont+ "  total:"+totalventa, Toast.LENGTH_SHORT).show();

        Bundle bundle=new Bundle();
        bundle.putInt("contador",cont);
        bundle.putInt("totalventa",totalventa);
        dialog_bottonshape_fragmt.setArguments(bundle);
        //dialog_bottonshape_fragmt.recibe_datos(cont,totalventa);
        dialog_bottonshape_fragmt.show(getSupportFragmentManager(),"dialog_bottonshape_fragmt");

         */

    }
}

