package com.cosmosapp.UsersCosmos.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.pedidos.Productos_carrito;
import com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra.Dialog_Bottonshape_fragmt;
import com.cosmosapp.UsersCosmos.holder.Holde_inicio_servicios;

import java.util.List;

public class Adapterr_norml_inicio_menu extends RecyclerView.Adapter<Holde_inicio_servicios> {

    Context context;
    List<Productos_carrito> productoList;

    String cateforia_producto;
    String nombre;
    String codigo;
    String precio;

    @NonNull
    @Override
    public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_estadodomicilio, parent, false);

        return new Holde_inicio_servicios(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final Holde_inicio_servicios holder, int position) {

        final int precio2_int;
        if (productoList.get(position).getCateforia_producto() != null) {
            cateforia_producto = productoList.get(position).getCateforia_producto();
        }
        if (productoList.get(position).getNombre() != null) {
            nombre = productoList.get(position).getCateforia_producto();
        }
        if (productoList.get(position).getCodigo() != null) {
            codigo = productoList.get(position).getCodigo();

        }
        if (productoList.get(position).getPrecio() != null) {
            cateforia_producto = productoList.get(position).getPrecio();
        }
        if (productoList.get(position).getPrecio2_int() != 0) {

            precio2_int = productoList.get(position).getPrecio2_int();

        } else {
            precio2_int = 0;
        }


        holder.getCount1().setVisibility(View.GONE);
        holder.getCount2().setVisibility(View.GONE);
        holder.getCount3().setVisibility(View.GONE);

        holder.getMas1().setVisibility(View.GONE);
        holder.getMas2().setVisibility(View.GONE);
        holder.getMas3().setVisibility(View.GONE);

        holder.getMen1().setVisibility(View.GONE);
        holder.getMen2().setVisibility(View.GONE);
        holder.getMen3().setVisibility(View.GONE);
        ///////////////////////////////////////////////////

        holder.getCategoria_titulo().setText(productoList.get(position).getNombre());
        holder.getPreciodesde().setText(productoList.get(position).getPrecio());

        /////////////////////////////


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //si toca inicia el primero libre
                holder.getCount1().setVisibility(View.VISIBLE);
                holder.getMas1().setVisibility(View.VISIBLE);
                holder.getMen1().setVisibility(View.VISIBLE);

                holder.getMas1().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                                /*
                                Bundle bundle=new Bundle();
                                bundle.getString("categoria",model.getCateforia_producto());
                                bundle.getString("nombre",model.getNombre());
                                bundle.getString("codigo",model.getCodigo());
                                bundle.getString("precio_string",model.getPrecio());
                                bundle.getString("precio_num",model.getCateforia_producto());

                                 */
                        Bundle bundle = new Bundle();
                        bundle.putString("categoria", cateforia_producto);
                        bundle.putString("nombre", nombre);
                        bundle.putString("codigo", codigo);
                        bundle.putString("precio_string", precio);
                        bundle.putInt("precio_int", precio2_int);

                        Intent intent = new Intent(view.getContext(), Dialog_Bottonshape_fragmt.class);
                        intent.putExtra("serv", bundle);
                        view.getContext().startActivity(intent);
                        //Dialog_Bottonshape_fragmt dialog=new Dialog_Bottonshape_fragmt();


                    }
                });


                holder.getMen1().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });


            }

        });
    }

    @Override
    public int getItemCount() {
        return productoList.size();
    }
}
