package com.cosmosapp.UsersCosmos.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.holder.Holde_inicio_servicios;

import java.util.ArrayList;
import java.util.List;

public class Adapterr_norml_productos1 extends RecyclerView.Adapter<Holde_inicio_servicios> {

    Context context;
    List<Servicio_p1> productoList;

    List<Servicio_p1> carritoservicios=new ArrayList<>();

    public Adapterr_norml_productos1(Context context, List<Servicio_p1> productoList) {
        this.context = context;
        this.productoList = productoList;
    }

    @NonNull
    @Override
    public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_estadodomicilio, parent, false);

        return new Holde_inicio_servicios(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holde_inicio_servicios holder, int position) {


        holder.getCount1().setVisibility(View.GONE);
        holder.getCount2().setVisibility(View.GONE);
        holder.getCount3().setVisibility(View.GONE);

        holder.getMas1().setVisibility(View.GONE);
        holder.getMas2().setVisibility(View.GONE);
        holder.getMas3().setVisibility(View.GONE);

        holder.getMen1().setVisibility(View.GONE);
        holder.getMen2().setVisibility(View.GONE);
        holder.getMen3().setVisibility(View.GONE);
        ////////////
        //foto?
        if (productoList.get(position).getNombre()!=null) {
            holder.getCategoria_titulo().setText(productoList.get(position).getCateforia_producto());
            holder.getPreciodesde().setText(productoList.get(position).getPrecio());
        }
        /////////





    }

    @Override
    public int getItemCount() {
        return productoList.size();
    }
}
