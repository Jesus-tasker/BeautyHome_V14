package com.cosmosapp.UsersCosmos.Constantes;

public class Constantes {
    public static final  String URL_foto_por_defecto_usuario="https://firebasestorage.googleapis.com/v0/b/chatfino-618b0.appspot.com/o/perfilfoto.png?alt=media&token=16136dfc-78c7-478c-9066-2d26b4c63142";
    public static final String Nodo_Usuario="Usuario_clientes";
    public static final String Nodo_Usuario_clients_uso2="Usuario";
    public static  final String Nodo_chat="Chatv2";
    public static  final String Mensajes="Mensajes";
    public static  final String Myschats="Myschats";
    public static  final String Nodo_localizacion="Localizacion";
    public static  final String Nodo_Rooms="rooms";
    public static  final String Nodo_Rooms_general="Rooms_general";
    public  static  final String Factura="Facturas";


    public  static  final String Productos="Productos";
    public  static  final String Productos_venta="Productos_venta";
    public  static  final String Productos_Panaderia="Panaderia";
    public  static  final String Productos_Carnes="Carnes";
    public  static  final String Productos_Huevos="Huevos";
    public  static  final String Productos_Frutas="Frutas";
    public  static  final String Productos_Verduras="Verduras";
    public  static  final String Productos_Aseo_hogar="Aseo_hogar";
    public  static  final String Catalogo_productos="Catalogo_productos";

    public static String Promociones="PRomosciones";
    public static String Reservaciones="REservaciones";
    public static String Reservaciones_usuario="Reservas_user";
    public static String token="Tokens";

    public static String Titulo="titulo";
    public  static  String Detalle="detalle";
    public static String tiponotificaion="tiponotificaion";
    public static String usersreportados="Reportados";
    public static String Reserva_completa="Reserva_completa";
    public static String nube_key="AAAAAKpXN3M:APA91bFvAomaYwfJIlhjAdcEm193c36Rh3zQTcnoilIu_6quCS9Ump8hTeMEKxG_fqJX9NMaM67zowaRmvx0jdgBZadb8mcrzU_FPmuA2TPF8Sk0a_dm1tRQimDNvsfprNDvPTZcjcmK";


    //servicios peluqeuria
    public  static String servicio1_Peluqueria_hombre="Peluqueria Barberia";
    public  static String servicio1_Peluqueria_Dama="Peluqueria Dama";
    public  static String servicio1_Unas="Solo Uñas";
    public  static String servicio1_Color_hombre="Color capilar hombre";
    public  static String servicio1_Color_mujer="Color capilar Mujer";
    public  static String servicio1_Masajes_reductivos="Masajes Reductivos";

    public static String Servicios_completados ="Complete_admin";
    public static String servicios_cancelados="Cancelados_Amin";



    public  static  String terminosycondicion="TERMINOS DE USO\n" +
            "Creación el 17/09/2020\n" +
            "\u200B\n" +
            "\n" +
            " Bienvenido o a Beauty and home somos una app nueva con el fin de ayudarte a obtener los mejores servicios en estetica y belleza para tu hogar especificamente en santiago de chile  , operado por Jesus Montoya Vera de Colombia,desarrollada para ejercer  en Santiago de chile  como una app en proceso de innovación y en comunicación tprototipoipo delivery para belleza  \"beauty and home v10\", apta solo para mayores de 18 años .\n" +
            "\n" +
            "\n" +
            "Aviso: Beauty and Homees una aplicación desarrollada en Android hasta la fecha por lo cual los usuarios podrán crear su cuenta y desvincularla a voluntad .\n" +
            "\n" +
            "Reembolsos por nuestra pagina oficial\n" +
            "\n" +
            "Htttp//Mipaginaoficial.com/crealaputapagina.es\n" +
            "contactanos al correo :\n" +
            "\n" +
            "\n" +
            "\n" +
            "Inscripciones realizadas por playstore podrán ponerse en contacto también de forma directa con la información de los proveedores.\n" +
            "\n" +
            "Aceptación de los Términos de uso.\n" +
            "\n" +
            "Al crear una cuenta de Beauty and home  a través de un dispositivo móvil Android ,estas de acuerdo en obligarte por (I)estos términos de uso,(II) politicas de privacidad y consejos de seguridad, todos estos términos se incorporan por referencia en este acuerdo,(iii)cualquier termino que describa si compras o has adquirido funciones productos o servidios adidionales que sean ofrecidos.\n" +
            "\n" +
            "Beauty and home  en este momento varia con esta versión inicial la cual es la fase de prueba ,la versión que aplicamos 1.0.\n" +
            "\n" +
            "Beauty and Home  notificara a los ususarios cuando sea necesario una actualización para  mostrarte la versión mas reciente y funcional asi como cambios en términos de uso y condición ,aquí incluiremos un acuerdo en el cual como usuario aceptas nuestras condiciones y políticas de uso .\n" +
            "\n" +
            "2.Elegibilidad\n" +
            "\n" +
            "El requisito mínimo para usar Beauty and Home es ser mayor de 18 años ,para crear tu cuenta y utilizar nuestros servicios . al crear una cuenta y usar nuestros servicios declaras y garantizas que:\n" +
            "\n" +
            "Puedes formar un contrato vinculante , siempre y cuando seas mayor de 18 años.\n" +
            "\n" +
            "No eres una persona que tiene prohibido el usar el servicio de acuerdo a  las leyes de Colombia y Chile o cualquier otra jurisdicción aplicable; lo que significa que no apareces en la lista de ciudadanos  con restricciones legales buscados o reportados por la entidad de justicia  del país donde se use nuestro servicio.\n" +
            "\n" +
            "Vas a cumplir con este Acuerdo y todas las leyes asociadas  locales,estatales ,nacionales e internacionales .\n" +
            "\n" +
            "Nunca has sido condenado o no disputante un delito grave, un delito sexual, o cualquier delito que implique violencia , ya que no estas obligado a registrarte como delincuente sexual en ningún estado ,registro federal  o local de delincuentes sexuales.\n" +
            "\n" +
            "\n" +
            "\n" +
            "3. Tu Cuenta.\n" +
            "\n" +
            "Para utilizar Beauty and Home ,puedes iniciar cesión con Facebook. Si lo haces nos autorizas a acceder y usar cierta información de cuenta de Facebook, pero no ilimitada a tu perfil publico de Facebook y la otra información sobre  amigos de Facebook que tienes en común con otros usuarios de nuestra red(.\n" +
            "\n" +
            "Para obtener mas información que obtenemos de ti y como la utilizamos , políticas de privacidad ubicadas en esta pagina web.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Eres responsable de mantener el control de tus datos y mantener la discreccion y confidencialidad para inicio de sesión ,y eres el único responsable por todas las actividades que ocurran bajo esas credenciales. si crees que alguien ha tenido acceso a tu cuenta ponte en contacto este será eliminado una vez verifiquemos tu identidad puedes contactar al correo.\n" +
            "\n" +
            "atencionalclienteYesroom@gmail.com\n" +
            "denunciaanonimaYesroom@gmail.com\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "4. Beauty home profesionnals y beauty home admin.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Beauty and home comparte informacion con sus apps hermanas beauty profesionals el cual es el encargado de recepcionar la informacion del domicilio y este permite a nuestros profesionales saber la ubicación especifica del servicio,asi mismo beauty admin es una app administrativa donde evaluamos al profesional mas adecuado para asignarlo a cada usuario especifico.\n" +
            "\n" +
            "Estas comparten informacion impoetante y entre las 3 crean el sistema completo beauty and home la vual es la responsable del control de usuaruos\n" +
            "\n" +
            "\n" +
            "\n" +
            "5.Servicio y Terminacion.\n" +
            "\n" +
            "Beauty and Home  esta en desarrollo por lo cual siempre tomaremos medidas como cambiar elementos , actualizar eliminar y agregar funciones según se vea un proyecto positivo para nuestros usuarios ,así como eliminar características que no afecten materialmente sus derechos .podemos suspender su servicio en su totalidad,y reportar si es requerido por la comunidad de usuarios.\n" +
            "\n" +
            "Puedes cancelar tu cuenta en cuanto lo desee el usuario,por el motivo que desee,siguiendo las instrucciones “micuenta” en tu pantalla principal.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Como usuario das autoridad a Beauty and Home  para eliminar tu cuenta ,sin previo aviso si se te considera que has violado nuestro acuerdo. Tras dichas terminación , no tendaras deerechoa  reembolsos por las compras.Despues de que canele tu cuenta, el acuerdo terminara , en caso de reembolso puedes contactarte a nuestros correo  con el titulo solicitud de reembolso.\n" +
            "\n" +
            "Entre ellas solicitar y cancelar servicios.\n" +
            "\n" +
            "Utilizar nuestra app von fines malignos.\n" +
            "\n" +
            "atencionalclienteYesroom@gmail.com//especificar REEMBOLSO en asunto\n" +
            "denunciaanonimaYesroom@gmail.com\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "6. Seguridad :Tus interacciones dentro de la apps.\n" +
            "\n" +
            "Beauty and Home consideta que en la nueva era digital debemos confiar en el cliente , para ello este podra tener hasta un maximo de 1 servicio solicitado desde su celular con nuestra empresa.\n" +
            "\n" +
            "\n" +
            "\n" +
            "El usuario acepta nuestras políticas de uso dentro de nuestros servicio.\n" +
            "\n" +
            "El usuatio debe presentsr siempre que se le solicite informacion teal sobre su domicilio y datos personales para realizar correctamente la reservacion y atencion qje merece.\n" +
            "\n" +
            "El usario se compromete a integrar informacion verdadera y exacta de la ubicación del domivilio.\n" +
            "\n" +
            "El usuario acepta no realizar pedidos o cancelarlos con tiempo pues estos deben ser dedarrollados con tiempo y calidad,\n" +
            "\n" +
            "  como debe tener presente  consejos de consejos de pagos electronicos  de  ta,bien te comprometes a no proporcionar tu información financiera (ej: tarjeta de crédito,debito o cuenta bancaria) o transferir dinero a otros estilistas fuera del servivio\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "EL USUARIO ES EL UNICO RESPONSABLE DE SU INTERACCION CON LOS PROFESIONALES   ASI COMO SU COMPORTAMIENTO DENTRO DE LOS LUGARES DE RESERVA Y RELAJACION “” EL USURIO TENDRA SUS NORMAS DE POLITICAS ESPECIALIZADAS PARA Beauty and Home users\n" +
            "\n" +
            "\n" +
            "\n" +
            "EL USUARIO ENTIENDE QUE Beauty and Home  NO VERIFICA ANTECEDENTES PERSONALES DE SUS USUARIOS NI INVESTIGA OTRO MODO LOS ANTECEDENTES DE SUS USUARIOS.\n" +
            "\n" +
            "Beauty  NO GARANTIZA LA CONDUCTA DE SUS USUARIOS PERO NO PERMITE EL IRRESPETO hacia sus trabajadores como profesional a los clientes.\n" +
            "\n" +
            "\n" +
            "\n" +
            "NO ESTAMOS DISPUESTOS NI TENEMOS LA AUTORIZACION PARA REALIZAR BUSQUEDAS EN NUESTROS USUARIOS, EL USUARIO ACEPTA QUE B3AUTY AND HOME PUEDA REALIZAR VERIFICACIONES DE ANTECEDENTES PENALES Y OTROS CRIBADOS COMO BUSQUEDAS EN LOS REGISTROS DE CRIMINALES SECILOS EN CUALQUIER MOMENTO USANDO LOS REGISTROS PUBLICOS DISPONIBLES ESTE PROCESO PUEDE SER LLEVADO ACABO EN CASO QUE UN USUARIO RECIBA MULTIPLES ALERTAS AL INCUMPLIR NUESTRAS NORMAS O PUEDA SER CATALOGADO COMO PELIGROSO POR LA MISMA COMUNIDAD.\n" +
            "\n" +
            "\n" +
            "\n" +
            "7.Derechos que “Beauty and Home user ” otorga.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Beauty and Home te da una cuenta única intrasnferible e irrevocable en nuestro servicio, no transferible a terceros para acceder a nuestro servicios.\n" +
            "\n" +
            "Permite al usuario disfrutar de los beneficios del servicio previstos por  Beauty and Home por el presente acuerdo  el usuario cumple las siguientes funciones:\n" +
            "\n" +
            "No utilizar nuestros servicios con fines comerciales sin el consentimiento por escrito de nuestra app.!!\n" +
            "\n" +
            "No expresar ni insinuar que cualquiera de tus declaraciones están evaladas por Beauty and Home.\n" +
            "\n" +
            "No utilizar ningún roboto ,bot ,o robot de búsqueda ,raspador,aplicación de búsqueda de sitios o recuperación,prozi u otro dispositivo manual o automatico método o proceso que acceda o recupere datos  en cualquier forma de ,repordicion o sorteal la estrictira de navegación o presentar el servicio o su contenido.\n" +
            "\n" +
            "no utilizar el servicio de ninguna manera que pudiera interferir con, interrumpir o afectar negativamente el Servicio o los servidores o redes conectados al Servicio.\n" +
            "\n" +
            "no subir virus u otro código malicioso ni poner en peligro la seguridad del Servicio.\n" +
            "\n" +
            "no falsificar encabezados ni manipular identificadores para disfrazar el origen de cualquier información transmitida a través del Servicio.\n" +
            "\n" +
            "no hacer “marcos” ni “espejos” de cualquier parte del Servicio, sin previa autorización por escrito de Beauty and Home.\n" +
            "\n" +
            "no modificar, adaptar, sublicenciar, traducir, vender, realizar ingeniería inversa, descifrar, descompilar o desensamblar cualquier parte del Servicio, o provocar que otros lo hagan.\n" +
            "\n" +
            "no utilizar o desarrollar cualquier aplicación de terceros que interactúe con el Servicio o Contenido o información de otros usuarios sin nuestro consentimiento por escrito.\n" +
            "\n" +
            "no utilizar, acceder ni publicar la interfaz de programación de la aplicación de Beauty and Home  sin nuestro consentimiento por escrito.\n" +
            "\n" +
            "no sondear, escanear ni probar la vulnerabilidad de nuestro Servicio o de cualquier sistema o red.\n" +
            "\n" +
            "no fomentar ni promover cualquier actividad que viole este Acuerdo.\n" +
            "\n" +
            "La Compañía puede investigar y tomar las acciones legales disponibles en respuesta al uso ilegal y/o no autorizado del Servicio, incluida la terminación de tu cuenta.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Llamar servicioa y cancelarlos propósitos.\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "8.Derechos que otorga Beauty and Home.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Beauty and Home te da una cuenta única intrasnferible e irrevocable en nuestro servicio, no transferible a terceros para acceder a nuestro servicios.\n" +
            "\n" +
            "  Esl usuario es libre de regalías, tiene el derecho, almacenar, utilizar, copiar, mostrar, reproducir, adaptar, modificar, publicar, modificar y distribuir información que nos autorices para acceder a Facebook, así como cualquier información que publiques, subas, muestres o pongas a disposición (colectivamente, “publicar”) en el Servicio o transmitas a otros usuarios (colectivamente, “Contenido”)\n" +
            "\n" +
            "\n" +
            "\n" +
            "Aceptas que toda la información que envíes al crear tu cuenta, incluida la información presentada de tu cuenta de Facebook, es exacta y veraz y que tienes el derecho de publicar el Contenido en el Servicio y conceder la licencia anterior.\n" +
            "\n" +
            "\n" +
            "\n" +
            "El usuario acepta  que nosotros, nuestras filiales y nuestros socios de terceros Beauty and Home con respecto a nuestro Servicio, aceptas que Beauty and Home  puede utilizar y compartir dicha retroalimentación para cualquier propósito sin compensarte por ello.\n" +
            "\n" +
            "El usuario acepta que Beauty and Home puede acceder, conservar y revelar la información de tu cuenta y el Contenido si así debe hacerlo por ley o si de buena fe considera que dicho acceso, reserva o revelación es razonablemente necesaria, tales como: (i) cumplir con procesos legales ; (ii) hacer cumplir este Acuerdo; (iii) responder a reclamos de que algún Contenido viola los derechos de terceros; (iv) responder a tus solicitudes de atención al cliente; o (v) proteger los derechos, propiedad o seguridad personal de la Compañía o de cualquier otra persona.\n" +
            "\n" +
            "Reglas de la comunidad.\n" +
            "\n" +
            "\n" +
            "Al utilizar el Servicio, aceptas que no podrás:\n" +
            "\n" +
            "utilizar el Servicio para ningún propósito que sea ilegal o prohibido por el presente Acuerdo.\n" +
            "\n" +
            "utilizar el Servicio con fines perjudiciales o nefastos.\n" +
            "\n" +
            "utilizar el Servicio con el fin de dañar el servicio.\n" +
            "\n" +
            "enviar correo no deseado, solicitar dinero o defraudar a cualquier repeesenrrante de Beauty and Home.\n" +
            "\n" +
            "hacerte pasar por otra persona o entidad o publicar cualquier imagen de otra persona sin su permiso.\n" +
            "\n" +
            "intimidar, “asediar”, intimidar, agredir, acosar, maltratar o difamar a cualquier persona.\n" +
            "\n" +
            "publicar cualquier Contenido que viole o infrinja los derechos de cualquier persona, incluidos los derechos de publicidad, privacidad, derechos de autor, marca registrada u otra propiedad intelectual o derecho de contrato.\n" +
            "\n" +
            "publicar cualquier Contenido que sea discurso de odio, amenazante, sexualmente explícito o pornográfico; que incite a la violencia; o que contenga desnudos o violencia gráfica o injustificada.\n" +
            "\n" +
            "publicar ningún Contenido que promueva el racismo, la intolerancia, el odio o el daño físico de cualquier tipo contra cualquier grupo o individuo.\n" +
            "\n" +
            "solicitar contraseñas para cualquier propósito, o información de identificación personal para fines comerciales o ilegales de otros usuarios o difundir la información personal de otra persona sin su permiso.\n" +
            "\n" +
            "usar la cuenta de otro usuario.\n" +
            "\n" +
            "crear otra cuenta si ya hemos terminado tu cuenta, a menos que tengas nuestro permiso.\n" +
            "\n" +
            "Violar este acuerdo puede causar en el bloqueo eliminación de tu cuenta\n" +
            "\n" +
            "\n" +
            "\n" +
            "Contenido de otros Usuarios.\n" +
            "\n" +
            "Como ya tiene establecido el usuario, este es libre de publicar información de su relevancia dentro de su perfil, con la certeza que el contenido es netamente responsabilidad del usuario que lo publica y Beauty and Home no garantiza si cumples con los estándares .\n" +
            "\n" +
            "\n" +
            "\n" +
            "En caso que contenga contenido de carácter violento, venta de animales, drogas , pedofilia, acosadores sexuales. enviar un correo anonimato a el siguiente correo\n" +
            "\n" +
            "atencionalclienteYesroom@gmail.com\n" +
            "\n" +
            "denunciaanonimaYesroom@gmail.com    //especificar Tipo en asunto\n" +
            "               \n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "Compras\n" +
            "\n" +
            "Actualmente Beauty and Homeno  posee un canal de compras verificado ya que esta en via de desarrollo.\n" +
            "\n" +
            "En e futuro se espera integrar mercado pago.\n" +
            "\n" +
            "Aviso y procedimiento para reclamaciones de infracciones de derechos de autor.\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "Renuncias.\n" +
            "\n" +
            "BEAUTY  AND HOME PROPORCIONA EL SERVICIO “TAL CUAL” Y “SEGÚN DISPONIBILIDAD” Y EN LA MEDIDA PERMITIDA POR LA LEY APLICABLE, NO OTORGA NINGUNA GARANTÍA DE NINGÚN TIPO, EXPLÍCITA, IMPLÍCITA, ESTATUTARIA U OTRA CON RESPECTO AL SERVICIO (INCLUIDO TODO EL CONTENIDO INCLUIDO EN EL MISMO), INCLUIDA, SIN LIMITACIÓN, CUALQUIER GARANTÍA IMPLÍCITA DE CALIDAD SATISFACTORIA, COMERCIABILIDAD, APTITUD PARA UN PROPÓSITO PARTICULAR O NO INFRACCIÓN. BEAUTY AND HOME NO DECLARA NI GARANTIZA QUE (A) EL SERVICIO SERÁ ININTERRUMPIDO.\n" +
            "\n" +
            "BEAUTY NO ACEPTARA INFRACCIONES HACIA NUESTRO PERSONAL ASI COMO  MAL USO DE LA APP DONDE PUEDA HACER RESERVACIONES Y ESTAS NUNCA SE REALICEN  CANVELANDOLAS VON TIEMPO.\n" +
            "\n" +
            "BEAUTY NO SE RESPONSABILIZA POR LA FORMA DE ACTUAR DE LOS USUARIOS NI DENTRO COMO FUERA DE LA APP ,SOLICITAMOS RESPETO AL PERSONAL.\n" +
            "\n" +
            "\n" +
            "\n" +
            "BEAUTY AND HOME Y NO SE RESPONSABILIZA POR NINGUNA CONDUCTA TUYA O DE OTRO USUARIO, DENTRO O FUERA DEL SERVICIO.\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "\n" +
            "Limitación de responsabilidad.\n" +
            "\n" +
            "BEAUTY AND HOME resp9ndera por los servicios desarrollafos que no sean satisfactorios para el clienye en donde puede establecwrce desde un acuerdo, reembolso o garantia por los servicios.\n" +
            "\n" +
            "BEAUTY AND HOME beauty home podra cancelar servicios de ver necesario que estos puedan representar un peligro para nuestros profesionales.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Arbitraje retroactivo y potencial, renuncia de acción de clase y renuncia de juicio ante jurado.\n" +
            "\n" +
            "cualquier controversia o reclamo que surjan de o estén relacionados con el presente Acuerdo (incluida cualquier supuesta violación de los mismos) o el Servicio, independientemente de la fecha de surgimiento e incluidos todos los reclamos pasados, pendientes y futuros, serán el ARBITRAJE VINCULANTE \n" +
            "\n" +
            " La única excepción a la exclusividad del arbitraje es que tienes el derecho de presentar una reclamación individual contra BEAUTY AND HOME ante un tribunal para demandas de menor cuantía de la jurisdicción competente en tu país de residencia.\n" +
            "\n" +
            "En el tribunal para demandas de menor cuantía, aceptas que bajo ninguna circunstancia iniciarás, mantendrás o participarás en ninguna acción de clase, arbitraje de clase u otra acción representativa o procedimiento contra BEAUTY AND HOME.\n" +
            "\n" +
            "Al aceptar este Acuerdo, AMBOS TÚ Y BEAUTY AND HOME RENUNCIAN AL DERECHO DE IR A JUICIO para hacer valer o defender cualquier demanda entre tú y BEAUTY AND HOME (a excepción de los asuntos que puedan ser debidamente llevados a un tribunal para demandas de menor cuantía y están dentro de la jurisdicción de dicho tribunal). TAMBIÉN RENUNCIAS A TU DERECHO A PARTICIPAR EN UNA ACCIÓN DE CLASE U OTRO PROCEDIMIENTO DE CLASE, incluido, sin limitación, cualquier acción de clase pasada, pendiente o futura, incluidas las existentes a la fecha de este Acuerdo.\n" +
            "\n" +
            "\n" +
            "\n" +
            "Si impones una reclamación contra BEAUTY AND HOME por fuera de un tribunal para demandas de menor cuantía, tus derechos serán determinados por un ÁRBITRO NEUTRAL, NO UN JUEZ NI JURADO, y el árbitro determinará todas las reclamaciones y todas las cuestiones relativas a la arbitrabilidad de la controversia. Lo mismo es cierto para BEAUTY AND HOME Tanto tú como BEAUTY AND HOME tienen derecho a una audiencia justa ante el árbitro. El árbitro generalmente puede conceder la misma solución que un tribunal, pero debes tener en cuenta que los procedimientos de arbitraje son generalmente más simples y más ágiles que los juicios y otros procedimientos judiciales. Las decisiones del árbitro son ejecutables en los tribunales y pueden ser revocadas por un tribunal sólo por razones muy limitadas. Para más detalles sobre el proceso de arbitraje, consulta nuestros Procedimientos de arbitraje.\n" +
            "\n" +
            "Al decidir si aceptas este Acuerdo de arbitraje, estas son algunas consideraciones importantes:\n" +
            "\n" +
            "El arbitraje se considera generalmente como un proceso de resolución de controversias más rápido que el sistema judicial, pero eso no es siempre el caso. El Árbitro normalmente determinará si BEAUTY AND HOME o tú tendrán que pagar o dividir el costo de cualquier arbitraje con BEAUTY AND HOME, en función de las circunstancias que se presenten.\n" +
            "\n" +
            "El arbitraje es un proceso de resolución de controversias privada que no implica la vía civil, un juez civil o un jurado. En cambio, la controversia entre las partes se decide por un árbitro privado elegido por las partes en virtud del Reglamento de Arbitraje de Consumo de la Asociación Americana de Arbitraje. El arbitraje no limita ni afecta las demandas legales que tú como individuo puedes presentar contra BEAUTY AND HOME. La aceptación del arbitraje sólo afectará donde dichas demandas puedan ser llevadas y la forma en que serán resueltas.\n" +
            "\n" +
            " IMPORTANTE PODRÍA HABER EN EL FUTURO, JUICIOS LEGALES CONTRA BEAUTY AND HOME QUE ALEGASEN DEMANDAS DE CLASE Y/O REPRESENTATIVAS EN TU NOMBRE, INCLUIDAS PERO SIN LIMITACIÓN, LAS ACCIONES DE CLASE DESCRITAS EN ESTA SECCIÓN 16, QUE EN CASO DE SER EXITOSAS, PODRÍAN RESULTAR POTENCIALMENTE EN CIERTA RECUPERACIÓN MONETARIA O DE OTRO TIPO PARA TI, SI ELIGES LA EXCLUSIÓN VOLUNTARIA DE LA APLICACIÓN RETROACTIVA DE ESTE ACUERDO DE ARBITRAJE. LA MERA EXISTENCIA DE DICHOS JUICIOS DE CLASE Y/O REPRESENTATIVOS, NO OBSTANTE, NO SIGNIFICA QUE DICHOS JUICIOS TENGAN FINALMENTE ÉXITO, O QUE, INCLUSO SI TUVIERAN ÉXITO, QUE TÚ TUVIERAS DERECHO A CUALQUIER RECUPERACIÓN.\n" +
            "\n" +
            "\n" +
            "\n" +
            "ACEPTAR ESTE ACUERDO DE ARBITRAJE ES UNA DECISIÓN IMPORTANTE. LA DECISIÓN DEBES TOMARLA TÚ Y DEBERÁS TENER CUIDADO DE INVESTIGAR MÁS A FONDO Y CONSULTAR CON OTRAS PERSONAS —INCLUIDO, SIN LIMITACIÓN, UN ABOGADO— LO RELACIONADO CON LAS CONSECUENCIAS DE TU DECISIÓN, IGUAL QUE HARÍAS AL TOMAR CUALQUIER OTRA DECISIÓN COMERCIAL O VITAL.\n" +
            "\n" +
            "Legislación aplicable.\n" +
            "\n" +
            "Excepto donde nuestro acuerdo de arbitraje esté prohibido por la ley,\n" +
            "\n" +
            "cuenta su conflicto de leyes, se aplicarán a cualquier controversia que surja de o relacionada con este Acuerdo, el Servicio, o tu relación con . BEAUTY AND HOME No obstante lo anterior, el Acuerdo de arbitraje de la Sección 16 anterior se regirá por la Ley Federal de Arbitraje\n" +
            "\n" +
            "Lugar de encuentro.\n" +
            "\n" +
            "El usuario y BEAUTY AND HOME se comprometen a cualquier reclamación de que dichos tribunales constituyan un foro inconveniente.\n" +
            "\n" +
            "Indemnización por tu parte.\n" +
            "\n" +
            "El usuario se  compromete, en la medida permitida por la ley aplicable, a indemnizar, defender y mantener indemne a BEAUTY AND HOME, nuestras filiales, y sus y nuestros respectivos funcionarios, directores, agentes y empleados de y contra cualquiera y todas las reclamaciones, demandas, reclamos, daños, pérdidas, costos, responsabilidades y gastos, incluidos los honorarios de abogados, debido a, que surjan de, o se relacionen de alguna manera con tu acceso o uso del Servicio, tu Contenido, o tu incumplimiento de este Acuerdo.\n" +
            "\n" +
            "\n" +
            "\n" +
            "ACUERDO COMPLETO0\n" +
            "\n" +
            "Este Acuerdo, junto con la Política de privacidad, los Consejos de seguridad y cualquiera de los términos descritos a ti si compras o has comprado funciones, productos o servicios adicionales que ofrezcamos en el Servicio, contienen el acuerdo completo entre tú BEAUTY AND HOME   con respecto a tu relación con BEAUTY AND HOME y el uso del Servicio\n" +
            "excepción: nadie que se haya dado de baja de la aplicación retroactiva de la Sección 16 sigue sujeto a u obligado por cualesquiera acuerdos previos de arbitraje con BEAUTY AND HOME así como este acuerdo de arbitraje de ahora en adelante. Si alguna disposición de este Acuerdo es considerada inválida, el resto de este Acuerdo continuará en pleno vigor y efecto. Si BEAUTY AND HOME no ejerce o no hace valer cualquier derecho o disposición de este Acuerdo, no constituirá una renuncia a tal derecho o disposición. Aceptas que tu cuenta de BEAUTY AND HOME Y no es transferible y todos tus derechos a tu cuenta y a su Contenido terminan después de tu fallecimiento. Ninguna agencia, asociación, compañía conjunta, fiduciaria u otra relación de carácter especial o laboral se crea como resultado de este Acuerdo y no puedes hacer ninguna declaración en nombre de u obligar a BEAUTY AND HOME   de ninguna manera";
}
