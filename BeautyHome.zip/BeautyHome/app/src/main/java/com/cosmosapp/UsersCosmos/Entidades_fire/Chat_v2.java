package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Chat_v2 {

    private  String sender;
    private  String recibido;
    private  String mensaje;


    public Chat_v2() {
    }
    public Chat_v2(String sender, String recibido, String mensaje) {
        this.sender = sender;
        this.recibido = recibido;
        this.mensaje = mensaje;
    }




    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getRecibido() {
        return recibido;
    }

    public void setRecibido(String recibido) {
        this.recibido = recibido;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
