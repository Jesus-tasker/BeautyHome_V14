package com.cosmosapp.UsersCosmos.Entidades_fire.Entidades_logicas;


import com.cosmosapp.UsersCosmos.Entidades_fire.MensajeChat;
import com.cosmosapp.UsersCosmos.Entidades_fire.Mnsaje_final;

public class Lmen_final {
    private String key;
    public Mnsaje_final mnfinal; //
    public MensajeChat mensajeChat;
    private LUsuario lUsuario;

    public Lmen_final() {
    }

    public Lmen_final(String key, Mnsaje_final model) {
        this.key = key;
        this.mnfinal = mnfinal;
    }


    public Lmen_final(String key, Mnsaje_final mnfinal, LUsuario lUsuario) {
        this.key = key;
        this.mnfinal = mnfinal;
        this.lUsuario = lUsuario;
    }

    public MensajeChat getMensajeChat() {
        return mensajeChat;
    }

    public void setMensajeChat(MensajeChat mensajeChat) {
        this.mensajeChat = mensajeChat;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Mnsaje_final getMnfinal() {
        return mnfinal;
    }

    public void setMnfinal(Mnsaje_final mnfinal) {
        this.mnfinal = mnfinal;
    }

    public LUsuario getlUsuario() {
        return lUsuario;
    }

    public void setlUsuario(LUsuario lUsuario) {
        this.lUsuario = lUsuario;
    }
}
