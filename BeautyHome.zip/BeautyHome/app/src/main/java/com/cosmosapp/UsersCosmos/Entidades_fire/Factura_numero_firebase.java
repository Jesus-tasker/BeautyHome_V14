package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Factura_numero_firebase {
    int factura;
    int cantidad_servicio;

    public Factura_numero_firebase() {
    }

    public int getFactura() {
        return factura;
    }

    public void setFactura(int factura) {
        this.factura = factura;
    }

    public int getCantidad_servicio() {
        return cantidad_servicio;
    }

    public void setCantidad_servicio(int cantidad_servicio) {
        this.cantidad_servicio = cantidad_servicio;
    }
}
