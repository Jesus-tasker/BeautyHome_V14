package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Map_location {

    private double latitud;
    private double longitud;

    public Map_location() {
    }

    public Map_location(double latitud, double longitud) {
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public double getLatitud() {
        return latitud;
    }

    public void setLatitud(double latitud) {
        this.latitud = latitud;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }
}
