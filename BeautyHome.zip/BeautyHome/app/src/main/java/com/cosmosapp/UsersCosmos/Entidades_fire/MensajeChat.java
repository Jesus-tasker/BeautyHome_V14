package com.cosmosapp.UsersCosmos.Entidades_fire;

import com.google.firebase.database.ServerValue;

public class MensajeChat {

    private String mensaje; //en este caso el Mensaje recibira el url del Mensaje
    private  String urlfoto;
    private  boolean contienefoto;
    private String keyemior;
    private Object createTimestamp;//objeto tipo tiempo



    public MensajeChat() {
        createTimestamp= ServerValue.TIMESTAMP; //cuando se envio el Mensaje firebase

    }


    public MensajeChat(String mensaje, String urlfoto, boolean contienefoto, String keyemior, Object createTimestamp) {
        this.mensaje = mensaje;
        this.createTimestamp= ServerValue.TIMESTAMP; //cuando se envio el Mensaje firebase
        this.urlfoto = urlfoto;
        this.contienefoto = contienefoto;
        this.keyemior = keyemior;
        this.createTimestamp = createTimestamp;
    }


    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getUrlfoto() {
        return urlfoto;
    }

    public void setUrlfoto(String urlfoto) {
        this.urlfoto = urlfoto;
    }

    public boolean isContienefoto() {
        return contienefoto;
    }

    public void setContienefoto(boolean contienefoto) {
        this.contienefoto = contienefoto;
    }

    public String getKeyemior() {
        return keyemior;
    }

    public void setKeyemior(String keyemior) {
        this.keyemior = keyemior;
    }

    public Object getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Object createTimestamp) {
        this.createTimestamp = createTimestamp;
    }
}
