package com.cosmosapp.UsersCosmos.Entidades_fire;

import com.google.firebase.database.ServerValue;

public class Mnsaje_final  {

    private String mensaje;
    private Long fechadenaciniento;
    private  Object create_time_tamp;
    private Object createTimestamp;//objeto tipo tiempo

    private String fotodePerfilURI_emisor;
    private  String fotodePerfilURI_receptor;

    private   String usuario_emisor;
    private  String usuario_Receptor;

    private  String key_usuario_emisor;
    private  String key_usuario_receptor;


    public Mnsaje_final() {
        createTimestamp= ServerValue.TIMESTAMP; //cuando se envio el Mensaje firebase

    }

    public String getFotodePerfilURI_emisor() {
        return fotodePerfilURI_emisor;
    }

    public void setFotodePerfilURI_emisor(String fotodePerfilURI_emisor) {
        this.fotodePerfilURI_emisor = fotodePerfilURI_emisor;
    }

    public String getFotodePerfilURI_receptor() {
        return fotodePerfilURI_receptor;
    }

    public void setFotodePerfilURI_receptor(String fotodePerfilURI_receptor) {
        this.fotodePerfilURI_receptor = fotodePerfilURI_receptor;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Long getFechadenaciniento() {
        return fechadenaciniento;
    }

    public void setFechadenaciniento(Long fechadenaciniento) {
        this.fechadenaciniento = fechadenaciniento;
    }

    public Object getCreate_time_tamp() {
        return create_time_tamp;
    }

    public void setCreate_time_tamp(Object create_time_tamp) {
        this.create_time_tamp = create_time_tamp;
    }

    public Object getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Object createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getUsuario_emisor() {
        return usuario_emisor;
    }

    public void setUsuario_emisor(String usuario_emisor) {
        this.usuario_emisor = usuario_emisor;
    }

    public String getUsuario_Receptor() {
        return usuario_Receptor;
    }

    public void setUsuario_Receptor(String usuario_Receptor) {
        this.usuario_Receptor = usuario_Receptor;
    }

    public String getKey_usuario_emisor() {
        return key_usuario_emisor;
    }

    public void setKey_usuario_emisor(String key_usuario_emisor) {
        this.key_usuario_emisor = key_usuario_emisor;
    }

    public String getKey_usuario_receptor() {
        return key_usuario_receptor;
    }

    public void setKey_usuario_receptor(String key_usuario_receptor) {
        this.key_usuario_receptor = key_usuario_receptor;
    }
}


