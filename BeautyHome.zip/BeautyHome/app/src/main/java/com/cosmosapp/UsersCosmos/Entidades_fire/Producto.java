package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Producto {

    String cateforia_producto;
    String nombre;
    String Codigo;
    String precio;
    int precio2_int;
    String unidad;
    String specialidad_producto;
    String key;
    String fotoproducto;
    Object timestamp;
    String timestamp_strin;
    String fecha_string;



    public Producto() {
    }




    public Object getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Object timestamp) {
        this.timestamp = timestamp;
    }

    public String getTimestamp_strin() {
        return timestamp_strin;
    }

    public void setTimestamp_strin(String timestamp_strin) {
        this.timestamp_strin = timestamp_strin;
    }

    public String getFecha_string() {
        return fecha_string;
    }

    public void setFecha_string(String fecha_string) {
        this.fecha_string = fecha_string;
    }

    public Producto(String cateforia_producto, String nombre, String specialidad_producto, String codigo) {
        this.cateforia_producto = cateforia_producto;
        this.nombre = nombre;
        this.Codigo = codigo;
        this.specialidad_producto = specialidad_producto;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCateforia_producto() {
        return cateforia_producto;
    }

    public void setCateforia_producto(String cateforia_producto) {
        this.cateforia_producto = cateforia_producto;
    }

    public int getPrecio2_int() {
        return precio2_int;
    }

    public void setPrecio2_int(int precio2_int) {
        this.precio2_int = precio2_int;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getSpecialidad_producto() {
        return specialidad_producto;
    }

    public void setSpecialidad_producto(String specialidad_producto) {
        this.specialidad_producto = specialidad_producto;
    }

    public String getFotoproducto() {
        return fotoproducto;
    }

    public void setFotoproducto(String fotoproducto) {
        this.fotoproducto = fotoproducto;
    }
}
