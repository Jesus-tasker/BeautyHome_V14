package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Productos_selected_v1 {

    String foto;
    String nombre;
    int posicion;
    int foto_guardada;

    public Productos_selected_v1() {
    }

    public Productos_selected_v1(String nombre, int posicion) {
        this.nombre = nombre;
        this.posicion = posicion;
    }


// Checkout the project associated with this tutorial on Github if
// you want to use the same images.

}
