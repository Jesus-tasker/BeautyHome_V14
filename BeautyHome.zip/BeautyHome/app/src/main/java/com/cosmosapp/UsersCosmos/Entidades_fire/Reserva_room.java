package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Reserva_room {

    String nombre_room;
    String nombre_usu;
    String key_duenoroom;
    String key_Usucliente;
    String telefono_cliente;
    String tel_room;
    String fecha_reserva;
    String hora_reserva;
    String fecha_dia;
    String total_pagar;
    String correo_usu;
    String correo_room;
    int nuemro_deventa;
    Double latitud_room;
    Double longitud_room;

    public Reserva_room() {
    }

    public String getNombre_room() {
        return nombre_room;
    }


    public void setNombre_room(String nombre_room) {
        this.nombre_room = nombre_room;
    }

    public String getNombre_usu() {
        return nombre_usu;
    }

    public void setNombre_usu(String nombre_usu) {
        this.nombre_usu = nombre_usu;
    }

    public String getKey_duenoroom() {
        return key_duenoroom;
    }

    public void setKey_duenoroom(String key_duenoroom) {
        this.key_duenoroom = key_duenoroom;
    }

    public String getKey_Usucliente() {
        return key_Usucliente;
    }

    public void setKey_Usucliente(String key_Usucliente) {
        this.key_Usucliente = key_Usucliente;
    }

    public String getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(String telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public String getTel_room() {
        return tel_room;
    }

    public void setTel_room(String tel_room) {
        this.tel_room = tel_room;
    }

    public String getFecha_reserva() {
        return fecha_reserva;
    }

    public void setFecha_reserva(String fecha_reserva) {
        this.fecha_reserva = fecha_reserva;
    }

    public String getHora_reserva() {
        return hora_reserva;
    }

    public void setHora_reserva(String hora_reserva) {
        this.hora_reserva = hora_reserva;
    }

    public String getFecha_dia() {
        return fecha_dia;
    }

    public void setFecha_dia(String fecha_dia) {
        this.fecha_dia = fecha_dia;
    }

    public String getTotal_pagar() {
        return total_pagar;
    }

    public void setTotal_pagar(String total_pagar) {
        this.total_pagar = total_pagar;
    }

    public String getCorreo_usu() {
        return correo_usu;
    }

    public void setCorreo_usu(String correo_usu) {
        this.correo_usu = correo_usu;
    }

    public String getCorreo_room() {
        return correo_room;
    }

    public void setCorreo_room(String correo_room) {
        this.correo_room = correo_room;
    }

    public int getNuemro_deventa() {
        return nuemro_deventa;
    }

    public void setNuemro_deventa(int nuemro_deventa) {
        this.nuemro_deventa = nuemro_deventa;
    }

    public Double getLatitud_room() {
        return latitud_room;
    }

    public void setLatitud_room(Double latitud_room) {
        this.latitud_room = latitud_room;
    }

    public Double getLongitud_room() {
        return longitud_room;
    }

    public void setLongitud_room(Double longitud_room) {
        this.longitud_room = longitud_room;
    }
}
