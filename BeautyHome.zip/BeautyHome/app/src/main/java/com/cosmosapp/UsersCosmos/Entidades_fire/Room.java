package com.cosmosapp.UsersCosmos.Entidades_fire;

import java.util.List;

public class Room {

    private String keyemisor;
    private String nombre;
    private String  direccion;
    private String  telefono;
    private String precio;
    private String duracion_room;
    private Double longitud;
    private Double latitud;
    private List<String> list_uri_string;
    private  String foto;
    private Boolean wifi;
    private Boolean parquing;
    private  int Calificacion;
    private  String correo;



    public Room() {
    }

    public int getCalificacion() {
        return Calificacion;
    }

    public void setCalificacion(int calificacion) {
        Calificacion = calificacion;
    }

    public Boolean getWifi() {
        return wifi;
    }

    public void setWifi(Boolean wifi) {
        this.wifi = wifi;
    }

    public Boolean getParquing() {
        return parquing;
    }

    public void setParquing(Boolean parquing) {
        this.parquing = parquing;
    }

    public String getKeyemisor() {
        return keyemisor;
    }

    public void setKeyemisor(String keyemisor) {
        this.keyemisor = keyemisor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getDuracion_room() {
        return duracion_room;
    }

    public void setDuracion_room(String duracion_room) {
        this.duracion_room = duracion_room;
    }

    public Double getLongitud() {
        return longitud;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public List<String> getList_uri_string() {
        return list_uri_string;
    }

    public void setList_uri_string(List<String> list_uri_string) {
        this.list_uri_string = list_uri_string;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
