package com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu;

import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;

import java.util.List;

public class REserva_cosmos_v2 {
   Usuario usuario;
    List<Servicio_p1> listservices;

    public REserva_cosmos_v2() {
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Servicio_p1> getListservices() {
        return listservices;
    }

    public void setListservices(List<Servicio_p1> listservices) {
        this.listservices = listservices;
    }
}
