package com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu;

public class Reserva_completada {
    String timestamp;
    Reserva_cosmos reserva_cosmos;
    Users_On users_on_enturno;
    Boolean servicio_terminado;

    public Reserva_completada() {
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public Reserva_cosmos getReserva_cosmos() {
        return reserva_cosmos;
    }

    public void setReserva_cosmos(Reserva_cosmos reserva_cosmos) {
        this.reserva_cosmos = reserva_cosmos;
    }

    public Users_On getUsers_on_enturno() {
        return users_on_enturno;
    }

    public void setUsers_on_enturno(Users_On users_on_enturno) {
        this.users_on_enturno = users_on_enturno;
    }

    public Boolean getServicio_terminado() {
        return servicio_terminado;
    }

    public void setServicio_terminado(Boolean servicio_terminado) {
        this.servicio_terminado = servicio_terminado;
    }
}
