package com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu;

import java.util.List;

public class Reserva_cosmos {
    String timestamp;
    String key_busqueda;
    String key_uid;
    String notifiuid_cliente;
    String fotografia;
    String nombre_cliente;
    String direccion;
    String total_string;
    String telefono;
    String fecha_reservacion;
    String fecha_servicios;
    String hora_servicios;
    int total_int;
    double latitud_cliente;
    double longitud_cliente;
    List<Servicio_p1>listservices;


    public Reserva_cosmos() {
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getKey_busqueda() {
        return key_busqueda;
    }

    public void setKey_busqueda(String key_busqueda) {
        this.key_busqueda = key_busqueda;
    }

    public String getKey_uid() {
        return key_uid;
    }

    public void setKey_uid(String key_uid) {
        this.key_uid = key_uid;
    }

    public String getNotifiuid_cliente() {
        return notifiuid_cliente;
    }

    public void setNotifiuid_cliente(String notifiuid_cliente) {
        this.notifiuid_cliente = notifiuid_cliente;
    }

    public String getFotografia() {
        return fotografia;
    }

    public void setFotografia(String fotografia) {
        this.fotografia = fotografia;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTotal_string() {
        return total_string;
    }

    public void setTotal_string(String total_string) {
        this.total_string = total_string;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFecha_reservacion() {
        return fecha_reservacion;
    }

    public void setFecha_reservacion(String fecha_reservacion) {
        this.fecha_reservacion = fecha_reservacion;
    }

    public String getFecha_servicios() {
        return fecha_servicios;
    }

    public void setFecha_servicios(String fecha_servicios) {
        this.fecha_servicios = fecha_servicios;
    }

    public String getHora_servicios() {
        return hora_servicios;
    }

    public void setHora_servicios(String hora_servicios) {
        this.hora_servicios = hora_servicios;
    }

    public int getTotal_int() {
        return total_int;
    }

    public void setTotal_int(int total_int) {
        this.total_int = total_int;
    }

    public double getLatitud_cliente() {
        return latitud_cliente;
    }

    public void setLatitud_cliente(double latitud_cliente) {
        this.latitud_cliente = latitud_cliente;
    }

    public double getLongitud_cliente() {
        return longitud_cliente;
    }

    public void setLongitud_cliente(double longitud_cliente) {
        this.longitud_cliente = longitud_cliente;
    }

    public List<Servicio_p1> getListservices() {
        return listservices;
    }

    public void setListservices(List<Servicio_p1> listservices) {
        this.listservices = listservices;
    }
}
