package com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu;

import android.os.Parcel;
import android.os.Parcelable;
public class Servicio_p1 implements Parcelable {
    String cateforia_producto;
    String nombre;
    String Codigo;
    String precio;
    int precio2_int;
    String timestamp_string;
    String foto_string;

    public Servicio_p1() {
    }



    public Servicio_p1(String time_string, String cateforia_producto, String nombre, String codigo, String precio, int precio2_int) {
        this.cateforia_producto = cateforia_producto;
        this.nombre = nombre;
        Codigo = codigo;
        this.precio = precio;
        this.precio2_int = precio2_int;
    }
 public String getFoto_string() {
            return foto_string;
        }

        public void setFoto_string(String foto_string) {
            this.foto_string = foto_string;
        }

        public String getCateforia_producto() {
            return cateforia_producto;
        }

        public void setCateforia_producto(String cateforia_producto) {
            this.cateforia_producto = cateforia_producto;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public String getCodigo() {
            return Codigo;
        }

        public void setCodigo(String codigo) {
            Codigo = codigo;
        }

        public String getPrecio() {
            return precio;
        }

        public void setPrecio(String precio) {
            this.precio = precio;
        }

        public int getPrecio2_int() {
            return precio2_int;
        }

        public void setPrecio2_int(int precio2_int) {
            this.precio2_int = precio2_int;
        }

        public void setTimestamp_string(String timestamp_string) {
            this.timestamp_string = timestamp_string;
        }

        public String getTimestamp_string() {
            return timestamp_string;
        }





    protected Servicio_p1(Parcel in) {
        cateforia_producto = in.readString();
        nombre = in.readString();
        Codigo = in.readString();
        precio = in.readString();
        precio2_int = in.readInt();
        timestamp_string = in.readString();
        foto_string = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cateforia_producto);
        dest.writeString(nombre);
        dest.writeString(Codigo);
        dest.writeString(precio);
        dest.writeInt(precio2_int);
        dest.writeString(timestamp_string);
        dest.writeString(foto_string);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Servicio_p1> CREATOR = new Parcelable.Creator<Servicio_p1>() {
        @Override
        public Servicio_p1 createFromParcel(Parcel in) {
            return new Servicio_p1(in);
        }

        @Override
        public Servicio_p1[] newArray(int size) {
            return new Servicio_p1[size];
        }
    };
}