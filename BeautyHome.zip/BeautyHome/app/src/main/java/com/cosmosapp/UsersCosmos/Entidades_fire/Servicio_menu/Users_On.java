package com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu;

public class Users_On {
    String timestamp;
    String key_hash;
    String key_uid;
    String notifiuid_profesional;
    String fotografia;
    String nombre_profesional;
    String especialidad;
    String telefono;
    String fecha_insertada;
    public Users_On() {
    }

    public Users_On(String timestamp, String key_hash, String key_uid, String notifiuid_profesional, String fotografia, String nombre_profesional, String especialidad, String telefono, String fecha_insertada) {
        this.timestamp = timestamp;
        this.key_hash = key_hash;
        this.key_uid = key_uid;
        this.notifiuid_profesional = notifiuid_profesional;
        this.fotografia = fotografia;
        this.nombre_profesional = nombre_profesional;
        this.especialidad = especialidad;
        this.telefono = telefono;
        this.fecha_insertada = fecha_insertada;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getKey_hash() {
        return key_hash;
    }

    public void setKey_hash(String key_hash) {
        this.key_hash = key_hash;
    }

    public String getKey_uid() {
        return key_uid;
    }

    public void setKey_uid(String key_uid) {
        this.key_uid = key_uid;
    }

    public String getNotifiuid_profesional() {
        return notifiuid_profesional;
    }

    public void setNotifiuid_profesional(String notifiuid_profesional) {
        this.notifiuid_profesional = notifiuid_profesional;
    }

    public String getFotografia() {
        return fotografia;
    }

    public void setFotografia(String fotografia) {
        this.fotografia = fotografia;
    }

    public String getNombre_profesional() {
        return nombre_profesional;
    }

    public void setNombre_profesional(String nombre_profesional) {
        this.nombre_profesional = nombre_profesional;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFecha_insertada() {
        return fecha_insertada;
    }

    public void setFecha_insertada(String fecha_insertada) {
        this.fecha_insertada = fecha_insertada;
    }
}
