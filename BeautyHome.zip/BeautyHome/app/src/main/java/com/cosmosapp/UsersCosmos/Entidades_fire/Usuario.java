package com.cosmosapp.UsersCosmos.Entidades_fire;

public class Usuario {

    private String fotodePerfilURI;
    private String usuario_nombre;
    private String correo_usuario;
    private Long fechaDeNacimiento;
    private String genero;
    private String busco_genero;
    private String profesion;
    private String habilidad_profesional;
    private String teleono_usuario;
    private Object create_time_tamp;
    private String key_usuario;
    private String key_busqueda;
    private Boolean estadochat;
    private String notifi_uid;
    private Boolean wifi;
    private Boolean parqueadero;
    private  int calificaion;
    private String fechaextra;

    private String correoroom;
    private String precio_desde;
    private Boolean vip;
    private String cargo;





   private Double latidu;
    private Double longitud;




    public Usuario() {



    }

    public String getFechaextra() {
        return fechaextra;
    }

    public void setFechaextra(String fechaextra) {
        this.fechaextra = fechaextra;
    }

    public String getKey_usuario() {
        return key_usuario;
    }

    public void setKey_usuario(String key_usuario) {
        this.key_usuario = key_usuario;
    }

    public String getFotodePerfilURI() {
        return fotodePerfilURI;
    }

    public void setFotodePerfilURI(String fotodePerfilURI) {
        this.fotodePerfilURI = fotodePerfilURI;
    }

    public Boolean getEstadochat() {
        return estadochat;
    }

    public void setEstadochat(Boolean estadochat) {
        this.estadochat = estadochat;
    }

    public String getUsuario_nombre() {
        return usuario_nombre;
    }

    public void setUsuario_nombre(String usuario_nombre) {
        this.usuario_nombre = usuario_nombre;
    }

    public String getProfesion() {
        return profesion;
    }

    public String getHabilidad_profesional() {
        return habilidad_profesional;
    }

    public void setHabilidad_profesional(String habilidad_profesional) {
        this.habilidad_profesional = habilidad_profesional;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getTeleono_usuario() {
        return teleono_usuario;
    }

    public void setTeleono_usuario(String teleono_usuario) {
        this.teleono_usuario = teleono_usuario;
    }

    public String getCorreo_usuario() {
        return correo_usuario;
    }

    public void setCorreo_usuario(String correo_usuario) {
        this.correo_usuario = correo_usuario;
    }


    public Long getFechaDeNacimiento() {
        return fechaDeNacimiento;
    }

    public void setFechaDeNacimiento(Long fechaDeNacimiento) {
        this.fechaDeNacimiento = fechaDeNacimiento;
    }
    public Usuario(String correo_usuario, String usuario_nombre) {
        this.correo_usuario = correo_usuario;
        this.usuario_nombre = usuario_nombre;

    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Object getCreate_time_tamp() {
        return create_time_tamp;
    }

    public void setCreate_time_tamp(Object create_time_tamp) {
        this.create_time_tamp = create_time_tamp;
    }

    public String getKey_busqueda() {
        return key_busqueda;
    }

    public Double getLatidu() {
        return latidu;
    }

    public void setLatidu(Double latidu) {
        this.latidu = latidu;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public String getKey_busqueda(String hash) {
        return key_busqueda;
    }

    public void setKey_busqueda(String key_busqueda) {
        this.key_busqueda = key_busqueda;
    }

    public String getNotifi_uid() {
        return notifi_uid;
    }

    public void setNotifi_uid(String notifi_uid) {
        this.notifi_uid = notifi_uid;
    }

    public Boolean getWifi() {
        return wifi;
    }

    public void setWifi(Boolean wifi) {
        this.wifi = wifi;
    }

    public Boolean getParqueadero() {
        return parqueadero;
    }

    public void setParqueadero(Boolean parqueadero) {
        this.parqueadero = parqueadero;
    }

    public int getCalificaion() {
        return calificaion;
    }

    public void setCalificaion(int calificaion) {
        this.calificaion = calificaion;
    }

    public String getCorreoroom() {
        return correoroom;
    }

    public void setCorreoroom(String correoroom) {
        this.correoroom = correoroom;
    }

    public String getPrecio_desde() {
        return precio_desde;
    }

    public void setPrecio_desde(String precio_desde) {
        this.precio_desde = precio_desde;
    }

    public Boolean getVip() {
        return vip;
    }

    public void setVip(Boolean vip) {
        this.vip = vip;
    }

    public String getBusco_genero() {
        return busco_genero;
    }

    public void setBusco_genero(String busco_genero) {
        this.busco_genero = busco_genero;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
}
