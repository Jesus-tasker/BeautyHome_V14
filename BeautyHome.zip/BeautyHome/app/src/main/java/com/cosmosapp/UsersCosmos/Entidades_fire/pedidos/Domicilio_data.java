package com.cosmosapp.UsersCosmos.Entidades_fire.pedidos;


import com.cosmosapp.UsersCosmos.Entidades_fire.Producto;
import com.google.firebase.database.ServerValue;

import java.util.List;

public class Domicilio_data {

    String nombre_room;
    String nombre_usu;
    String key_duenoroom;
    String key_Usucliente;
    String telefono_cliente;
    String tel_room;
    String fecha_reserva;
    String hora_reserva;
    String fecha_dia;
    String total_pagar;
    String correo_usu;
    String correo_room;
    String codigo_venta;
    int nuemro_deventa;

    Double latitud_room;
    Double longitud_room;
    Double latitud_user;
    Double longitud_user;
    String key_busqueda_cliente;
    String key_busqueda_room;
    String notifi_cliente;
    String notifi_room;

    String direccion_usuario;
    String direccion_room;
    String fotousuario;


    List<Productos_carrito> productoList;
    Producto producto;
    private Object createTimestamp;//objeto tipo tiempo


    public Domicilio_data() {
        createTimestamp= ServerValue.TIMESTAMP; //cuando se envio el Mensaje firebase
    }

    public String getNombre_room() {
        return nombre_room;
    }


    public void setNombre_room(String nombre_room) {
        this.nombre_room = nombre_room;
    }

    public String getNombre_usu() {
        return nombre_usu;
    }

    public void setNombre_usu(String nombre_usu) {
        this.nombre_usu = nombre_usu;
    }

    public String getKey_duenoroom() {
        return key_duenoroom;
    }

    public void setKey_duenoroom(String key_duenoroom) {
        this.key_duenoroom = key_duenoroom;
    }

    public String getKey_Usucliente() {
        return key_Usucliente;
    }

    public void setKey_Usucliente(String key_Usucliente) {
        this.key_Usucliente = key_Usucliente;
    }

    public String getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(String telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public String getTel_room() {
        return tel_room;
    }

    public void setTel_room(String tel_room) {
        this.tel_room = tel_room;
    }

    public String getFecha_reserva() {
        return fecha_reserva;
    }

    public void setFecha_reserva(String fecha_reserva) {
        this.fecha_reserva = fecha_reserva;
    }

    public String getHora_reserva() {
        return hora_reserva;
    }

    public void setHora_reserva(String hora_reserva) {
        this.hora_reserva = hora_reserva;
    }

    public String getFecha_dia() {
        return fecha_dia;
    }

    public void setFecha_dia(String fecha_dia) {
        this.fecha_dia = fecha_dia;
    }

    public String getTotal_pagar() {
        return total_pagar;
    }

    public void setTotal_pagar(String total_pagar) {
        this.total_pagar = total_pagar;
    }

    public String getCorreo_usu() {
        return correo_usu;
    }

    public void setCorreo_usu(String correo_usu) {
        this.correo_usu = correo_usu;
    }

    public String getCorreo_room() {
        return correo_room;
    }

    public void setCorreo_room(String correo_room) {
        this.correo_room = correo_room;
    }

    public int getNuemro_deventa() {
        return nuemro_deventa;
    }

    public void setNuemro_deventa(int nuemro_deventa) {
        this.nuemro_deventa = nuemro_deventa;
    }

    public Double getLatitud_room() {
        return latitud_room;
    }

    public void setLatitud_room(Double latitud_room) {
        this.latitud_room = latitud_room;
    }

    public Double getLongitud_room() {
        return longitud_room;
    }

    public void setLongitud_room(Double longitud_room) {
        this.longitud_room = longitud_room;
    }

    public List<Productos_carrito> getProductoList() {
        return productoList;
    }

    public void setProductoList(List<Productos_carrito> productoList) {
        this.productoList = productoList;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getCodigo_venta() {
        return codigo_venta;
    }

    public void setCodigo_venta(String codigo_venta) {
        this.codigo_venta = codigo_venta;
    }

    public Double getLatitud_user() {
        return latitud_user;
    }

    public void setLatitud_user(Double latitud_user) {
        this.latitud_user = latitud_user;
    }

    public Double getLongitud_user() {
        return longitud_user;
    }

    public void setLongitud_user(Double longitud_user) {
        this.longitud_user = longitud_user;
    }

    public String getKey_busqueda_cliente() {
        return key_busqueda_cliente;
    }

    public void setKey_busqueda_cliente(String key_busqueda_cliente) {
        this.key_busqueda_cliente = key_busqueda_cliente;
    }

    public String getKey_busqueda_room() {
        return key_busqueda_room;
    }

    public void setKey_busqueda_room(String key_busqueda_room) {
        this.key_busqueda_room = key_busqueda_room;
    }

    public String getDireccion_usuario() {
        return direccion_usuario;
    }

    public void setDireccion_usuario(String direccion_usuario) {
        this.direccion_usuario = direccion_usuario;
    }

    public String getDireccion_room() {
        return direccion_room;
    }

    public void setDireccion_room(String direccion_room) {
        this.direccion_room = direccion_room;
    }

    public Object getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Object createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getNotifi_cliente() {
        return notifi_cliente;
    }

    public void setNotifi_cliente(String notifi_cliente) {
        this.notifi_cliente = notifi_cliente;
    }

    public String getNotifi_room() {
        return notifi_room;
    }

    public void setNotifi_room(String notifi_room) {
        this.notifi_room = notifi_room;
    }

    public String getFotousuario() {
        return fotousuario;
    }

    public void setFotousuario(String fotousuario) {
        this.fotousuario = fotousuario;
    }
}
