package com.cosmosapp.UsersCosmos.Entidades_fire.pedidos;

import android.os.Parcel;
import android.os.Parcelable;

import com.cosmosapp.UsersCosmos.Entidades_fire.Producto;

import java.util.ArrayList;
import java.util.List;


public class Productos_carrito implements Parcelable {
    String cateforia_producto;
    String nombre;
    String Codigo;
    String precio;
    int precio2_int;
    String unidad;
    String specialidad_producto;
    String foto_products_crrito;
    List<Producto> productolist;




    public Productos_carrito() {
      //  productolist = new ArrayList<Producto>();
    }

    public String getCateforia_producto() {
        return cateforia_producto;
    }

    public void setCateforia_producto(String cateforia_producto) {
        this.cateforia_producto = cateforia_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public int getPrecio2_int() {
        return precio2_int;
    }

    public void setPrecio2_int(int precio2_int) {
        this.precio2_int = precio2_int;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getSpecialidad_producto() {
        return specialidad_producto;
    }

    public void setSpecialidad_producto(String specialidad_producto) {
        this.specialidad_producto = specialidad_producto;
    }

    public String getFoto_products_crrito() {
        return foto_products_crrito;
    }

    public void setFoto_products_crrito(String foto_products_crrito) {
        this.foto_products_crrito = foto_products_crrito;
    }

    public List<Producto> getProductolist() {
        return productolist;
    }

    public void setProductolist(List<Producto> productolist) {
        this.productolist = productolist;
    }

    public static Creator<Productos_carrito> getCREATOR() {
        return CREATOR;
    }

    public void Productos_carrito(Parcel in) {
        productolist = new ArrayList<Producto>();
        readFromParcel(in);

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(cateforia_producto);
        parcel.writeString(nombre);
        parcel.writeString(Codigo);
        parcel.writeString(precio);
        parcel.writeInt(precio2_int);
        parcel.writeString(foto_products_crrito);
        parcel.writeList(productolist);
       // parcel.writeTypedList(productolist);


    }
    private void readFromParcel(Parcel in) {
        cateforia_producto = in.readString();
        nombre = in.readString();
        Codigo = in.readString();
        precio= in.readString();
        precio2_int = in.readInt();
        foto_products_crrito =in.readString();
       // productolist=in.readParcelableList();
       // in.readTypedList(productolist, CREATOR2);
    }
    /*
    public static final Parcelable.Creator<Producto> CREATOR2 = new Parcelable.Creator<Producto>() {


        @Override
        public Producto createFromParcel(Parcel in) {
            return new Producto(in);
        }

        @Override
        public Producto[] newArray(int i) {
            return new Producto[i];
        }
    };

     */
    public static final Creator<Productos_carrito> CREATOR = new Creator<Productos_carrito>() {


        @Override
        public Productos_carrito createFromParcel(Parcel parcel) {
            return new Productos_carrito(parcel);
        }

        @Override
        public Productos_carrito[] newArray(int i) {
            return new Productos_carrito[i];
        }
    };

    public Productos_carrito(Parcel in){
        readFromParcel(in);
    }


}
