package com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;
import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.Navegador.MAps.Ubicacion_Perfil_User;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.holder.Usuarios_cercanos_holder;

import java.util.List;

import static android.view.View.GONE;

public class Adapter_normal_lista_productos extends RecyclerView.Adapter<Usuarios_cercanos_holder> {

    Context context;
    List<Servicio_p1> productoList;

    public Adapter_normal_lista_productos(Context context, List<Servicio_p1> productoList) {
        this.context = context;
        this.productoList = productoList;
    }

    @NonNull
    @Override
    public Usuarios_cercanos_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usuarios_cercanos_info, parent, false);
        return  new Usuarios_cercanos_holder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull Usuarios_cercanos_holder holder, int position) {




        holder.getBtn_mensajeria().setVisibility(GONE);

//        holder.getTelefono().setVisibility(GONE);

        holder.getNombre_cliente_item().setText(productoList.get(position).getNombre());
        holder.getTelefono().setText(productoList.get(position).getPrecio());
        if (productoList.get(position).getFoto_string()!=null){

            Glide.with(holder.itemView.getContext()).load(productoList.get(position).getFoto_string()).into(holder.getFoto_perfil_item_usuario());
        }

        holder.getBtn_corazon().setVisibility(GONE);
    holder.getBtn_setings().setVisibility(GONE);



    }

    @Override
    public int getItemCount() {
        return productoList.size();
    }
}
