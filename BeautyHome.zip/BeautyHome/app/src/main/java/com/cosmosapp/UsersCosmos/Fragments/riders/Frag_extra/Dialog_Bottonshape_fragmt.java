package com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.List;

public class Dialog_Bottonshape_fragmt extends BottomSheetDialogFragment {
    TextView cantidad_tv;
    TextView total;
    TextView lista;

    List<Servicio_p1>servicioP1List=new ArrayList<>();
    int totalint;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.item_boton_flotante, container, false);



        cantidad_tv=(TextView)view.findViewById(R.id.conteo_productos);
        lista=(TextView)view.findViewById(R.id.listatextocomrpas);
        total=(TextView)view.findViewById(R.id.text_total_suma);
        Bundle bundle=getArguments();


        String cateforia_producto=bundle.getString("categoria");
        String nombre=bundle.getString("nombre");;
        String codigo=bundle.getString("codigo");;
        String precio=bundle.getString("precio_string");
        int precio_bund=bundle.getInt("precio_int");

        totalint=+precio_bund;

      //  Servicio_p1 servicio_p1=new Servicio_p1(timestamp(),cateforia_producto,nombre,codigo,precio,precio_bund);

      //  int contador=bundle.getInt("contador");
       // int totalint=bundle.getInt("totalventa");
      //  Toast.makeText(getContext(), "p:"+contador+ "  total:"+totalint, Toast.LENGTH_SHORT).show();

       // cantidad_tv.setText(contador);
        //total.setText(totalint);

        int contador=servicioP1List.size();
          recibe_datos(contador,totalint);



        return  view;
    }
    public String timestamp(){

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        return ts;
    }
    public  void recibe_datos (int conteo,int mercadototal){
        String s= String.valueOf(conteo);
        String n= String.valueOf(mercadototal);

        cantidad_tv.setText(s);
        total.setText(n);

    }

    }
