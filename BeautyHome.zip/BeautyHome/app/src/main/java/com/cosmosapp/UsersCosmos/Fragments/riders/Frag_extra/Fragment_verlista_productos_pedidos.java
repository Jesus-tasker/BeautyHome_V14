package com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.cosmosapp.R;


public class Fragment_verlista_productos_pedidos extends DialogFragment {

    RecyclerView recyclerView;
   // Adapter_normal_lista_rooms_cercanos adapter_normal_lista_rooms_cercanos;
   // List<Room> list_room;





    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_verlista_productos_pedidos, container, false);
        recyclerView=(RecyclerView)view.findViewById(R.id.rv_listaproductos);


      //  adapter_normal_lista_rooms_cercanos=new Adapter_normal_lista_rooms_cercanos(getContext(),list_room);
      //  adapter_normal_lista_productos=new Adapter_normal_lista_productos(getContext(),productoList);
      //  recyclerView.setAdapter(adapter_normal_lista_rooms_cercanos);
        this.getDialog().setTitle("Dialogo lista");

        return  view;

    }
}