package com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.cosmosapp.UsersCosmos.Navegador.MAps.Maps_desechabe_Carrito_confirmar;
import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Map_location;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Reserva_cosmos;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;
import com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra.Adapter_normal_lista_productos;
import com.cosmosapp.UsersCosmos.Navegador.GeoHash;
import com.cosmosapp.UsersCosmos.holder.Holde_inicio_servicios;
import com.cosmosapp.UsersCosmos.holder.Usuarios_cercanos_holder;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static android.view.View.GONE;
import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;
import static com.google.firebase.database.FirebaseDatabase.*;

public class Fragment_carrito extends Fragment {

//dialog factura
    TextView room_tvw;
    TextView toys_tv;




    ImageView factura;


    RecyclerView recyclerView;
    private FirestoreRecyclerAdapter<Servicio_p1,Holde_inicio_servicios> adapter;
    private FirestoreRecyclerOptions options;

    String cateforia_producto_carrito;
    String nombre_carrito;
    String codigo_carrito;
    String precio_carrito;
    int precio_int_carrito;



    List<Servicio_p1>list_servicios=new ArrayList<>();

    //locacion en firebase en tiempo real
    private FusedLocationProviderClient fusedLocationProviderClient;
    DatabaseReference reference_localizacion;

    private String vp1, Vp2, vp3;


    //estas son para enviar
    double latitud;
    double longitud;
    int MY_PERMISSIONS_REQUEST_READ_CONTACTS; //int para permisos de localizacion

    private long update_interval = 10 * 1000;   // 100 segundos
    private long FASTEST_INTERVAL = 2000;   //2 segundos

    private LocationRequest mLocationRequest;
    String fotorecuperada;
    String hash_traido;




    ////
//domicilio/reservacion

    Usuario usuario_domicilio;
    private String nombre_uso_de_firebase, telefono_firebase, descripcion_firebase;
    String notifiuid_cliente;
    String nombre_cliente;

    int total_int=0;
    double latitud_cliente_fire;
    double longitud_cliente_fire;
    List<Servicio_p1>listservices;

    String buscarenelcarrito; //variable usada para la seleccion y retorno del valor seleccionado
    String seleccion; //tambien necesario apr ala logica
    TextView categorias_servicio;

//    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_carrito, container, false);
        room_tvw=(TextView)view.findViewById(R.id.room_tv);
        toys_tv=(TextView)view.findViewById(R.id.toys_tvw);
         categorias_servicio=(TextView)view.findViewById(R.id.categorias_servicios_t);

        recyclerView=(RecyclerView)view.findViewById(R.id.servicios_rv);
        factura=(ImageView)view.findViewById(R.id.ver_fac);
        list_servicios.clear();

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener((Activity) getContext(),
                new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                String newToken = instanceIdResult.getToken();
                notifiuid_cliente = newToken;
                //  Toast.makeText(Perfil_Usuario.this, "notifi"+notifiuid, Toast.LENGTH_LONG).show();
                //Log.e("newToken",newToken);
                //funciona
            }
        });
        reference_localizacion = getInstance().getReference().child(Constantes.Nodo_localizacion);

        fusedLocationProviderClient = getFusedLocationProviderClient(getContext());
        cargarinfo_usu();
        startLocationUpdates(); //location
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
        String mylatitud = prefs.getString("latitud_string", "defaultStringIfNothingFound");
        String mylongitude = prefs.getString("longitud_string", "defaultStringIfNothingFound");

        final double latitude_1 = Double.longBitsToDouble(prefs.getLong("Latitude_1", 0));
        double longitude_1 = Double.longBitsToDouble(prefs.getLong("longitude_1", 0));

        String hashbund = prefs.getString("geohash", "no se escribio");
        hash_traido = hashbund;




        categorias_servicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder_categorias = new AlertDialog.Builder(view.getContext());

                // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();

                LayoutInflater inflater=LayoutInflater.from(view.getContext());//inflador de vista
                View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null); //la vista inflada

                builder_categorias.setView(dialogView);




               // categorias_servicio.dismiss(); //no funciona



               //.setLayout(600, 400); //Controlling width and height.
              //  dialogView.setla
               // dialogView.getWindow().setLayout(600, 400);

                RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                TextView texto_dialo=(TextView)dialogView.findViewById(R.id.numero_productoslista);
                EditText editText_nota=(EditText)dialogView.findViewById(R.id.notacliente);
                TextView mostrartotal=(TextView)dialogView.findViewById(R.id.mostrartotal_fac);
                TextView completar_reserva=(TextView)dialogView.findViewById(R.id.completarreserva);
                final EditText   fecha_cita_reserva=(EditText)dialogView. findViewById(R.id.fecha_cita_reserva);
                final EditText hora=(EditText) dialogView.findViewById(R.id.hora_reservacion);
                editText_nota.setVisibility(View.GONE);
                fecha_cita_reserva.setVisibility(View.GONE);
                hora.setVisibility(View.GONE);
                mostrartotal.setVisibility(View.GONE);
                completar_reserva.setVisibility(View.GONE);

                texto_dialo.setText("Servicios");
                List<Servicio_p1> lis_catalagos=new ArrayList<>();
                    /*
                // Servicio_p1(String time_string, String cateforia_producto, String nombre, String codigo, String precio, int precio2_int) {
                //
                //servicios peluqeuria

                public  static String servicio1_Peluqueria_hombre="Peluqueria Barberia";
                public  static String servicio1_Peluqueria_Dama="Peluqueria Dama";
                public  static String servicio1_Unas="Solo Uñas";
                public  static String servicio1_Color_hombre="Color capilar hombre";
                public  static String servicio1_Color_mujer="Color capilar Mujer";
                public  static String servicio1_Masajes_reductivos="Color capilar hombre";
                //alteramos este codigo para usarlo  aveneficio y que muestre la seeccion busqueda del usuario

                 */
                //usar el int como solo un dato para imagenes
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Peluqueria_Dama,"100","100",R.mipmap.ic_serv1_peluqeuria_dama));
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Peluqueria_hombre,"100","100",R.mipmap.ic_serv2_barber_peluqeuriahoombre));
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Color_hombre,"100","100",R.mipmap.ic_serv_barbercolor_v2));
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Color_mujer,"100","100",R.mipmap.ic_serv_4_color_dama_4));
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Unas,"100","100",R.mipmap.ic_serv_5_unas));
                lis_catalagos.add(new Servicio_p1(timestamp(),"Peluqueria",Constantes.servicio1_Masajes_reductivos,"100","100",R.mipmap.ic_serv_6_masajes_reductivos));

                RecyclerView.Adapter<Usuarios_cercanos_holder> adapter_solo_seleccionar =new RecyclerView.Adapter<Usuarios_cercanos_holder>() {
                    @NonNull
                    @Override
                    public Usuarios_cercanos_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view= LayoutInflater.from(dialogView.getContext()).inflate(R.layout.item_usuarios_cercanos_info, parent, false);
                        return  new Usuarios_cercanos_holder(view);
                    }

                    @Override
                    public void onBindViewHolder(@NonNull Usuarios_cercanos_holder holder, int position) {

                        holder.getBtn_mensajeria().setVisibility(GONE);

                        holder.getTelefono().setVisibility(GONE);
                        holder.getBtn_corazon().setVisibility(GONE);
                        holder.getBtn_setings().setVisibility(GONE);


                        if (lis_catalagos.get(position).getPrecio2_int()!=0){
                            //guaarde el int 2 la foto
                            Glide.with(dialogView.getContext()).load(lis_catalagos.get(position).getPrecio2_int()).into(holder.getFoto_perfil_item_usuario());

                        }


                        holder.getNombre_cliente_item().setText(lis_catalagos.get(position).getNombre());

                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                buscarenelcarrito=lis_catalagos.get(position).getNombre().trim();
                                categorias_servicio.setText(buscarenelcarrito);


                                     cargar_adapter(buscarenelcarrito); //funciona pero quiero provar algo

                                //cargar_adarpter_v2_conlista(buscarenelcarrito);


                              // builder_categorias.getDialog().cancel();







                                // The callback can be enabled or disabled here or in handleOnBackPressed()


                                //builder_categorias.create();



                              //  builder.setCancelable(true);




                                //.dismiss();




                            }
                        });




                    }

                    @Override
                    public int getItemCount() {
                        return lis_catalagos.size();
                    }
                };

                GridLayoutManager gridLayoutManager = new GridLayoutManager(view.getContext(), 2);
                rv.setLayoutManager(gridLayoutManager);
                rv.setAdapter(adapter_solo_seleccionar);
              //  Adapter_normal_lista_productos adapter = new Adapter_normal_lista_productos(view.getContext(),list_servicios);
              //  rv.setAdapter(adapter);

                //


                builder_categorias.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog,int id) {

                    }
                });


                builder_categorias.create();
                builder_categorias.show();





            }
        });

        factura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                LayoutInflater inflater=LayoutInflater.from(view.getContext());
                // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();
                View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null);
                builder.setView(dialogView);

                RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                TextView texto_dialo=(TextView)dialogView.findViewById(R.id.numero_productoslista);
               EditText editText_nota=(EditText)dialogView.findViewById(R.id.notacliente);
               TextView mostrartotal=(TextView)dialogView.findViewById(R.id.mostrartotal_fac);
                TextView completar_reserva=(TextView)dialogView.findViewById(R.id.completarreserva);
              final EditText   fecha_cita_reserva=(EditText)dialogView. findViewById(R.id.fecha_cita_reserva);
                final EditText hora=(EditText) dialogView.findViewById(R.id.hora_reservacion);


                List<Usuario>listaadmis=new ArrayList<>();
                final String[] fecha_reservacion = new String[1];
                final String[] hora_reservacion = new String[1];
                final Long[] fechaCalendar2 = new Long[1];
                int num=list_servicios.size();

                //dialog
                 Calendar c = Calendar.getInstance();
                //Variables para obtener la fecha
                final int mes = c.get(Calendar.MONTH);
                final int dia = c.get(Calendar.DAY_OF_MONTH);
                final int anio = c.get(Calendar.YEAR);
                //Variables para obtener la hora hora
                final int hora_int = c.get(Calendar.HOUR_OF_DAY);
                final int minuto = c.get(Calendar.MINUTE);
               final String CERO = "0";
                 final String DOS_PUNTOS = ":";

                texto_dialo.setText("Servicios:  "+num+"\n"+"Total: "+total_int);

                fecha_cita_reserva.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                      // fecha_cita_reserva.setFocusable(true);
                      //  fecha_cita_reserva.setFocusable(true);

                        fecha_cita_reserva.setClickable(false);
                        //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                        final Calendar calendar=Calendar.getInstance();
                        DatePickerDialog datePickerDialog= new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {



                                Calendar can=Calendar.getInstance();
                                can.set(calendar.YEAR,year);
                                can.set(Calendar.MONTH,month);
                                can.set(calendar.DAY_OF_MONTH,dayOfMonth);

                                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/YYYY");
                                Date date=can.getTime() ;

                                String fechaCalendarrrr=simpleDateFormat.format(date);
                                //Long fechalong=simpleDateFormat.format(date);//es string reune los datos
                                fechaCalendar2[0] =date.getTime(); //con eto obtenermos el archivo de topo long a strig

                                fecha_cita_reserva.setText(fechaCalendarrrr);
                               fecha_reservacion[0] =fechaCalendarrrr;


                            }
                        },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                    }
                });
                hora.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TimePickerDialog recogerHora = new TimePickerDialog(getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                //Formateo el hora obtenido: antepone el 0 si son menores de 10
                                String horaFormateada =  (hourOfDay < 10)? String.valueOf(CERO + hourOfDay) : String.valueOf(hourOfDay);
                                //Formateo el minuto obtenido: antepone el 0 si son menores de 10
                                String minutoFormateado = (minute < 10)? String.valueOf(CERO + minute):String.valueOf(minute);
                                //Obtengo el valor a.m. o p.m., dependiendo de la selección del usuario
                                String AM_PM;
                                if(hourOfDay < 12) {
                                    AM_PM = "a.m.";
                                } else {
                                    AM_PM = "p.m.";
                                }
                                //Muestro la hora con el formato deseado
                                hora.setText(horaFormateada + DOS_PUNTOS + minutoFormateado + " " + AM_PM);
                                String timehora=horaFormateada + DOS_PUNTOS + minutoFormateado + " " + AM_PM;
                                hora_reservacion[0] =timehora;
                            }
                            //Estos valores deben ir en ese orden
                            //Al colocar en false se muestra en formato 12 horas y true en formato 24 horas
                            //Pero el sistema devuelve la hora en formato 24 horas
                        }, hora_int, minuto, false);

                        recogerHora.show();

                    }
                });

                completar_reserva.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        //datos usuario
                        //pedido
                        //direccion
                        //lista de servicios
                        Map_location map_location = new Map_location();
                        map_location.setLatitud(latitud);
                        map_location.setLongitud(longitud);

                        //map_location.setLatitud(latitud_cliente);
                        //map_location.setLongitud(longitud_cliente);
                        GeoHash geoHash = GeoHash.fromLocation(map_location, 6);
                        hash_traido = geoHash.toString();


                        //comprobamos datos
                        if (fecha_cita_reserva.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "ingregar fecha", Toast.LENGTH_SHORT).show();
                        }

                        if (hora.getText().toString().isEmpty()){
                            Toast.makeText(getContext(), "ingregar hora reservacion", Toast.LENGTH_SHORT).show();
                        }
                        if (latitud==0&&longitud==0){
                            Toast.makeText(getContext(), "Localizacion off "+latitud+ "  "+ longitud+ "  "+nombre_uso_de_firebase, Toast.LENGTH_SHORT).show();

                        }
                        if (nombre_uso_de_firebase==null){
                            Toast.makeText(getContext(), "usuario no obtneido , intentar de nuevo ,nombre: "+nombre_uso_de_firebase, Toast.LENGTH_SHORT).show();


                            cargarinfo_usu();
                        }


                        if ( nombre_uso_de_firebase!=null&&fecha_reservacion[0]!=null&&hora_reservacion[0]!=null){

                            CharSequence colors[] = new CharSequence[]{"Direccion perfil:"+descripcion_firebase, "Ubicacion actual"};

                            List<String> lista_hashpermitido=new ArrayList<>();
                            //hash 5, sectores de 5klm
                            String cadena_5klm = hash_traido; //lectura a 5klmts de distancia
                            cadena_5klm = cadena_5klm.substring(0, cadena_5klm.length() - 1);
                            lista_hashpermitido.add("66j9z");
                            lista_hashpermitido.add("66jcb");
                            lista_hashpermitido.add("66j9x");
                            lista_hashpermitido.add("66jc8");
                            lista_hashpermitido.add("66jc8");
                            lista_hashpermitido.add("66jc9");

                            Toast.makeText(getContext(),cadena_5klm, Toast.LENGTH_SHORT).show();

                            AlertDialog.Builder builder_multtiple = new AlertDialog.Builder(getContext());
                            builder_multtiple.setTitle("Ubicacion Domicilio");
                            String finalCadena_5klm = cadena_5klm;
                            builder_multtiple.setItems(colors, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("value is", "" + which);
                                    switch (which) {


                                        case 0:


                                            //aqui todo bien solo falta arreglar lat y long de usuario perfil
                                            ProgressDialog progressDialog=new ProgressDialog(getContext());
                                            progressDialog.setMessage("loading..");

                                            if(list_servicios.size()>0&&hash_traido!=null) {

                                                for (int i=0;i<lista_hashpermitido.size();i++){

                                                    if (finalCadena_5klm.equals(lista_hashpermitido.get(i))){
                                                        Toast.makeText(getContext(), "sector correcto "+hash_traido, Toast.LENGTH_SHORT).show();

                                                        i=lista_hashpermitido.size();


                                                        Reserva_cosmos reserva_cosmos = new Reserva_cosmos();
                                                        reserva_cosmos.setTimestamp(timestamp());
                                                        reserva_cosmos.setKey_uid(Usuario_DAO.getInstance().getKeyUsuario());
                                                        reserva_cosmos.setNotifiuid_cliente(notifiuid_cliente);
                                                        reserva_cosmos.setKey_busqueda(hash_traido);
                                                        reserva_cosmos.setNombre_cliente(nombre_uso_de_firebase);
                                                        reserva_cosmos.setTelefono(telefono_firebase);
                                                        reserva_cosmos.setLatitud_cliente(latitud_cliente_fire);
                                                        reserva_cosmos.setLongitud_cliente(longitud_cliente_fire);
                                                        reserva_cosmos.setDireccion(descripcion_firebase);
                                                        reserva_cosmos.setHora_servicios(hora_reservacion[0]);
                                                        reserva_cosmos.setFecha_servicios(fecha_reservacion[0]);
                                                        reserva_cosmos.setFecha_reservacion(fecha_enviado_mensaje());
                                                        reserva_cosmos.setFotografia(fotorecuperada);

                                                        reserva_cosmos.setListservices(list_servicios);



                                                        reserva_cosmos.setTotal_int(total_int);

                                                        // String val=precio_int_carrito;
                                                        //reserva_cosmos.setTotal_string(val);

                                                        FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                        db.collection(Constantes.Reservaciones).document(Usuario_DAO.getInstance().getKeyUsuario()).set(reserva_cosmos);
                                                        // db.collection(Constantes.Reservaciones_usuario).document(Usuario_DAO.getInstance().getKeyUsuario()).collection(Constantes.Factura).add(reserva_cosmos);

                                                        //avisar administradores
                                                        FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
                                                        firebaseDatabase.getReference("Usuario")
                                                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                                                    @Override
                                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                                                                        for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                                                                            //   Servicio_p1 servicio_p1=snapshot.getValue(Servicio_p1.class);
                                                                            Usuario usuario=snapshot.getValue(Usuario.class);
                                                                            if (usuario!=null){

                                                                                if (usuario.getNotifi_uid()!=null) {

                                                                                    RequestQueue myrequest = Volley.newRequestQueue(getContext());
                                                                                    JSONObject jsonObject = new JSONObject();
                                                                                    try {
                                                                                        String token = usuario.getNotifi_uid();
                                                                                        jsonObject.put("to", token);

                                                                                        JSONObject notificaciojn = new JSONObject();
                                                                                        notificaciojn.put(Constantes.Titulo, "Nueva Reservacion");
                                                                                        notificaciojn.put(Constantes.Detalle, "Reservacion   " + nombre_uso_de_firebase);
                                                                                        notificaciojn.put(Constantes.tiponotificaion, "corazon");
                                                                                        notificaciojn.put("uid","");
                                                                                        notificaciojn.put("fotouser","");
                                                                                        notificaciojn.put("nombre", nombre_uso_de_firebase);
                                                                                        notificaciojn.put("notifi2", notifiuid_cliente);

                                                                                        Log.e("TAG", "token adapter   " + token);


                                                                                        jsonObject.put("data", notificaciojn);
                                                                                        String URL = "https://fcm.googleapis.com/fcm/send";
                                                                                        //  String URL2="https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

                                                                                        //envia los requerimientos jsobobject //methdo,url/objetos y escuchas y error de escucha
                                                                                        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL, jsonObject, null, null) {

                                                                                            @Override
                                                                                            public Map<String, String> getHeaders() {
                                                                                                Map<String, String> header = new Hashtable<>();
                                                                                                header.put("content-type", "application/json");
                                                                                                header.put("authorization", "key=" + Constantes.nube_key);
                                                                                                //firebaseconsole/consfiguracion//cloudmessenger/
                                                                                                return header;
                                                                                            }
                                                                                        };

                                                                                        myrequest.add(request);

                                                                                    } catch (Exception e) {
                                                                                        e.printStackTrace();
                                                                                    }
                                                                                }

                                                                            }

                                                                        }




                                                                    }

                                                                    @Override
                                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                                    }
                                                                });


                                                        //  Toast.makeText(getContext(), listaadmis.size(), Toast.LENGTH_LONG).show();

                                                        //nontificar_administradores(); //no funciono
                                                        Toast.makeText(getContext(), "Reservacion agendada: "+ latitud+"   "+longitud, Toast.LENGTH_LONG).show();

                                                    }

                                                }

               }
                                            else {
                                                Toast.makeText(getContext(), "Informacion faltante", Toast.LENGTH_LONG).show();

                                            }
                                            break;


                                        case 1:

                                            //ubicacion actual
                                            ProgressDialog progressDialog2=new ProgressDialog(getContext());
                                            progressDialog2.setMessage("loading..");

                                            if (list_servicios.size()>0 &&  nombre_uso_de_firebase!=null&&latitud!=0&&longitud!=0) {
                                                /*
                                                //obtenemos los datos hasta la reservacion actual
                                                Reserva_cosmos reserva_cosmos = new Reserva_cosmos();
                                                reserva_cosmos.setTimestamp(timestamp());
                                                reserva_cosmos.setKey_uid(Usuario_DAO.getInstance().getKeyUsuario());
                                                reserva_cosmos.setNotifiuid_cliente(notifiuid_cliente);
                                                reserva_cosmos.setKey_busqueda(hash_traido);
                                                reserva_cosmos.setNombre_cliente(nombre_uso_de_firebase);
                                                reserva_cosmos.setTelefono(telefono_firebase);
                                                reserva_cosmos.setLatitud_cliente(latitud);
                                                reserva_cosmos.setLongitud_cliente(longitud);
                                                reserva_cosmos.setDireccion(descripcion_firebase);
                                                reserva_cosmos.setHora_servicios(hora_reservacion[0]);
                                                reserva_cosmos.setFecha_servicios(fecha_reservacion[0]);
                                                reserva_cosmos.setFecha_reservacion(fecha_enviado_mensaje());

                                                reserva_cosmos.setListservices(list_servicios);

                                                reserva_cosmos.setTotal_int(total_int);

                                                 */
                                                //  if (hash_traido!=null,notifiuid_cliente!=null,telefono_firebase!=null,fotorecuperada!=null,descripcion_firebase!=null, hora_reservacion[0]!=null,fecha_reservacion[0]!=null,latitud!=0,longitud!=0){

                                                for (int i=0;i<lista_hashpermitido.size();i++) {

                                                    if (finalCadena_5klm.equals(lista_hashpermitido.get(i))) {
                                                        Toast.makeText(getContext(), "sector correcto " + hash_traido, Toast.LENGTH_SHORT).show();

                                                        i = lista_hashpermitido.size();

                                                    }
                                                }

                                                Intent i = new Intent(getContext(), Maps_desechabe_Carrito_confirmar.class);

                                                LatLng toPosition = new LatLng(latitud, longitud);

                                                Bundle bundle1 = new Bundle();
                                                // Bundle bundle2_soloinfo = new Bundle();

                                                /*
                                               // bundle1.putString("key_usu_c_v1", Usuario_DAO.getInstance().getKeyUsuario());
                                               // bundle1.putString("key_usu__hash_v1", hash_traido);

                                              //  bundle1.putString("notifi_v1", notifiuid_cliente);//agregada
                                              //  bundle1.putString("nom_usu_v1", nombre_uso_de_firebase);
                                                //bundle1.putString("tel_usu_v1", telefono_firebase);
                                                //bundle1.putString("foto_user_v1", fotorecuperada);
                                                // bundle1.putString("correo_usu",co);
                                                //bundle1.putString("nota_cliente_v1", descripcion_firebase);//Agregado
                                                //  bundle1.putString("hora_reservacion_v1", hora_reservacion[0]);
                                              //  bundle1.putString("fecha_reservacion_v1", fecha_reservacion[0]);
                                              //  bundle1.putInt("total_V1", total_int);

                                                 */


                                                //estos funcionan a la perfeccion
                                                bundle1.putParcelable("to_position", toPosition); //este dice que sirve
                                                i.putParcelableArrayListExtra("Lista_v3", (ArrayList<? extends Parcelable>) list_servicios); //funiona

                                                i.putExtra("key_usu_c_v1", Usuario_DAO.getInstance().getKeyUsuario());
                                                i.putExtra("key_usu__hash_v1", hash_traido);
                                                i.putExtra("notifi_v1", notifiuid_cliente);
                                                i.putExtra("nom_usu_v1",nombre_uso_de_firebase);
                                                i.putExtra("tel_usu_v1", telefono_firebase);
                                                i.putExtra("foto_user_v1", fotorecuperada);
                                                i.putExtra("nota_cliente_v1", descripcion_firebase);
                                                i.putExtra("hora_reservacion_v1", hora_reservacion[0]);
                                                i.putExtra("fecha_reservacion_v1", fecha_reservacion[0]);
                                                 String valortotral_s= String.valueOf(total_int);
                                               // i.putExtra("total_v2", total_int);
                                                 i.putExtra("total_v2_carr", valortotral_s);


                                                i.putExtra("bundle_domicilio", bundle1);


                                                startActivity(i);


                                            }
                                            else {
                                                Toast.makeText(getContext(), "Informacion faltante", Toast.LENGTH_LONG).show();

                                            }




                                    }


                                }
                            });
                            builder_multtiple.show();



                        }

                        else {

                        }






                    }
                });


                //   rv.setLayoutManager(new LinearLayoutManager(view.getContext(),LinearLayoutManager.HORIZONTAL,false));
                GridLayoutManager gridLayoutManager = new GridLayoutManager(view.getContext(), 2);
                rv.setLayoutManager(gridLayoutManager);

                RecyclerView.Adapter<Usuarios_cercanos_holder> adapter_ultimo_vistazolist= new RecyclerView.Adapter<Usuarios_cercanos_holder>() {
                    @NonNull
                    @Override
                    public Usuarios_cercanos_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usuarios_cercanos_info, parent, false);
                        return  new Usuarios_cercanos_holder(view);

                    }

                    @Override
                    public void onBindViewHolder(@NonNull Usuarios_cercanos_holder holder, int position) {


                        holder.getBtn_mensajeria().setVisibility(GONE);

//        holder.getTelefono().setVisibility(GONE);

                        holder.getNombre_cliente_item().setText(list_servicios.get(position).getNombre());
                        holder.getTelefono().setText(list_servicios.get(position).getPrecio());
                        if (list_servicios.get(position).getFoto_string()!=null){

                            Glide.with(holder.itemView.getContext()).load(list_servicios.get(position).getFoto_string()).into(holder.getFoto_perfil_item_usuario());
                        }

                        holder.getBtn_corazon().setVisibility(GONE);
                        holder.getBtn_setings().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemView.getContext());


                                builder.setTitle("Eliminar servicio?");
                                builder.setIcon(R.mipmap.ic_launcher);
                                builder.setMessage(
                                        "eliminar "+list_servicios.get(position).getNombre());
                                builder.setPositiveButton("OK",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                nombre_carrito=list_servicios.get(position).getNombre();
                                                codigo_carrito=list_servicios.get(position).getCodigo();

                                                for (int i1=0;i1<list_servicios.size();i1++){ //buclefor de la lista


                                                if (nombre_carrito.equals(list_servicios.get(i1).getNombre())&& codigo_carrito.equals(list_servicios.get(i1).getCodigo())) {


                                                              total_int=total_int-list_servicios.get(i1).getPrecio2_int();
                                                    Toast.makeText(getContext(), "-1 "+list_servicios.get(i1).getNombre(), Toast.LENGTH_SHORT).show();

                                                    list_servicios.remove(i1);
                                                    i1--;


                                                    i1=list_servicios.size();

                                                    texto_dialo.setText("Servicios:  "+list_servicios.size()+"\n"+"Total: "+total_int);



                                                    notifyDataSetChanged();

                                                }




                                                }

                                                //int n=position;
                                                //list_servicios.remove(position);
                                                //notifyDataSetChanged();





                                            }
                                        }).setNegativeButton("CANCELAR",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Toast.makeText(holder.itemView.getContext(), "cancelado ", Toast.LENGTH_LONG).show();
                                                //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                            }
                                        });
                                //  AlertDialog dialog = builder.create();
                                builder.create();
                                builder.show();

                            }
                        });

                    }

                    @Override
                    public int getItemCount() {
                        return list_servicios.size();
                    }
                };
                ///Adapter_normal_lista_productos adapter = new Adapter_normal_lista_productos(view.getContext(),list_servicios);
                rv.setAdapter(adapter_ultimo_vistazolist);

                //


                AlertDialog dialog = builder.create();

                builder.create();
                builder.show();


            }
        });




      //  cargarusers_friestore();
        ///////////////////////////////////////////////

      //  cargarprodutosdeventa();

        ///////////////////7

       // FirebaseFirestore db=FirebaseFirestore.getInstance();

        // db.collection(Constantes.Productos).whereGreaterThan("codigo","10");


        if (buscarenelcarrito!=null) {
            seleccion =buscarenelcarrito;
           cargar_adapter(seleccion);
           // cargar_adarpter_v2_conlista(seleccion);
        }
        else {
            seleccion = Constantes.servicio1_Peluqueria_hombre;
            cargar_adapter(seleccion);
           // cargar_adarpter_v2_conlista(seleccion);

        }


        return view;
    }

    private void cargar_adapter(String categorias_servicio_aqio) {
        FirebaseFirestore db=FirebaseFirestore.getInstance();
        com.google.firebase.firestore.Query query2 = db.collection(Constantes.Productos).document(Constantes.Catalogo_productos).collection(categorias_servicio_aqio)
                //.whereGreaterThan("codigo","1");//.startAt( ubicacion_hash); //no funciono
               // .orderBy("timestamp_string");
         .orderBy("timestamp_string", Query.Direction.DESCENDING).limitToLast(10);

        FirestoreRecyclerOptions<Servicio_p1> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Servicio_p1>().setQuery(query2, Servicio_p1.class).build();
        adapter=new FirestoreRecyclerAdapter<Servicio_p1, Holde_inicio_servicios>(firestoreRecyclerOptions) {

            @NonNull
            @Override
            public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_servicios, parent, false);

                return new Holde_inicio_servicios(view);
            }

            protected void onBindViewHolder(@NonNull final Holde_inicio_servicios holder, int position, @NonNull final Servicio_p1 model) {


                if (model.getFoto_string()!=null){

                    Glide.with(getContext()).load(model.getFoto_string()).into(holder.getFotocatefgoria());

                }else {
                    Glide.with(getContext()).load(R.mipmap.ic_launcher).into(holder.getFotocatefgoria());

                }
                if (model.getCateforia_producto()!=null) {
                    cateforia_producto_carrito=model.getCateforia_producto();
                }
                if (model.getNombre()!=null) {
                    nombre_carrito =model.getNombre();
                }
                if (model.getCodigo()!=null) {
                    codigo_carrito=model.getCodigo();

                }
                if (model.getPrecio()!=null) {
                    precio_carrito =model.getPrecio();
                }
                if (model.getPrecio2_int()!=0) {

                    precio_int_carrito=model.getPrecio2_int();

                }else {precio_int_carrito=0;}



                holder.getCount1().setVisibility(View.GONE);
                holder.getCount2().setVisibility(View.GONE);
                holder.getCount3().setVisibility(View.GONE);

                holder.getMas1().setVisibility(View.GONE);
                holder.getMas2().setVisibility(View.GONE);
                holder.getMas3().setVisibility(View.GONE);

                holder.getMen1().setVisibility(View.GONE);
                holder.getMen2().setVisibility(View.GONE);
                holder.getMen3().setVisibility(View.GONE);
                ///////////////////////////////////////////////////

                holder.getCategoria_titulo().setText(model.getNombre());
                holder.getPreciodesde().setText(model.getPrecio());

                /////////////////////////////



                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //si toca inicia el primero libre
                        //position=-1;
                        holder.getCount1().setVisibility(View.VISIBLE);
                        holder.getMas1().setVisibility(View.VISIBLE);
                        holder.getMen1().setVisibility(View.VISIBLE);

                        holder.getMas1().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Servicio_p1 servicio_p1=new Servicio_p1();


                                //tengo la teoria que es por esto que no me toma la info correcta
                                /*
                                servicio_p1.setFoto_string(model.getFoto_string());
                                servicio_p1.setCateforia_producto(cateforia_producto_carrito);
                                servicio_p1.setNombre(nombre_carrito);
                                servicio_p1.setCodigo(codigo_carrito);
                                servicio_p1.setPrecio(precio_carrito);
                                servicio_p1.setPrecio2_int(precio_int_carrito);

                                 */
                                servicio_p1.setFoto_string(model.getFoto_string());
                                servicio_p1.setCateforia_producto(model.getCateforia_producto());
                                servicio_p1.setNombre(model.getNombre());
                                servicio_p1.setCodigo(model.getCodigo());
                                servicio_p1.setPrecio(model.getPrecio());
                                servicio_p1.setPrecio2_int(model.getPrecio2_int());
                                Toast.makeText(getActivity(), "añadido: " + model.getNombre() +" ,"+ model.getPrecio(), Toast.LENGTH_LONG).show();
                                total_int=total_int+model.getPrecio2_int();

                                list_servicios.add(servicio_p1);






                            }
                        });



                        holder.getMen1().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                Servicio_p1 servicio_p1=new Servicio_p1();


                                servicio_p1.setFoto_string(model.getFoto_string());
                                servicio_p1.setCateforia_producto(model.getCateforia_producto());
                                servicio_p1.setNombre(model.getNombre());
                                servicio_p1.setCodigo(model.getCodigo());
                                servicio_p1.setPrecio(model.getPrecio());
                                servicio_p1.setPrecio2_int(model.getPrecio2_int());
                                //Toast.makeText(getActivity(), "-1 : " + model.getNombre() +" ,"+ model.getPrecio(), Toast.LENGTH_LONG).show();


                                //eliminar el servicio de la lista si existe
                                for (int i1=0;i1<list_servicios.size();i1++){ //buclefor de la lista

                                    if (nombre_carrito.equals(list_servicios.get(i1).getNombre())&& codigo_carrito.equals(list_servicios.get(i1).getCodigo())) {
                                        list_servicios.remove(i1);
                                        i1--;

                                        total_int=total_int-model.getPrecio2_int();
                                        Toast.makeText(getContext(), "-1 "+model.getNombre(), Toast.LENGTH_SHORT).show();
                                        i1=list_servicios.size();

                                        //texto_dialo.setText("Servicios:  "+list_servicios.size()+"\n"+"Total: "+total_int);



                                    }


                                }

                            }
                        });






                    }
                });


            }


        };


        //adapter.notifyDataSetChanged();



        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);


        adapter.startListening();
        recyclerView.setAdapter(adapter);

    }

    private  void cargar_adarpter_v2_conlista(String categorias_servicio_aqio){

        List<Servicio_p1> lista_servicios_v2=new ArrayList<>();
        FirebaseFirestore db=FirebaseFirestore.getInstance();
        db.collection(Constantes.Productos).document(Constantes.Catalogo_productos).collection(categorias_servicio_aqio)
                //.whereGreaterThan("codigo","1");//.startAt( ubicacion_hash); //no funciono
                .orderBy("timestamp_string")
                .get()
              .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                  @Override
                  public void onComplete(@NonNull Task<QuerySnapshot> task) {
                      if (task.isSuccessful()) {
                          for (QueryDocumentSnapshot document : task.getResult()) {
                            //  Log.d(TAG, document.getId() + " => " + document.getData());
                              Servicio_p1 servicio_p1_seleccionado=document.toObject(Servicio_p1.class);
                              if (servicio_p1_seleccionado!=null){

                                  lista_servicios_v2.add(servicio_p1_seleccionado);
                              }


                          }
                      } else {
                          //Log.d(TAG, "Error getting documents: ", task.getException());
                      }
                  }
              });
//        Toast.makeText(getContext(),lista_servicios_v2.size(), Toast.LENGTH_SHORT).show();


        RecyclerView.Adapter<Holde_inicio_servicios> adapter_carrito_v2=new RecyclerView.Adapter<Holde_inicio_servicios>() {
            @NonNull
            @Override
            public Holde_inicio_servicios onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_servicios, parent, false);

                return new Holde_inicio_servicios(view);
            }

            @Override
            public void onBindViewHolder(@NonNull Holde_inicio_servicios holder, int position) {
                if (lista_servicios_v2.get(position).getFoto_string()!=null){

                    Glide.with(getContext()).load(lista_servicios_v2.get(position).getFoto_string()).into(holder.getFotocatefgoria());

                }else {
                    Glide.with(getContext()).load(R.mipmap.ic_launcher).into(holder.getFotocatefgoria());

                }
                if (lista_servicios_v2.get(position).getCateforia_producto()!=null) {
                    cateforia_producto_carrito=lista_servicios_v2.get(position).getCateforia_producto();
                }
                if (lista_servicios_v2.get(position).getNombre()!=null) {
                    nombre_carrito =lista_servicios_v2.get(position).getNombre();
                }
                if (lista_servicios_v2.get(position).getCodigo()!=null) {
                    codigo_carrito=lista_servicios_v2.get(position).getCodigo();

                }
                if (lista_servicios_v2.get(position).getPrecio()!=null) {
                    precio_carrito =lista_servicios_v2.get(position).getPrecio();
                }
                if (lista_servicios_v2.get(position).getPrecio2_int()!=0) {

                    precio_int_carrito=lista_servicios_v2.get(position).getPrecio2_int();

                }else {precio_int_carrito=0;}



                holder.getCount1().setVisibility(View.GONE);
                holder.getCount2().setVisibility(View.GONE);
                holder.getCount3().setVisibility(View.GONE);

                holder.getMas1().setVisibility(View.GONE);
                holder.getMas2().setVisibility(View.GONE);
                holder.getMas3().setVisibility(View.GONE);

                holder.getMen1().setVisibility(View.GONE);
                holder.getMen2().setVisibility(View.GONE);
                holder.getMen3().setVisibility(View.GONE);
                ///////////////////////////////////////////////////

                holder.getCategoria_titulo().setText(lista_servicios_v2.get(position).getNombre());
                holder.getPreciodesde().setText(lista_servicios_v2.get(position).getPrecio());

                /////////////////////////////



                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        //si toca inicia el primero libre
                        holder.getCount1().setVisibility(View.VISIBLE);
                        holder.getMas1().setVisibility(View.VISIBLE);
                        holder.getMen1().setVisibility(View.VISIBLE);

                        holder.getMas1().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Servicio_p1 servicio_p1=new Servicio_p1();


                                servicio_p1.setFoto_string(lista_servicios_v2.get(position).getFoto_string());
                                servicio_p1.setCateforia_producto(cateforia_producto_carrito);
                                servicio_p1.setNombre(nombre_carrito);
                                servicio_p1.setCodigo(codigo_carrito);
                                servicio_p1.setPrecio(precio_carrito);
                                servicio_p1.setPrecio2_int(precio_int_carrito);

                                Toast.makeText(getActivity(), "añadido: " + nombre_carrito +" ,"+ precio_carrito, Toast.LENGTH_LONG).show();
                                total_int=total_int+precio_int_carrito;

                                list_servicios.add(servicio_p1);






                            }
                        });



                        holder.getMen1().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                Servicio_p1 servicio_p1=new Servicio_p1();

                                servicio_p1.setFoto_string(lista_servicios_v2.get(position).getFoto_string());
                                servicio_p1.setCateforia_producto(cateforia_producto_carrito);
                                servicio_p1.setNombre(nombre_carrito);
                                servicio_p1.setCodigo(codigo_carrito);
                                servicio_p1.setPrecio(precio_carrito);
                                servicio_p1.setPrecio2_int(precio_int_carrito);


                                //eliminar el servicio de la lista si existe
                                for (int i1=0;i1<list_servicios.size();i1++){ //buclefor de la lista

                                    if (nombre_carrito.equals(list_servicios.get(i1).getNombre())&& codigo_carrito.equals(list_servicios.get(i1).getCodigo())) {
                                        list_servicios.remove(i1);
                                        i1--;

                                        total_int=total_int-precio_int_carrito;
                                        Toast.makeText(getContext(), "-1 "+nombre_carrito, Toast.LENGTH_SHORT).show();
                                        i1=list_servicios.size();


                                    }


                                }

                            }
                        });






                    }
                });

            }

            @Override
            public int getItemCount() {
                return lista_servicios_v2.size();
            }
        };


        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);



        //adapter_carrito_v2.startListening();
        recyclerView.setAdapter(adapter_carrito_v2);
        adapter_carrito_v2.notifyDataSetChanged();





    }

    //este methodo fue canbiado para insertar datos desde lainterfaz admin
    private void cargarprodutosdeventa() {
        //cargar el catologo a esta direccion de productos clase
        //serviciosp1
        FirebaseFirestore db=FirebaseFirestore.getInstance();

        com.google.firebase.firestore.Query query_ventas= db.collection(Constantes.Productos)
                .whereGreaterThan("codigo","1");//.startAt( ubicacion_hash); //no funciono

        // Servicio_p1(String time_string, String cateforia_producto,
        // String nombre, String codigo, String precio, int precio2_int) {
        //
       // List<Servicio_p1> listaservicios_a_vender=new ArrayList<>();
      //  listaservicios_a_vender.add(new Servicio_p1(timestamp(),"Peluqueria","Corte Varon","101","10000",10000));

       // db.collection(Constantes.Productos).add(new Servicio_p1(timestamp(),"Peluqueria","Corte Varon","101","10000",10000));

    }

    private void nontificar_administradores() { //no unciono


        FirebaseDatabase database= FirebaseDatabase.getInstance();
                database.getReference("Usuario" ).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dataSnapshotz:dataSnapshot.getChildren()){

                            Usuario admis=dataSnapshot.getValue(Usuario.class);
                            if (admis!=null){



                                if (admis.getNotifi_uid()!=null) {

                                    RequestQueue myrequest= Volley.newRequestQueue(getContext());
                                    JSONObject jsonObject=new JSONObject();
                                    try {
                                        String token = admis.getNotifi_uid();
                                        jsonObject.put("to", token);

                                        JSONObject notificaciojn = new JSONObject();
                                        notificaciojn.put(Constantes.Titulo, "Nueva Reservacion");
                                        notificaciojn.put(Constantes.Detalle, "Reservacion   "+nombre_uso_de_firebase);
                                        notificaciojn.put(Constantes.tiponotificaion,"corazon");
                                        //notificaciojn.put("uid",admis);
                                        //   notificaciojn.put("fotouser",admis.);
                                        notificaciojn.put("nombre",nombre_uso_de_firebase);
                                        notificaciojn.put("notifi2",notifiuid_cliente);

                                        Log.e("TAG","token adapter   "+ token);


                                        jsonObject.put("data", notificaciojn);
                                        String URL = "https://fcm.googleapis.com/fcm/send";
                                        //  String URL2="https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

                                        //envia los requerimientos jsobobject //methdo,url/objetos y escuchas y error de escucha
                                        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,URL , jsonObject, null, null) {

                                            @Override
                                            public Map<String, String> getHeaders() {
                                                Map<String, String> header = new Hashtable<>();
                                                header.put("content-type", "application/json");
                                                header.put("authorization", "key="+"AAAAIOH5QNo:APA91bGA2L7RnnA3cqv5WstLWoped63inBOQWTYLCMm0TSwFV0u805VeCmpQnlkLP5TX78esinfIblRL3VniviFerwQDLy4MFaDS-bTWoVl-2dS4EixZrlajcUTNw2yvu-MPryd1NaCf");
                                                //firebaseconsole/consfiguracion//cloudmessenger/
                                                return header;
                                            }
                                        };

                                        myrequest.add(request);

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }




                            }

                        }



                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


    }

    private void cargarusers_friestore() {

/*

        FirebaseFirestore firestore_forrecicler = FirebaseFirestore.getInstance();

        Query query2=firestore_forrecicler.collection(Constantes.Nodo_Rooms_general)
                .whereGreaterThanOrEqualTo("key_busqueda",ubicacion);
        FirestoreRecyclerOptions<Room> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Room>().setQuery(query2 , Room.class).build();

      //   adapter_firestore_productos_room = new Adapter_Firestore_productos_Room(firestoreRecyclerOptions);
        adapter_hoteles_cercanos=new Adapter_hoteles_cercanos(firestoreRecyclerOptions);

        adapter_hoteles_cercanos.notifyDataSetChanged();

 */
    }
    public  String fecha_enviado_mensaje(){

        // Date date=new Date();
        //PrettyTime prettyTime=new PrettyTime(new Date(), Locale.getDefault()); //obtiene el formato del dispositivo local
        //return  prettyTime.format(date);

        // Long cdigoHora=mensajeList.get(position).getHora();
        // al pedir un ong para funcionar simplemente enviamos el lon getCreatedTimestamp()
        Date d=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
        return sdf.format(d);
    }
    public String timestamp(){

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        return ts;
    }
    private void startLocationUpdates() {

        // Cree la solicitud de ubicación para comenzar a recibir actualizaciones
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(update_interval);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Cree el objeto LocationSettingsRequest utilizando la solicitud de ubicación
        LocationSettingsRequest.Builder constructor = new LocationSettingsRequest.Builder();
        constructor.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = constructor.build();


        // Verifique si la configuración de ubicación se cumple
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(getContext());
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // el nuevo SDK v11 de la API de Google usa getFusedLocationProviderClient (this)
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getFusedLocationProviderClient(getContext()).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // trabaja aquí
                        // onLocationChanged (locationResult . getLastLocation ());
                       latitud= locationResult.getLastLocation().getLatitude();
                       longitud=locationResult.getLastLocation().getLongitude();
                    }
                },
                Looper.myLooper());
    }
    public void cargarinfo_usu(){
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // enviar.setEnabled(true); //esto dice que antes de reclamar los datos el boton debe estar inabilitado
            FirebaseDatabase database = getInstance();
            DatabaseReference reference = database.getReference(Constantes.Nodo_Usuario + "/" + currentUser.getUid());

            //  DatabaseReference reference=database.getReference("Usuarios/"+currentUser.getUid()); //se concadena con el UID de firebase que es un codigo largo de id
            //con el anterior referencia podemos reclamar el nombre y el correo de firebase de el path usuarios
            FirebaseStorage storage_usu_foto = FirebaseStorage.getInstance();
            //StorageReference storageReference2=storage_usu_foto.getReference("Foto_Ususarios").child(Usuario_DAO.getInstance().getKeyUsuario());
            StorageReference storageReference3 = storage_usu_foto.getReference("fotos_perfil_USuario").child(Usuario_DAO.getInstance().getKeyUsuario());


            reference.addListenerForSingleValueEvent(new ValueEventListener() {


                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) { //datasnappshop es el qeu recupera los datos


                    //String value = dataSnapshot.getValue(String.class);
                    Usuario usu = dataSnapshot.getValue(Usuario.class);//pone la referencia

                    if (usu != null) {
                        String usu2 = usu.getUsuario_nombre();
                        String foto_ussss = usu.getFotodePerfilURI();
                        String profesion = usu.getProfesion();





                        final String foto_perfil_URI2 = usu.getFotodePerfilURI();

                        if (usu.getFotodePerfilURI() != null) {
                          //  Glide.with(getContext()).load(usu.getFotodePerfilURI()).into(foto_usuario_perfil);
                            fotorecuperada = foto_ussss;
                        }
                        if (usu.getLatidu()!=null&&usu.getLongitud()!=null){

                            latitud_cliente_fire=usu.getLatidu();
                            longitud_cliente_fire=usu.getLongitud();

                        }




                        if (usu.getUsuario_nombre()!=null){

                            nombre_uso_de_firebase = usu.getUsuario_nombre().trim(); //string
                          //  nombreusuario_edittex.setText(nombre_uso_de_firebase);
                        }else {
                          //  nombreusuario_edittex.setText("");
                        }
                        if (usu.getTeleono_usuario()!=null){
                            telefono_firebase = usu.getTeleono_usuario().trim();
                           // telefono_usuario.setText(telefono_firebase);
                        }else {
                            //telefono_usuario.setText("");
                        }
                        if (usu.getHabilidad_profesional()!=null){

                            descripcion_firebase = usu.getHabilidad_profesional();
                           // descipcion_trabajo.setText(descripcion_firebase);

                        }else {
                          //  descipcion_trabajo.setText("");
                        }



                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        } else {
            //returnLogin();
        }


    }




    @Override
    public void onStart() {
        super.onStart();

        if (adapter != null) {

            adapter.startListening();
        }



    }

    @Override
    public void onStop() {
        super.onStop();

        if (adapter != null) {

            adapter.stopListening();
        }



    }

    @Override
    public void onResume() { //aqui recuperamos los datos de firebase
        super.onResume();
        /*
        if (adapter_hoteles_cercanos != null) {

            adapter_hoteles_cercanos.startListening();
        }

         */

    }
}
