package com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Reserva_cosmos;
import com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra.Adapter_normal_lista_productos;
import com.cosmosapp.UsersCosmos.holder.Holder_pedidos;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class Fragmento_Domicilios extends Fragment {

    RecyclerView recicler_pedidos;
    TextView vaciardomicilios;
   // Adapter_PedidosFirestore adapter_pedidosFirestore;
    FirestoreRecyclerAdapter<Reserva_cosmos, Holder_pedidos> adapter;

    public Fragmento_Domicilios() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fragmento__domicilios, container, false);
        recicler_pedidos=(RecyclerView)view.findViewById(R.id.recicler_domicilio_recibidos);
        vaciardomicilios=(TextView) view.findViewById(R.id.eliminardomicilioslista);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
      //  Query query=db.collection(Constantes.Factura).document(Constantes.Vendedor).collection(Usuario_DAO.getInstance().getKeyUsuario())
       Query query=  db.collection(Constantes.Reservaciones_usuario)
               .document(Usuario_DAO.getInstance().getKeyUsuario()).collection(Constantes.Factura)

               .orderBy("timestamp", Query.Direction.DESCENDING).limitToLast(25);
      //  .orderBy("timestamp", Query.Direction.DESCENDING);
              // .orderBy("timestamp");



        FirestoreRecyclerOptions<Reserva_cosmos> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Reserva_cosmos>().setQuery(query , Reserva_cosmos.class).build();

        adapter=new FirestoreRecyclerAdapter<Reserva_cosmos, Holder_pedidos>(firestoreRecyclerOptions) {
            @Override
            protected void onBindViewHolder(@NonNull Holder_pedidos holder, int position, @NonNull final Reserva_cosmos model) {
                holder.getEliminar().setVisibility(View.GONE);
                holder.getAsignar_profesional().setVisibility(View.GONE);
                holder.getCompletar_serv().setVisibility(View.GONE);

               // Glide.with(holder.itemView.getContext()).load(Constantes.URL_foto_por_defecto_usuario ).into(holder.getFotousuario());


                if (model.getTimestamp()!=null) {//codigo del pedido y time
                    holder.getCodigofactura().setText("codigo:"+ model.getTimestamp());
                }

                if (model.getNombre_cliente()!=null) {
                    model.getNombre_cliente();
                    holder.getInfo_user().setText(model.getNombre_cliente());
                }



                holder.getHora().setText(model.getFecha_reservacion());

                holder.getInfo_user().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View view) {


                        AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                        builder.setTitle("Cliente");
                        builder.setIcon(R.mipmap.ic_launcher);
                        builder.setMessage(
                                "hora pedido : " + model.getFecha_reservacion()+"\n"
                                        +"nombre : " + model.getNombre_cliente()+"\n"
                                        +"Telefono : " + model.getTelefono()+"\n"
                                        +"direccion : " + model.getDireccion()+"\n"
                                     //   +"productos : " + model.getListservices().size()+"\n"
                                        +"valor de compra  : " + model.getTotal_int()+"\n"
                        );
                        builder.setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        //enviar notificacion




                                    }
                                });
                        //  AlertDialog dialog = builder.create();
                        builder.create();
                        builder.show();
//////////////







                    }
                });
                //revisa el domicilio
                holder.getDomicilio().setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (model.getListservices().size()>0) {


                            //   final   FragmentManager fragmentManager=getfragmentmanager;
                            //   Fragment_verlista_productos_pedidos fragment_verlista_productos_pedidos=new Fragment_verlista_productos_pedidos();
                            // fragment_verlista_productos_pedidos.show();
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                            LayoutInflater inflater = LayoutInflater.from(view.getContext());
                            // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();
                            View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null);

                            RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                            TextView texto_dialo=(TextView)dialogView.findViewById(R.id.numero_productoslista);
                            EditText editText_nota=(EditText)dialogView.findViewById(R.id.notacliente);
                            TextView mostrartotal=(TextView)dialogView.findViewById(R.id.mostrartotal_fac);
                            TextView completar_reserva=(TextView)dialogView.findViewById(R.id.completarreserva);
                            final EditText   fecha_cita_reserva=(EditText)dialogView. findViewById(R.id.fecha_cita_reserva);
                            final EditText hora=(EditText) dialogView.findViewById(R.id.hora_reservacion);

                            builder.setView(dialogView);

                            editText_nota.setVisibility(View.GONE);
                            completar_reserva.setVisibility(View.GONE);
                            // mostrartotal.setText(model.getReserva_cosmos().getTotal_int());
                            //  int num = list_useron.size();
                            //arreglo de textos
                            editText_nota.setEnabled(false);
                            fecha_cita_reserva.setEnabled(false);
                            hora.setEnabled(false);
                            fecha_cita_reserva.setText("Fecha reserva "+ model.getFecha_servicios());
                            hora.setText("hora : "+model.getFecha_reservacion());




                            //   rv.setLayoutManager(new LinearLayoutManager(view.getContext(),LinearLayoutManager.HORIZONTAL,false));
                            GridLayoutManager gridLayoutManager = new GridLayoutManager(view.getContext(), 2);
                            rv.setLayoutManager(gridLayoutManager);
                            Adapter_normal_lista_productos adapter = new Adapter_normal_lista_productos(view.getContext(), model.getListservices());
                            rv.setAdapter(adapter);

                            //


                            AlertDialog dialog = builder.create();

                            builder.create();
                            builder.show();
                        }else {
                            Toast.makeText(view.getContext(), "error en servicios contactar cliente", Toast.LENGTH_LONG).show();

                        }




                    }
                });




            }

            @NonNull
            @Override
            public Holder_pedidos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_estadodomicilio, parent, false);

                return  new Holder_pedidos(view);
            }
        };




        adapter.notifyDataSetChanged();

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
        recicler_pedidos.setLayoutManager(gridLayoutManager);
        adapter.startListening();
        recicler_pedidos.setAdapter(adapter) ;


        vaciardomicilios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                builder.setTitle("Eliminar registros");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("se elimianra todos los registros actuales");
                builder.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                //enviar notificacion





                            }
                        });
                //  AlertDialog dialog = builder.create();
                builder.create();
                builder.show();
//////////////

            }
        });

        return view;

    }

    public  String fecha_enviado_mensaje(){

        // Date date=new Date();
        //PrettyTime prettyTime=new PrettyTime(new Date(), Locale.getDefault()); //obtiene el formato del dispositivo local
        //return  prettyTime.format(date);

        // Long cdigoHora=mensajeList.get(position).getHora();
        // al pedir un ong para funcionar simplemente enviamos el lon getCreatedTimestamp()
        Date d=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
        return sdf.format(d);
    }
    public String timestamp(){

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        return ts;
    }
    @Override
    public void onStart() { //cuando salgamos d ela aplicacion y entremos, se cargeue el adaptador
        super.onStart();
        if (adapter != null) {

            adapter.startListening();
        }

        // adapter_recicler_clientes.startListening();//adaotador inicia

    }


    @Override
    public void onStop() {
        super.onStop();

        if (adapter!= null) {

            adapter.stopListening();
            super.onStop();
        }
        //adapter_recicler_clientes.stopListening(); //adaptador se detienen
    }

    @Override
    public void onResume() { //aqui recuperamos los datos de firebase
        super.onResume();
        if (adapter != null) {

            adapter.startListening();
        }
    }
}