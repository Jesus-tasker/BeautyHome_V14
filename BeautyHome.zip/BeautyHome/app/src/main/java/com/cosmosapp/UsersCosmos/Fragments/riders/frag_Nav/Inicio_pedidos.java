package com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Adapter.Adapter_Inicio_firestore;
import com.cosmosapp.UsersCosmos.Adapter.Adapter_fire_servicio;
import com.cosmosapp.UsersCosmos.Adapter.Adapterr_norml_productos1;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Map_location;
import com.cosmosapp.UsersCosmos.Entidades_fire.Producto;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Reserva_completada;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Reserva_cosmos;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Users_On;
import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;
import com.cosmosapp.UsersCosmos.Entidades_fire.pedidos.Productos_carrito;
import com.cosmosapp.UsersCosmos.Fragments.riders.Frag_extra.Adapter_normal_lista_productos;
import com.cosmosapp.UsersCosmos.Navegador.GeoHash;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.actividades.Perfil_Usuario;
import com.cosmosapp.UsersCosmos.holder.Holder_pedidos;
import com.cosmosapp.UsersCosmos.holder.Usuarios_cercanos_holder;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;
import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

/**
 * A simple {@link Fragment} subclass.
 */
public class Inicio_pedidos extends Fragment {

    final List<Productos_carrito> listmenu_productos=new ArrayList<>();
    RecyclerView recyclerView_usuarios_cercanos, recyclerView_usuarios2;
    View vista_btoton_agregar; //esta vista es el qeu me permitira accionar el boton en el fragment
    ImageView agregar_cliente_frag;
    String nombre_uso_de_firebase;
    String cargo_usu_firebase;
    CircleImageView foto_perfil_usuario_cv;
    DatabaseReference databaseReference_clientes;
    TextView nombre_usu, busco;
    ImageView localizacion;


    //estos son los elementos del reciclerdatosd del usuario nombre y foto
    private RecyclerView recyclerView;

    //locacion en firebase en tiempo real
    private FusedLocationProviderClient fusedLocationProviderClient;
    DatabaseReference reference_localizacion;

    private String vp1, Vp2, vp3;


    double latitud;
    double longitud;
    String telefono;
    String especialidad;
    int MY_PERMISSIONS_REQUEST_READ_CONTACTS; //int para permisos de localizacion

    private long update_interval = 10 * 1000;   // 100 segundos
    private long FASTEST_INTERVAL = 2000;   //2 segundos

    private LocationRequest mLocationRequest;
    String fotorecuperada;
    String hash_traido;
    //shared preferece guardare la foto del usuario y su nombre

    Adapter_Inicio_firestore  adapter_inicio_firestore;
    Adapterr_norml_productos1 adapterr_norml_productos1;
    List<Servicio_p1> servicioP1List;
    Adapter_fire_servicio adapter_fire_servicio;


    //prueba1 serv_1 traer del adapter a al lista
    List<Servicio_p1>lista_serv_p1=new ArrayList<>();
    TextView comprar;

    List<Reserva_completada> list_reservacion=new ArrayList<>();
    FirestoreRecyclerAdapter<Reserva_completada, Holder_pedidos> adapter;

    Button cancelar_servicio_btn;
    Boolean tiene_domicilio;
    TextView ultima_reservacion;


    public Inicio_pedidos() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View visra = inflater.inflate(R.layout.inicio_pedidos, container, false);

        reference_localizacion = FirebaseDatabase.getInstance().getReference().child(Constantes.Nodo_localizacion);

        fusedLocationProviderClient = getFusedLocationProviderClient(getContext());
        cargarinfo_usu();
        startLocationUpdates(); //location
        //obtenerubicacion(); //aveces funciona  tratare de traerlo con shared preference


        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
        String mylatitud = prefs.getString("latitud_string", "defaultStringIfNothingFound");
        String mylongitude = prefs.getString("longitud_string", "defaultStringIfNothingFound");

        final double latitude_1 = Double.longBitsToDouble(prefs.getLong("Latitude_1", 0));
        double longitude_1 = Double.longBitsToDouble(prefs.getLong("longitude_1", 0));

        String hashbund = prefs.getString("geohash", "no se escribio");
        hash_traido = hashbund;

        latitud = latitude_1;
        longitud = longitude_1;


        foto_perfil_usuario_cv = (CircleImageView) visra.findViewById(R.id.foto_perfil_perfil);

        nombre_usu = (TextView) visra.findViewById(R.id.nombre_perefil);
        busco = (TextView) visra.findViewById(R.id.cargo);
        recyclerView_usuarios_cercanos = visra.findViewById(R.id.lista_usuarioscercanos_rv); //referencia del recicler view
        // recyclerView_clientes.setLayoutManager(new LinearLayoutManager(getContext()));
        localizacion = (ImageView) visra.findViewById(R.id.ubicacion);
        /////////////////////
        comprar=(TextView) visra.findViewById(R.id.comprar);
        cancelar_servicio_btn=(Button)visra.findViewById(R.id.cancelarpedido);

        ultima_reservacion=(TextView)visra.findViewById(R.id.ultima_reservacion_texto);


        comprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                LayoutInflater inflater=LayoutInflater.from(view.getContext());
                // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();
                View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null);
                builder.setView(dialogView);

                RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                TextView texto_dialo=(TextView)dialogView.findViewById(R.id.numero_productoslista);
                int num=lista_serv_p1.size();
                texto_dialo.setText("Productos:  "+num);

                //   rv.setLayoutManager(new LinearLayoutManager(view.getContext(),LinearLayoutManager.HORIZONTAL,false));
                GridLayoutManager gridLayoutManager = new GridLayoutManager(view.getContext(), 2);
                rv.setLayoutManager(gridLayoutManager);
                Adapter_normal_lista_productos adapter = new Adapter_normal_lista_productos(view.getContext(),lista_serv_p1);
                rv.setAdapter(adapter);

                //


                AlertDialog dialog = builder.create();

                builder.create();
                builder.show();



            }
        });


/////////////////////////////
        //para obtener la localizacion en tiempo real
        reference_localizacion = FirebaseDatabase.getInstance().getReference().child(Constantes.Nodo_localizacion);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getContext());



        foto_perfil_usuario_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(), Perfil_Usuario.class);
                startActivity(intent);
            }
        });
        localizacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                builder.setTitle("Buscar en mi zona");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Revisa tu zona y activa tu estado para recibir pedidos ");
                builder.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                             //   Intent i=new Intent(getActivity(), Maps2.class);

                               // startActivity(i);





                            }
                        }).setNegativeButton("CANCELAR",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(getContext(), "cancelado ", Toast.LENGTH_LONG).show();
                                //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                            }
                        });
                //  AlertDialog dialog = builder.create();
                builder.create();
                builder.show();



            }
        });



        mostrar_Ultima_reservacion_cliente();



     //
     //    cargarlistadeproductosavender(); //funcion  l perfeccion
     //  litdepreciosdtbse(); //igul no gurd l segund list

        //list//////

       //  cargrproductos_firetorev2(); //FAVORITO pPARA GUARDAR LISTAS EN FIRESTORE
     //   descrgrservicios();
     //   cargarusuariosFirestore();




        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
        recyclerView_usuarios_cercanos.setLayoutManager(gridLayoutManager);
          adapter.startListening();
         recyclerView_usuarios_cercanos.setAdapter(adapter);
         adapter.notifyDataSetChanged();

    //    adapterr_norml_productos1=new Adapterr_norml_productos1(getContext(),servicioP1List);
      //  recyclerView_usuarios_cercanos.setAdapter(adapterr_norml_productos1);


     //  adapter_inicio_firestore.startListening();
      // recyclerView_usuarios_cercanos.setAdapter(adapter_inicio_firestore);
       //adapter_inicio_firestore.notifyDataSetChanged();

        // adapter_user_firestore.startListening();
       // recyclerView_usuarios_cercanos.setAdapter(adapter_user_firestore);
        //adapter_user_firestore.notifyDataSetChanged();




        return visra;


    }



/*
 private  void cargrproductosv2(){
        String  categoria="Peluqueri Hombre";

     FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
     Servicio_p1 servicio_p1=new Servicio_p1();
     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
              .setValue(new Servicio_p1(timestamp(),categoria,"Corte Hombre","101","15000",15000));
     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
             .setValue(new Servicio_p1(timestamp(),categoria,"Barberia","101","15000",15000));

     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
             .setValue(new Servicio_p1(timestamp(),categoria,"Tinturado Hombre","102","80000",80000));
     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
             .setValue(new Servicio_p1(timestamp(),categoria,"iluminaciones Hombre","102","100000",100000));

     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
             .setValue(new Servicio_p1(timestamp(),categoria,"keratina hombre","102","100000",100000));
     firebaseDatabase.getReference().child(Constantes.Catalogo_productos).push()
             .setValue(new Servicio_p1(timestamp(),categoria,"Corte dama","201","15000",15000));

 }

    private  void cargrproductos_firetorev2(){
        String  categoria="Peluueri Hombre";

      FirebaseFirestore db=FirebaseFirestore.getInstance();
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"Corte Hombre","101","15000",15000)));
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"Barberia","101","15000",15000)));
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"Tinturado Hombre","102","80000",80000)));
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"iluminaciones Hombre","102","100000",100000)));
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"keratina hombre","102","100000",100000)));
        db.collection(Constantes.Productos).add((new Servicio_p1(timestamp(),categoria,"Corte dama","201","15000",15000)));


    }


 */
    private void cargarlistadeproductosavender() {
        List<Productos_carrito>carritoList=new ArrayList<>();

        String ctegori1_Pelueurihombre="peluueria hombre";
        //peluueri hombre
        List<Producto>listpeluueri_hombre= new ArrayList<>();

        Producto cortehombre=new Producto();//p1
        cortehombre.setCodigo("101");
        cortehombre.setNombre("Corte Hombre");
        cortehombre.setPrecio("15.000");
        cortehombre.setPrecio2_int(15000);
        cortehombre.setCateforia_producto("100");
        listpeluueri_hombre.add(cortehombre);//gregdo_pelueurihombre

        Producto brberia=new Producto();///p2
        cortehombre.setCodigo("102");
        cortehombre.setNombre("Brberia");
        cortehombre.setPrecio("15.000");
        cortehombre.setPrecio2_int(15000);
        cortehombre.setCateforia_producto("100");
        listpeluueri_hombre.add(brberia);

        Productos_carrito menu_cosmos_hombre=new Productos_carrito(); //crrito1
        menu_cosmos_hombre.setCodigo("100");
        menu_cosmos_hombre.setNombre("Peluueria Hombre");
        menu_cosmos_hombre.setPrecio("15.000");

      //  menu_cosmos_hombre.setProductolist(listpeluueri_hombre);

        carritoList.add(menu_cosmos_hombre);

        FirebaseFirestore db=FirebaseFirestore.getInstance();
        db.collection(Constantes.Catalogo_productos).add(menu_cosmos_hombre);



        /*
        //color hombre
        List<Producto>color_hombre_list= new ArrayList<>();

        Producto tinturdo=new Producto();//p1
        cortehombre.setCodigo("201");
        cortehombre.setNombre("Tinturdo");
        cortehombre.setPrecio("80.000");
        cortehombre.setPrecio2_int(80000);
        cortehombre.setCateforia_producto("200");
        color_hombre_list.add(tinturdo);

        Producto iluminciones=new Producto();//p1
        cortehombre.setCodigo("201");
        cortehombre.setNombre("Iluminciones");
        cortehombre.setPrecio("100.000");
        cortehombre.setPrecio2_int(100000);
        cortehombre.setCateforia_producto("200");
        color_hombre_list.add(iluminciones);

        Producto kertin_hombre=new Producto();//p1
        cortehombre.setCodigo("201");
        cortehombre.setNombre("Kertina");
        cortehombre.setPrecio("100.000");
        cortehombre.setPrecio2_int(100000);
        cortehombre.setCateforia_producto("200");
        color_hombre_list.add(iluminciones);



        Productos_carrito color_list_hombre=new Productos_carrito(); //crrito1
        menu_cosmos_hombre.setCodigo("100");
        menu_cosmos_hombre.setNombre("Profesionl Hombre");
        menu_cosmos_hombre.setPrecio("80.000");
        menu_cosmos_hombre.setProductolist(color_hombre_list);
        ////////////////

        carritoList.add(color_list_hombre);
        FirebaseFirestore db1=FirebaseFirestore.getInstance();
        db1.collection(Constantes.Catalogo_productos).add(color_list_hombre)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                    }
                });


 */

        // FirebaseFirestore db=FirebaseFirestore.getInstance();
        //db.collection(Constantes.Catalogo_productos).add(carritoList);


                //gurd uno  uno los p`roductos
                for (int i=0;i<carritoList.size();i++){

                   // FirebaseFirestore db=FirebaseFirestore.getInstance();
                    //db.collection(Constantes.Catalogo_productos).add(carritoList.get(i));



                }



//list de crrito de comprs


        //tinturhombre
        List<Producto>tintur_hombre= new ArrayList<>();
        Producto tinturdohombre=new Producto();
        cortehombre.setCodigo("201");
        cortehombre.setNombre("Tinturdo Hombre");
        cortehombre.setPrecio("80.000");
        cortehombre.setPrecio2_int(15000);
        cortehombre.setCateforia_producto("200");
    }

    public  void mostrar_Ultima_reservacion_cliente(){
        //cuando el admin agrege el progfesional traera esta lista correspondiente
        FirebaseFirestore db = FirebaseFirestore.getInstance();

       //  Query query=db.collection(Constantes.Factura).document(Constantes.Vendedor).collection(Usuario_DAO.getInstance().getKeyUsuario())
        final FirebaseFirestore lista_workers = FirebaseFirestore.getInstance();

        Query query_workers= lista_workers.collection(Constantes.Reserva_completa)
                .document(Constantes.Nodo_Usuario_clients_uso2).collection(Usuario_DAO.getInstance().getKeyUsuario().trim())
                .orderBy("timestamp", Query.Direction.ASCENDING).limitToLast(1);

        //no sera neceario con lista mejor directo
        query_workers.get() .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Reserva_completada mireservacion=document.toObject(Reserva_completada.class);
                        if (mireservacion!=null){

                            list_reservacion.add(mireservacion);
                        }

                        Log.d(TAG, document.getId() + " => " + document.getData());
                    }
                } else {
                    Log.d(TAG, "Error getting documents: ", task.getException());
                }
            }
        });

        //  .orderBy("timestamp", Query.Direction.DESCENDING);


        if (list_reservacion.size()>-0){
            cancelar_servicio_btn.setVisibility(View.VISIBLE);
        }else {
            cancelar_servicio_btn.setVisibility(View.INVISIBLE);
        }



        FirestoreRecyclerOptions<Reserva_completada> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Reserva_completada>().setQuery(query_workers , Reserva_completada.class).build();

        adapter=new FirestoreRecyclerAdapter<Reserva_completada, Holder_pedidos>(firestoreRecyclerOptions) {
            @Override
            protected void onBindViewHolder(@NonNull final Holder_pedidos holder, int position, @NonNull final Reserva_completada model) {

                if (model.getServicio_terminado().equals(false)) {

                    if (model.getServicio_terminado()!=false&&list_reservacion.size()>0){
                      //  String servicio_on="Sin recervacion existente";
                        //ultima_reservacion.setText(servicio_on);

                        holder.itemView.setVisibility(View.GONE);

                    }

                    if (model.getTimestamp() != null) {//codigo del pedido y time
                        holder.getCodigofactura().setText("codigo:" + model.getTimestamp() + "\n" + "fecha: " + model.getReserva_cosmos().getFecha_servicios());
                    }
                    if (model.getReserva_cosmos().getNombre_cliente() != null) {
                        holder.getInfo_user().setText(model.getReserva_cosmos().getNombre_cliente());
                    }
                    if (model.getReserva_cosmos().getFotografia() != null) {
                        Glide.with(holder.itemView.getContext()).load(model.getReserva_cosmos().getFotografia()).into(holder.getFotousuario());


                    } else {
                        Glide.with(holder.itemView.getContext()).load(Constantes.URL_foto_por_defecto_usuario).into(holder.getFotousuario());

                    }
                    holder.getHora().setText(model.getReserva_cosmos().getFecha_reservacion());

                    holder.getInfo_user().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(final View view) {


                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                            builder.setTitle("Cliente");
                            builder.setIcon(R.mipmap.ic_launcher);
                            builder.setMessage(
                                    "hora pedido : " + model.getReserva_cosmos().getFecha_reservacion() + "\n"
                                            + "nombre : " + model.getReserva_cosmos().getNombre_cliente() + "\n"
                                            + "Telefono : " + model.getReserva_cosmos().getTelefono() + "\n"
                                            + "direccion : " + model.getReserva_cosmos().getDireccion() + "\n"
                                            //   +"productos : " + model.getListservices().size()+"\n"
                                            + "valor de compra  : " + model.getReserva_cosmos().getTotal_int() + "\n"
                            );
                            builder.setPositiveButton("OK",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            //enviar notificacion


                                        }
                                    }).setNegativeButton("CANCELAR",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Toast.makeText(view.getContext(), "cancelado ", Toast.LENGTH_LONG).show();
                                            //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                        }
                                    });
                            //  AlertDialog dialog = builder.create();
                            builder.create();
                            builder.show();
//////////////


                        }
                    });
                    //revisa el domicilio
                    holder.getDomicilio().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            if (model.getReserva_cosmos().getListservices() != null) {


                                //   final   FragmentManager fragmentManager=getfragmentmanager;
                                //   Fragment_verlista_productos_pedidos fragment_verlista_productos_pedidos=new Fragment_verlista_productos_pedidos();
                                // fragment_verlista_productos_pedidos.show();
                                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                                LayoutInflater inflater = LayoutInflater.from(view.getContext());
                                // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();
                                View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null);


                                RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                                TextView texto_dialo = (TextView) dialogView.findViewById(R.id.numero_productoslista);
                                EditText editText_nota = (EditText) dialogView.findViewById(R.id.notacliente);
                                TextView mostrartotal = (TextView) dialogView.findViewById(R.id.mostrartotal_fac);
                                TextView completar_reserva = (TextView) dialogView.findViewById(R.id.completarreserva);
                                final EditText fecha_cita_reserva = (EditText) dialogView.findViewById(R.id.fecha_cita_reserva);
                                final EditText hora = (EditText) dialogView.findViewById(R.id.hora_reservacion);

                                builder.setView(dialogView);

                                editText_nota.setVisibility(View.GONE);
                                completar_reserva.setVisibility(View.GONE);
                                // mostrartotal.setText(model.getReserva_cosmos().getTotal_int());
                                //  int num = list_useron.size();
                                //arreglo de textos
                                editText_nota.setEnabled(false);
                                fecha_cita_reserva.setEnabled(false);
                                hora.setEnabled(false);
                                fecha_cita_reserva.setText("Fecha reserva " + model.getReserva_cosmos().getFecha_servicios());
                                hora.setText("hora : " + model.getReserva_cosmos().getFecha_reservacion());


                                int num = model.getReserva_cosmos().getListservices().size();
                                texto_dialo.setText("Productos:  " + num);

                                //   rv.setLayoutManager(new LinearLayoutManager(view.getContext(),LinearLayoutManager.HORIZONTAL,false));
                                GridLayoutManager gridLayoutManager = new GridLayoutManager(view.getContext(), 2);
                                rv.setLayoutManager(gridLayoutManager);
                                Adapter_normal_lista_productos adapter = new Adapter_normal_lista_productos(view.getContext(), model.getReserva_cosmos().getListservices());
                                rv.setAdapter(adapter);

                                //


                                AlertDialog dialog = builder.create();

                                builder.create();
                                builder.show();
                            } else {
                                Toast.makeText(view.getContext(), "error en servicios contactar cliente", Toast.LENGTH_LONG).show();

                            }


                        }
                    });


                    if (model.getUsers_on_enturno().getNombre_profesional() != null) {

                        holder.getAsignar_profesional().setText(model.getUsers_on_enturno().getNombre_profesional());
                    }
                    holder.getAsignar_profesional().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                            LayoutInflater inflater = LayoutInflater.from(view.getContext());
                            // LayoutInflater inflater2 = view.getLayoutParams()getActivity().getLayoutInflater();

                            View dialogView = (View) inflater.inflate(R.layout.fragment_verlista_productos_pedidos, null);
                            builder.setView(dialogView);

                            final List<Users_On> list_useron = new ArrayList<>();
                            list_useron.add(model.getUsers_on_enturno());


                            RecyclerView rv = (RecyclerView) dialogView.findViewById(R.id.rv_listaproductos);
                            TextView texto_dialo = (TextView) dialogView.findViewById(R.id.numero_productoslista);
                            EditText editText_nota = (EditText) dialogView.findViewById(R.id.notacliente);
                            TextView mostrartotal = (TextView) dialogView.findViewById(R.id.mostrartotal_fac);
                            TextView completar_reserva = (TextView) dialogView.findViewById(R.id.completarreserva);
                            final EditText fecha_cita_reserva = (EditText) dialogView.findViewById(R.id.fecha_cita_reserva);
                            final EditText hora = (EditText) dialogView.findViewById(R.id.hora_reservacion);

                            builder.setView(dialogView);

                            editText_nota.setVisibility(View.GONE);
                            completar_reserva.setVisibility(View.GONE);
                            int num = list_useron.size();
                            //arreglo de textos
                            editText_nota.setEnabled(false);
                            fecha_cita_reserva.setEnabled(false);
                            hora.setEnabled(false);

                            //  editText_nota.setText("Servicios");
                            //  mostrartotal.setText(model.getReserva_cosmos().getTotal_int());
                            mostrartotal.setVisibility(view.GONE);
                            fecha_cita_reserva.setText("Fecha reserva " + model.getReserva_cosmos().getFecha_servicios());
                            hora.setText("hora : " + model.getReserva_cosmos().getFecha_reservacion());

                            texto_dialo.setText("Personal:  " + model.getUsers_on_enturno().getNombre_profesional());
                            RecyclerView.Adapter<Usuarios_cercanos_holder> adapter_users_on = new RecyclerView.Adapter<Usuarios_cercanos_holder>() {
                                @NonNull
                                @Override
                                public Usuarios_cercanos_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_usuarios_cercanos_info, parent, false);
                                    return new Usuarios_cercanos_holder(view);
                                }

                                @Override
                                public void onBindViewHolder(@NonNull Usuarios_cercanos_holder holder, final int position) {

                                    if (list_useron.get(position).getFotografia() != null) {

                                        Glide.with(getContext()).load(list_useron.get(position).getFotografia()).into(holder.getFoto_perfil_item_usuario());
                                    }

                                    holder.getNombre_cliente_item().setText(list_useron.get(position).getNombre_profesional());
                                    holder.getTelefono().setText(list_useron.get(position).getFecha_insertada());


                                    //aqui la idea es enviar el domicilio al cliente y al domicliario al tiempo


                                }

                                @Override
                                public int getItemCount() {
                                    return list_useron.size();
                                }
                            };

                            //   rv.setLayoutManager(new LinearLayoutManager(view.getContext(),LinearLayoutManager.HORIZONTAL,false));
                            GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 1);
                            rv.setLayoutManager(gridLayoutManager);
                            //Adapternormal_users_on adapter = new Adapternormal_users_on(getContext(), list_users_on);

                            rv.setAdapter(adapter_users_on);

                            //


                            builder.create();
                            builder.show();


                        }
                    });


                    holder.getEliminar().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                            builder.setTitle("cancelar Servicio");
                            builder.setIcon(R.mipmap.ic_launcher);
                            builder.setMessage(
                                    "hora pedido : " + model.getReserva_cosmos().getFecha_reservacion() + "\n"
                                            + "nombre : " + model.getReserva_cosmos().getNombre_cliente() + "\n"

                                            + "valor de compra  : " + model.getReserva_cosmos().getTotal_int() + "\n"
                            );
                            builder.setPositiveButton("OK",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            //esta es la query para traer el domicio
                                            /*  Query query_workers= lista_workers.collection(Constantes.Reserva_completa)
                .document(Constantes.Nodo_Usuario_clients_uso2).collection(Usuario_DAO.getInstance().getKeyUsuario().trim())
                .orderBy("timestamp", Query.Direction.ASCENDING).limitToLast(1);*/
                                            String eliminado = "Eliminado";


                                            //cone sto la idea es traer el ultimo dato
                                            Reserva_completada reserva_completada_V3=new Reserva_completada();

                                            reserva_completada_V3=list_reservacion.get(0);
                                            reserva_completada_V3.setServicio_terminado(true);
                                            //PRO PRUEBAS DEBO TRABAJAR CON ESTE SISTEMA  PARA ACTUALIZAR LA ULTIMA
                                            //1.USuario cliente- la idea es que con esto agrega una ultima reservacion vacia

                                            db.collection(Constantes.Reserva_completa).document(Constantes.Nodo_Usuario_clients_uso2)
                                                    .collection(Usuario_DAO.getInstance().getKeyUsuario().trim()).add(reserva_completada_V3);



                                            //2. avisar al estilista del servicio cancelado
                                            db.collection(Constantes.Reserva_completa).document(Constantes.Nodo_Rooms)
                                                    .collection(model.getUsers_on_enturno().getKey_uid().trim()).add(reserva_completada_V3);


                                            db.collection(Constantes.Reserva_completa)
                                                    .document(Constantes.servicios_cancelados)
                                                    .collection(model.getUsers_on_enturno().getKey_uid().trim()).add(reserva_completada_V3);


                                            //orifginales, mo funcionan por que no me cargaria el query
                                            //  db.collection(Constantes.Reserva_completa).document(Usuario_DAO.getInstance().getKeyUsuario()).delete();//eliminr en el usuario
                                            // db.collection(Constantes.Reserva_completa).document(model.getUsers_on_enturno().getKey_uid()).delete();//eliminar del estilista

                                            RequestQueue myrequest = Volley.newRequestQueue(getContext());
                                            JSONObject jsonObject = new JSONObject();
                                            try {
                                                String token = model.getUsers_on_enturno().getNotifiuid_profesional();
                                                jsonObject.put("to", token);

                                                JSONObject notificaciojn = new JSONObject();
                                                notificaciojn.put(Constantes.Titulo, "Reservacion eliminada");
                                                notificaciojn.put(Constantes.Detalle, "Reservacion   " + nombre_uso_de_firebase);
                                                notificaciojn.put(Constantes.tiponotificaion, "corazon");
                                                notificaciojn.put("uid", "");
                                                notificaciojn.put("fotouser", "");
                                                notificaciojn.put("nombre", nombre_uso_de_firebase);
                                                //  notificaciojn.put("notifi2", notifiuid_cliente);

                                                Log.e("TAG", "token adapter   " + token);


                                                jsonObject.put("data", notificaciojn);
                                                String URL = "https://fcm.googleapis.com/fcm/send";
                                                //  String URL2="https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

                                                //envia los requerimientos jsobobject //methdo,url/objetos y escuchas y error de escucha
                                                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL, jsonObject, null, null) {

                                                    @Override
                                                    public Map<String, String> getHeaders() {
                                                        Map<String, String> header = new Hashtable<>();
                                                        header.put("content-type", "application/json");
                                                        header.put("authorization", "key=" + Constantes.nube_key);
                                                        //firebaseconsole/consfiguracion//cloudmessenger/
                                                        return header;
                                                    }
                                                };

                                                myrequest.add(request);

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            Toast.makeText(getContext(), "Reservacion eliminada", Toast.LENGTH_SHORT).show();

                                            //enviar notificacion


                                        }
                                    }).setNegativeButton("CANCELAR",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Toast.makeText(getContext(), "cancelado ", Toast.LENGTH_LONG).show();
                                            //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                        }
                                    });
                            //  AlertDialog dialog = builder.create();
                            builder.create();
                            builder.show();
//////////////

                        }
                    });
                    holder.getCompletar_serv().setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());


                            builder.setTitle("Servicio Completado");
                            builder.setIcon(R.mipmap.ic_launcher);
                            builder.setMessage(
                                    "Servicio realizado con exito! " + "\n"+ "\n"
                                            + "hora pedido : " + model.getReserva_cosmos().getFecha_reservacion() + "\n"
                                            + "nombre : " + model.getReserva_cosmos().getNombre_cliente() + "\n"
                                            + "valor de compra  : " + model.getReserva_cosmos().getTotal_int() + "\n"
                            );
                            builder.setPositiveButton("Confirmar",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                            ProgressDialog progressDialog=new ProgressDialog(getContext());
                                            progressDialog.setMessage("eliminando");
                                            progressDialog.show();

                                            list_reservacion=new ArrayList<>();
                                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                                            query_workers.get() .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                                    if (task.isSuccessful()) {
                                                        for (QueryDocumentSnapshot document : task.getResult()) {
                                                            Reserva_completada mireservacion=document.toObject(Reserva_completada.class);
                                                            if (mireservacion!=null){

                                                                list_reservacion.add(mireservacion);
                                                            }

                                                            Log.d(TAG, document.getId() + " => " + document.getData());
                                                        }
                                                    } else {
                                                        Log.d(TAG, "Error getting documents: ", task.getException());
                                                    }
                                                }
                                            });
                                            //cone sto la idea es traer el ultimo dato
                                            Reserva_completada reserva_completada_V3=new Reserva_completada();

                                            reserva_completada_V3=list_reservacion.get(0);
                                            reserva_completada_V3.setServicio_terminado(true);

                                            //PRO PRUEBAS DEBO TRABAJAR CON ESTE SISTEMA  PARA ACTUALIZAR LA ULTIMA
                                            //1.USuario cliente- la idea es que con esto agrega una ultima reservacion vacia

                                            //1.usuario cliente
                                            db.collection(Constantes.Reserva_completa).document(Constantes.Nodo_Usuario_clients_uso2)
                                                    .collection(Usuario_DAO.getInstance().getKeyUsuario().trim()).add(reserva_completada_V3);



                                            //2. avisar al estilista del servicio completo
                                            db.collection(Constantes.Reserva_completa).document(Constantes.Nodo_Rooms)
                                                    .collection(model.getUsers_on_enturno().getKey_uid().trim()).add(reserva_completada_V3);


                                            //3.avisar al salon que el cervicio esta completo
                                            db.collection(Constantes.Reserva_completa)
                                                    .document(Constantes.Servicios_completados)
                                                    .collection(model.getUsers_on_enturno().getKey_uid().trim()).add(reserva_completada_V3);


                                                    /*
                                                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                                                    db.collection(Constantes.Reservaciones_usuario).document(Usuario_DAO.getInstance().getKeyUsuario()).collection(Constantes.Factura).add(model.getReserva_cosmos());
                                                    db.collection(Constantes.Reserva_completa).document(Usuario_DAO.getInstance().getKeyUsuario()).delete();
                                                    db.collection(Constantes.Reserva_completa).document(model.getUsers_on_enturno().getKey_uid()).delete();
                                                    db.collection(Constantes.Reservaciones_usuario).document(model.getUsers_on_enturno().getKey_uid()).collection(Constantes.Factura).add(model.getReserva_cosmos());


                                                     */
                                            RequestQueue myrequest = Volley.newRequestQueue(getContext());
                                            JSONObject jsonObject = new JSONObject();
                                            try {
                                                String token = model.getUsers_on_enturno().getNotifiuid_profesional();
                                                jsonObject.put("to", token);

                                                JSONObject notificaciojn = new JSONObject();
                                                notificaciojn.put(Constantes.Titulo, "Servicio competado");
                                                notificaciojn.put(Constantes.Detalle, "Gracias por la atencion    " + nombre_uso_de_firebase);
                                                notificaciojn.put(Constantes.tiponotificaion, "corazon");
                                                notificaciojn.put("uid", "");
                                                notificaciojn.put("fotouser", "");
                                                notificaciojn.put("nombre", nombre_uso_de_firebase);
                                                //  notificaciojn.put("notifi2", notifiuid_cliente);

                                                Log.e("TAG", "token adapter   " + token);


                                                jsonObject.put("data", notificaciojn);
                                                String URL = "https://fcm.googleapis.com/fcm/send";
                                                //  String URL2="https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

                                                //envia los requerimientos jsobobject //methdo,url/objetos y escuchas y error de escucha
                                                JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL, jsonObject, null, null) {

                                                    @Override
                                                    public Map<String, String> getHeaders() {
                                                        Map<String, String> header = new Hashtable<>();
                                                        header.put("content-type", "application/json");
                                                        header.put("authorization", "key=" + "AAAAIOH5QNo:APA91bGA2L7RnnA3cqv5WstLWoped63inBOQWTYLCMm0TSwFV0u805VeCmpQnlkLP5TX78esinfIblRL3VniviFerwQDLy4MFaDS-bTWoVl-2dS4EixZrlajcUTNw2yvu-MPryd1NaCf");
                                                        //firebaseconsole/consfiguracion//cloudmessenger/
                                                        return header;
                                                    }
                                                };

                                                myrequest.add(request);

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            Toast.makeText(getContext(), "Reservacion eliminada", Toast.LENGTH_SHORT).show();

                                            Intent i = new Intent(getContext(), Navegdor.class);
                                            //enviar notificacion

                                            startActivity(i);

                                        }
                                    }).setNegativeButton("CANCELAR",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Toast.makeText(getContext(), "cancelado ", Toast.LENGTH_LONG).show();
                                            //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                        }
                                    });
                            //  AlertDialog dialog = builder.create();
                            builder.create();
                            builder.show();

                        }
                    });

                }




            }

            @NonNull
            @Override
            public Holder_pedidos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_estadodomicilio, parent, false);

                return  new Holder_pedidos(view);
            }
        };

        adapter.notifyDataSetChanged();


    }

    public String timestamp(){

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        return ts;
    }

    private void cargarusuariosFirestore() {

        Map_location map_location = new Map_location();
        map_location.setLatitud(latitud);
        map_location.setLongitud(longitud);

        double meridiano_tierra = 40007860;
        double radio = 6371; ////radio d ela tierra en kl

        GeoHash geoHash = GeoHash.fromLocation(map_location, 6);
        GeoHash norte = geoHash.getNorthernNeighbour();
        GeoHash geosur = geoHash.getSouthernNeighbour();
        GeoHash geoeste = geoHash.getEasternNeighbour();
        GeoHash geo_oeste = geoHash.getWesternNeighbour();

        //probadno
        GeoHash[] geoHash1 = geoHash.getAdjacent();

        String adyacente = geoHash1.toString().trim();

        String ubicacion_hash = geoHash.toString();//"d2g7ds"       "d2g7ds5"
        String nor = norte.toString().trim(); //6char "d2g7dt"      //7char d2g7d27
        String sur = geosur.toString().trim(); //"d2g7de"
        String weast = geoeste.toString().trim(); //d2g7du
        String oeste = geo_oeste.toString().trim(); //d2g7dk
        String end = "~";


        String s=timestamp();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
       // db.collection(Constantes.Catalogo_productos); //correccion pedidos
        com.google.firebase.firestore.Query query2 = db.collection(Constantes.Catalogo_productos)
                .whereGreaterThan("codigo","1");//.startAt( ubicacion_hash); //no funciono

        FirestoreRecyclerOptions<Productos_carrito> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Productos_carrito>().setQuery(query2, Productos_carrito.class).build();


        adapter_inicio_firestore = new Adapter_Inicio_firestore(firestoreRecyclerOptions);


        adapter_inicio_firestore.notifyDataSetChanged();

        // Toast.makeText(getActivity(), "hash_iniicio: "+ubicacion_hash, Toast.LENGTH_LONG).show();

        //Toast.makeText(Busqeuda_Producto_p1.this, ubicacion,Toast.LENGTH_SHORT).show();

/*
        FirebaseFirestore firestore_forrecicler = FirebaseFirestore.getInstance();
        // FirebaseFirestore db=FirebaseFirestore.getInstance();
        //db.collection(Constantes.Catalogo_productos).document().collection(Constantes.Productos_total)
        //  com.google.firebase.firestore.Query query = firestore_forrecicler.collection(Constantes.Users).document(Constantes.cliente).;

        com.google.firebase.firestore.Query query2 = firestore_forrecicler.collection(Constantes.Users)
                .orderBy("key_busqueda");//.startAt( ubicacion_hash); //no funciono
        // .whereGreaterThanOrEqualTo("key_busqueda",ubicacion_hash );
        // .whereEqualTo("estadochat",true);

        FirestoreRecyclerOptions<Usuario> firestoreRecyclerOptions =
                new FirestoreRecyclerOptions.Builder<Usuario>().setQuery(query2, Usuario.class).build();

        adapter_user_firestore = new Adapter_User_firestore(firestoreRecyclerOptions);


        adapter_user_firestore.notifyDataSetChanged();

 */
    }





    private void startLocationUpdates() {

        // Cree la solicitud de ubicación para comenzar a recibir actualizaciones
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(update_interval);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Cree el objeto LocationSettingsRequest utilizando la solicitud de ubicación
        LocationSettingsRequest.Builder constructor = new LocationSettingsRequest.Builder();
        constructor.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = constructor.build();


        // Verifique si la configuración de ubicación se cumple
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(getContext());
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // el nuevo SDK v11 de la API de Google usa getFusedLocationProviderClient (this)
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getFusedLocationProviderClient(getContext()).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // trabaja aquí
                        // onLocationChanged (locationResult . getLastLocation ());
                    }
                },
                Looper.myLooper());
    }
    private void obtenerubicacion() {
        // fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(getContext());

        //aqui creamos la condicional para que pida el permiso si la aplicacion puede usar geolocalizacion en este caso pide el permiso al usuario con un dialogo
        //basicamente pide acceso a localizacion
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){


            //aqui pedimos el permiso sobre qeu tipo de permiso en este caso fine location puede ser camera u otro
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);

            return;

        }

        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            //aqui obtubo latitud y longitud sin usar google maps
                            Log.e("Latitud: ",+location.getLatitude()+"Longitud: "+location.getLongitude()); //ejemplo calro para obtener los datos en timepo real



                            latitud=location.getLongitude();
                            longitud=location.getLongitude();


                        }
                    }
                });

    }
    public void guardar_nom_foto(){


        SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        sharedPref.edit().putString("nomusu",nombre_uso_de_firebase);
        sharedPref.edit().putString("fotousu",vp1);



    }

    public void cargarinfo_usu(){
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        //  enviar.setEnabled(false); //esto dice que antes de reclamar los datos el boton debe estar inabilitado

        if (currentUser != null) {
            // enviar.setEnabled(true); //esto dice que antes de reclamar los datos el boton debe estar inabilitado
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference(Constantes.Nodo_Usuario + "/" + currentUser.getUid());

            //  DatabaseReference reference=database.getReference("Usuarios/"+currentUser.getUid()); //se concadena con el UID de firebase que es un codigo largo de id
            //con el anterior referencia podemos reclamar el nombre y el correo de firebase de el path usuarios
            FirebaseStorage storage_usu_foto = FirebaseStorage.getInstance();
            //StorageReference storageReference2=storage_usu_foto.getReference("Foto_Ususarios").child(Usuario_DAO.getInstance().getKeyUsuario());
            StorageReference storageReference3 = storage_usu_foto.getReference("fotos_perfil_USuario")
                    .child(Usuario_DAO.getInstance().getKeyUsuario());


            // reference_perfil_foto=storage_fotos_de_Oerfuk.getReference("Fotos/foto_perfil_usuario_registrados"+getKeyUsuario()); //aqui crea la carpeta con el id del ussuario correspondiente y almacena una ubicacion para las fotos

            // StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl("storage ref url in string");


            reference.addListenerForSingleValueEvent(new ValueEventListener() {


                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) { //datasnappshop es el qeu recupera los datos


                    //String value = dataSnapshot.getValue(String.class);
                    Usuario usu = dataSnapshot.getValue(Usuario.class);//pone la referencia
                    if(usu!=null){

                        String foto_ussss = usu.getFotodePerfilURI();



                        nombre_uso_de_firebase = usu.getUsuario_nombre();

                        final String foto_perfil_URI2 = usu.getFotodePerfilURI();
                        //  vp1=foto_ussss;
                        if (usu.getFotodePerfilURI()!=null) {


                            try {
                                Glide.with(getContext()).load(foto_ussss).into(foto_perfil_usuario_cv);
                                fotorecuperada=usu.getFotodePerfilURI();


                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        if (usu.getUsuario_nombre()!=null){
                            nombre_usu.setText(usu.getUsuario_nombre());

                            if (usu.getTeleono_usuario()!=null){

                                telefono=usu.getTeleono_usuario();
                            }
                            if (usu.getHabilidad_profesional()!=null){

                                especialidad=usu.getHabilidad_profesional();

                            }


                        }

                        //     guardar_nom_foto();

                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        } else {
            //returnLogin();
        }


    }




    @Override
    public void onStart() { //cuando salgamos d ela aplicacion y entremos, se cargeue el adaptador
        super.onStart();

        if (adapter != null) {

            adapter.startListening();
        }



        // adapter_recicler_clientes.startListening();//adaotador inicia

    }


    @Override
    public void onStop() {
        super.onStop();

        if (adapter!= null) {

            adapter.stopListening();
            super.onStop();
        }


        //adapter_recicler_clientes.stopListening(); //adaptador se detienen
    }

    @Override
    public void onResume() { //aqui recuperamos los datos de firebase
        super.onResume();

        if (adapter != null) {

            adapter.startListening();
        }


    }


}

