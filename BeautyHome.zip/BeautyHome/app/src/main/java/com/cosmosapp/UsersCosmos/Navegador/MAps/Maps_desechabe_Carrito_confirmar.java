package com.cosmosapp.UsersCosmos.Navegador.MAps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Reserva_cosmos;
import com.cosmosapp.UsersCosmos.Entidades_fire.Servicio_menu.Servicio_p1;
import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Maps_desechabe_Carrito_confirmar extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    Double latitudmap,longitudmap;

    List<Servicio_p1> list_servicios_p1;

    Bundle bundle1 ;

    String keyuser ;
    String key_hash ;

    String notifi ;

    String foto_usu_bund;
    String nom_usu;
    String tel_usu ;
    String nota_cliente ;
    String hora_servicio ;//nota_cliente
    String fecha_reservacion ;//nota_cliente

    String direccion_escrita;//esta sera ara escribira el usuario
    String total_string;
   int tota_bundle;

    List<Servicio_p1> lista_v3_Servicios=new ArrayList<>();



    ///ESTE ES USADO PARA CUANDO SE PIDE EL DOMICILIO SELECCIONAR MI UBICACION ACTUAL O LA DE PERFIL
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_aps_desechabe);


        Bundle bundle = getIntent().getParcelableExtra("bundle_domicilio");//aqui paso el latlang y lista parcelable de produtos
        Bundle bundle_info_v2 = getIntent().getParcelableExtra("bundle_info_v2");//aqui paso el latlang y lista parcelable de produtos

        Intent intent=this.getIntent();

        if(intent !=null) {

          bundle1 = getIntent().getExtras();

         //   lista_v3_Servicios = getIntent().getParcelableArrayListExtra("Lista_v3"); //funciona :D
          //lo de abajo solo funciono con la lista


          if (bundle1!=null) {

              //ahora por algun motivo no me muestra estos

            keyuser =getIntent().getStringExtra("key_usu_c_v1");//
            key_hash = getIntent().getStringExtra("key_usu__hash_v1");//bundle1.getString("key_usu__hash_v1");
            notifi = getIntent().getStringExtra("notifi_v1");//.getString("notifi_v1");

            foto_usu_bund = getIntent().getStringExtra("foto_user_v1");//.getString("foto_user_v1");
            nom_usu = getIntent().getStringExtra("nom_usu_v1");//bundle1.getString("nom_usu_v1");
            tel_usu =  getIntent().getStringExtra("tel_usu_v1");//bundle1.getString("tel_usu_v1");
            nota_cliente = getIntent().getStringExtra("nota_cliente_v1");//.getString("nota_cliente_v1");
            hora_servicio =getIntent().getStringExtra("hora_reservacion_v1");// bundle1.getString("hora_reservacion_v1");//nota_cliente
            fecha_reservacion = getIntent().getStringExtra("fecha_reservacion_v1");//bundle1.getString("fecha_reservacion_v1");//nota_cliente
           // tota_bundle =getIntent().getIntExtra("total_v1",10);// bundle1.getInt("total_v1");
            total_string=getIntent().getStringExtra("total_v2_carr");
             // tota_bundle=getIntent().getIntExtra("total_v2",0);


           lista_v3_Servicios = getIntent().getParcelableArrayListExtra("Lista_v3"); //funciona :D

              //problemas con esto de laista
              // list_servicios_p1 = (List<Servicio_p1>) i.getSerializableExtra("LIST"); //no funciono

              /*  //Esta version no me trajo la informacion

            keyuser = bundle1.getString("key_usu_c_v1"); //la verdad no importa
            key_hash = bundle1.getString("key_usu__hash_v1");
            notifi = bundle1.getString("notifi_v1");

            foto_usu_bund = bundle1.getString("foto_user_v1");
            nom_usu = bundle1.getString("nom_usu_v1");
            tel_usu = bundle1.getString("tel_usu_v1");
            nota_cliente = bundle1.getString("nota_cliente_v1");
            hora_servicio = bundle1.getString("hora_reservacion_v1");//nota_cliente
            fecha_reservacion = bundle1.getString("fecha_reservacion_v1");//nota_cliente
            tota_bundle = bundle1.getInt("total_v1");
              * * */
          }



            //falta la lista de servicios
        }



        if (bundle!=null) {
            //A AQUI FUNCIOAN TRAER LAT Y LONG POR EL BUNDLE CON EL GETPARCELABLE ,Y NO CON EL GETEXTRA DE INTENT
            LatLng toPosition = bundle.getParcelable("to_position");
            latitudmap=toPosition.latitude;
            longitudmap=toPosition.longitude;


            ///aqui tratare de traer tyodos los dtos con getparcelable, pero no funciono
            /*
            keyuser = bundle.getParcelable("key_usu_c_v1").; //
            key_hash = bundle.getParcelable("key_usu__hash_v1");
            notifi = bundle.getParcelable("notifi_v1");

            foto_usu_bund = bundle.getParcelable("foto_user_v1");
            nom_usu = bundle.getParcelable("nom_usu_v1");
            tel_usu = bundle.getParcelable("tel_usu_v1");
            nota_cliente = bundle.getParcelable("nota_cliente_v1");
            hora_servicio = bundle.getParcelable("hora_reservacion_v1");//nota_cliente
            fecha_reservacion = bundle.getParcelable("fecha_reservacion_v1");//nota_cliente
           // tota_bundle = bundle.getParcelable("total_v1");


             */

       //  reserva_cosmos =bundle.getParcelable("reservacion");


        }else {
            //-34, 151
            latitudmap= Double.valueOf(-35);
            longitudmap= Double.valueOf(151);

        }





      //  mMap.setOnMarkerDragListener(this);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mappita_desechable);
        mapFragment.getMapAsync(this);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.



    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    public  String fecha_enviado_mensaje(){

        // Date date=new Date();
        //PrettyTime prettyTime=new PrettyTime(new Date(), Locale.getDefault()); //obtiene el formato del dispositivo local
        //return  prettyTime.format(date);

        // Long cdigoHora=mensajeList.get(position).getHora();
        // al pedir un ong para funcionar simplemente enviamos el lon getCreatedTimestamp()
        Date d=new Date();
        SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
        return sdf.format(d);
    }
    public String timestamp(){

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        return ts;
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        // Add a marker in Sydney and move the camera

        LatLng sydney = new LatLng(latitudmap, longitudmap );
        mMap.addMarker(new MarkerOptions().position(sydney).title("Domicilio") .draggable(true));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(sydney.latitude, sydney.longitude), 16.0f));
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {




                latitudmap=marker.getPosition().latitude;
                longitudmap=marker.getPosition().longitude;

                    //int total_int_v1 = Integer.parseInt(total_string);

                    AlertDialog.Builder builder = new AlertDialog.Builder(Maps_desechabe_Carrito_confirmar.this);


                final EditText input = new EditText(Maps_desechabe_Carrito_confirmar.this);
                input.setHint("Direccion exacta");
                    builder.setTitle("MI Ubicacion");
                    builder.setIcon(R.mipmap.ic_launcher);
                     builder.setView(input); //editttex
                    //   builder.setMessage("Aqui recibire al profesional ");
                    builder.setMessage(
                            "fecha : " + fecha_reservacion + "\n"
                                    + "hora  : " + hora_servicio + "\n"

                                    + "nombre : " + nom_usu + "\n"
                                    + "Telefono : " + tel_usu + "\n"
                                   // + "direccion : " + direccion_escrita + "\n"
                                    + "valor de compra  : " +total_string + "\n" + "\n"  +
                                    "total de Servicios:   " + lista_v3_Servicios.size() + "\n" + "\n"
                                    + "continuar : " + "\n"
                    );


                    builder.setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {



                                    // ProgressBar progressBar=new ProgressBar(Maps_desechabe_Carrito_confirmar.this);
                                    ProgressDialog progressDialog = new ProgressDialog(Maps_desechabe_Carrito_confirmar.this);
                                    progressDialog.setMessage("Completando...");
                                    progressDialog.show();


                                    //enviar notificacion
                                    if (latitudmap != 0 && longitudmap != 0) {

                                        direccion_escrita=input.getText().toString();

                                        if (direccion_escrita!=null) {

                                            //este esta completo
                                            Reserva_cosmos reserva_cosmos = new Reserva_cosmos();
                                            reserva_cosmos.setTimestamp(timestamp());
                                            reserva_cosmos.setKey_uid(Usuario_DAO.getInstance().getKeyUsuario());
                                            reserva_cosmos.setNotifiuid_cliente(notifi);
                                            reserva_cosmos.setKey_busqueda(key_hash);
                                            reserva_cosmos.setNombre_cliente(nom_usu);
                                            reserva_cosmos.setTelefono(tel_usu);
                                            reserva_cosmos.setLatitud_cliente(latitudmap);
                                            reserva_cosmos.setLongitud_cliente(longitudmap);
                                            reserva_cosmos.setDireccion(direccion_escrita);
                                            reserva_cosmos.setHora_servicios(hora_servicio);
                                            reserva_cosmos.setFecha_servicios(fecha_reservacion);
                                            reserva_cosmos.setFecha_reservacion(fecha_enviado_mensaje());

                                            reserva_cosmos.setListservices(lista_v3_Servicios);

                                            String numCadena = total_string;
                                            int numEntero = Integer.parseInt(numCadena);
                                             reserva_cosmos.setTotal_int(numEntero);
                                            //reserva_cosmos.setTotal_string(total_string);


                                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                                            db.collection(Constantes.Reservaciones).document(Usuario_DAO.getInstance().getKeyUsuario()).set(reserva_cosmos);
                                            // db.collection(Constantes.Reservaciones_usuario).document(Usuario_DAO.getInstance().getKeyUsuario()).collection(Constantes.Factura).add(reserva_cosmos);

                                            //avisar administradores
                                            FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                                            firebaseDatabase.getReference("Usuario")
                                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                                                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                                                //   Servicio_p1 servicio_p1=snapshot.getValue(Servicio_p1.class);
                                                                Usuario usuario = snapshot.getValue(Usuario.class);
                                                                if (usuario != null) {

                                                                    if (usuario.getNotifi_uid() != null) {

                                                                        RequestQueue myrequest = Volley.newRequestQueue(Maps_desechabe_Carrito_confirmar.this);
                                                                        JSONObject jsonObject = new JSONObject();
                                                                        try {
                                                                            String token = usuario.getNotifi_uid();
                                                                            jsonObject.put("to", token);

                                                                            JSONObject notificaciojn = new JSONObject();
                                                                            notificaciojn.put(Constantes.Titulo, "Nueva Reservacion");
                                                                            notificaciojn.put(Constantes.Detalle, "Reservacion   " + nom_usu);
                                                                            notificaciojn.put(Constantes.tiponotificaion, "corazon");
                                                                            notificaciojn.put("uid", "");
                                                                            notificaciojn.put("fotouser", "");
                                                                            notificaciojn.put("nombre", nom_usu);
                                                                            notificaciojn.put("notifi2", notifi);

                                                                            Log.e("TAG", "token adapter   " + token);


                                                                            jsonObject.put("data", notificaciojn);
                                                                            String URL = "https://fcm.googleapis.com/fcm/send";
                                                                            //  String URL2="https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

                                                                            //envia los requerimientos jsobobject //methdo,url/objetos y escuchas y error de escucha
                                                                            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL, jsonObject, null, null) {

                                                                                @Override
                                                                                public Map<String, String> getHeaders() {
                                                                                    Map<String, String> header = new Hashtable<>();
                                                                                    header.put("content-type", "application/json");
                                                                                    header.put("authorization", "key=" + Constantes.nube_key);
                                                                                    //firebaseconsole/consfiguracion//cloudmessenger/
                                                                                    return header;
                                                                                }
                                                                            };

                                                                            myrequest.add(request);

                                                                        } catch (Exception e) {
                                                                            e.printStackTrace();
                                                                        }
                                                                    }

                                                                }

                                                            }


                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                                        }
                                                    });


                                            //  Toast.makeText(getContext(), listaadmis.size(), Toast.LENGTH_LONG).show();

                                            //nontificar_administradores(); //no funciono
                                            Toast.makeText(Maps_desechabe_Carrito_confirmar.this, direccion_escrita, Toast.LENGTH_SHORT).show();

                                            Toast.makeText(Maps_desechabe_Carrito_confirmar.this, "Reservacion agendada: " + nom_usu, Toast.LENGTH_LONG).show();

                                            Intent intent = new Intent(Maps_desechabe_Carrito_confirmar.this, Navegdor.class);

                                            startActivity(intent);
                                        } else {
                                            // db.insertSubject(value);
                                            //getData();
                                            Toast.makeText(Maps_desechabe_Carrito_confirmar.this, "Ingresar direccion", Toast.LENGTH_SHORT).show();

                                        }


                                    } else {
                                        Toast.makeText(Maps_desechabe_Carrito_confirmar.this, "Informacion faltante, error inesperado 370", Toast.LENGTH_LONG).show();

                                    }


                                    /*
                                    Intent i = new Intent(getContext(), MapsActivity_domicilio.class);
                                    // LatLng fromPosition = new LatLng(9385853.0094, 23123123.234 );

                                    LatLng toPosition = new LatLng(model.getLatitud_cliente(), model.getLongitud_cliente());


                                    Bundle args = new Bundle();
                                    //args.putParcelable("from_position", fromPosition);
                                    args.putParcelable("to_position", toPosition);

                                    i.putExtra("bundle_domicilio", args);


                                    startActivity(i);

                                    //bundle.putExtra("map", (Serializable) map);

                                     */

                                }


                            }).setNegativeButton("CANCELAR",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(Maps_desechabe_Carrito_confirmar.this, "cancelado ", Toast.LENGTH_LONG).show();
                                    //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                }
                            });
                    //  AlertDialog dialog = builder.create();
                    builder.create();
                    builder.show();


                return true;
//////////////
            }
        });


    //   mover_mi_ubicacion_de_domicilio();






    }


}


