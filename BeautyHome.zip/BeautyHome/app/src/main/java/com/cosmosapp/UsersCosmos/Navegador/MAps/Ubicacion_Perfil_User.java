package com.cosmosapp.UsersCosmos.Navegador.MAps;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.actividades.Perfil_Usuario;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;
import static java.security.AccessController.getContext;

public class Ubicacion_Perfil_User extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    TextView texto_confirmar;
    double latitudmap,longitudmap;

    int MY_PERMISSIONS_REQUEST_READ_CONTACTS; //int para permisos de localizacion

    LocationManager mLocationManager;

    private LocationRequest mLocationRequest;

    private long update_interval = 10 * 1000;   // 10 segundos
    private long FASTEST_INTERVAL = 2000;   //2 segundos



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicacion__perfil__user);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_activiti_ubicaicon_perfil);
        mapFragment.getMapAsync(this);


        Bundle bundle = getIntent().getParcelableExtra("bundle_domicilio_v2");//aqui paso el latlang y lista parcelable de produtos


        if (bundle!=null) {
            //A AQUI FUNCIOAN TRAER LAT Y LONG POR EL BUNDLE CON EL GETPARCELABLE ,Y NO CON EL GETEXTRA DE INTENT
            LatLng toPosition = bundle.getParcelable("to_position_v2");
            latitudmap = toPosition.latitude;
            longitudmap = toPosition.longitude;

        }else {
            latitudmap=0;
            longitudmap=0;
           // startLocationUpdates();
        }



        texto_confirmar=findViewById(R.id.confirm_ubicacion);
        texto_confirmar.setVisibility(View.GONE);




    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;




        LatLng sydney = new LatLng(latitudmap, longitudmap);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Domicilio").draggable(true));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(sydney.latitude, sydney.longitude), 16.0f));

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Ubicacion_Perfil_User.this);


                builder.setTitle("MI Ubicacion");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage(
                        "Esta es La Ubicacion del Servicio ");
                builder.setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                //enviar notificacion


                                //aqui ya hemos confirmado de ante mano su ubicaicon
                                //este simplemente confirma
                                Intent i = new Intent(Ubicacion_Perfil_User.this, Navegdor.class);
                                // LatLng fromPosition = new LatLng(9385853.0094, 23123123.234 );


                                startActivity(i);




                            }
                        }).setNegativeButton("CANCELAR",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(Ubicacion_Perfil_User.this, "cancelado ", Toast.LENGTH_LONG).show();
                                //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                            }
                        });
                //  AlertDialog dialog = builder.create();
                builder.create();
                builder.show();
                return false;
            }
        });

//////////////

        //llamarmarker(latitudmap,longitudmap); //no funciono pasar todo a un methodo



        //no era tan malo

        /*

            if (latitudmap!=0.0&longitudmap!=0.0) {
                LatLng sydney = new LatLng(latitudmap, longitudmap);
                mMap.addMarker(new MarkerOptions().position(sydney).title("Domicilio").draggable(true));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(sydney.latitude, sydney.longitude), 16.0f));
                mMap.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
                                                 @Override
                                                 public void onMarkerDragStart(Marker marker) {

                                                 }

                                                 @Override
                                                 public void onMarkerDrag(Marker marker) {

                                                 }

                                                 @Override
                                                 public void onMarkerDragEnd(Marker marker) {


                                                     latitudmap = marker.getPosition().latitude;
                                                     longitudmap = marker.getPosition().longitude;


                                                     AlertDialog.Builder builder = new AlertDialog.Builder(Ubicacion_Perfil_User.this);


                                                     builder.setTitle("MI Ubicacion");
                                                     builder.setIcon(R.mipmap.ic_launcher);
                                                     builder.setMessage(
                                                             "Esta es La Ubicacion del Servicio ");
                                                     builder.setPositiveButton("OK",
                                                             new DialogInterface.OnClickListener() {
                                                                 @Override
                                                                 public void onClick(DialogInterface dialog, int which) {

                                                                     //enviar notificacion


                                                                     Intent i = new Intent(Ubicacion_Perfil_User.this, Perfil_Usuario.class);
                                                                     // LatLng fromPosition = new LatLng(9385853.0094, 23123123.234 );

                                                                     LatLng toPosition = new LatLng(latitudmap, longitudmap);


                                                                     Bundle args = new Bundle();
                                                                     //args.putParcelable("from_position", fromPosition);
                                                                     args.putParcelable("to_position", toPosition);

                                                                     i.putExtra("bundle_domicilio", args);


                                                                     startActivity(i);


                                                                 }
                                                             }).setNegativeButton("CANCELAR",
                                                             new DialogInterface.OnClickListener() {
                                                                 @Override
                                                                 public void onClick(DialogInterface dialog, int which) {
                                                                     Toast.makeText(Ubicacion_Perfil_User.this, "cancelado ", Toast.LENGTH_LONG).show();
                                                                     //  Toast.makeText(Solicitar_room.this, "completado foto:" + fotousuario_fire, Toast.LENGTH_LONG).show();

                                                                 }
                                                             });
                                                     //  AlertDialog dialog = builder.create();
                                                     builder.create();
                                                     builder.show();
//////////////


                                                 }


                                             }

                );
            }else {
                startLocationUpdates();

            }
            */



    }




    private void startLocationUpdates() {

        // Cree la solicitud de ubicación para comenzar a recibir actualizaciones
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(update_interval);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Cree el objeto LocationSettingsRequest utilizando la solicitud de ubicación
        LocationSettingsRequest.Builder constructor = new LocationSettingsRequest.Builder();
        constructor.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = constructor.build();


        // Verifique si la configuración de ubicación se cumple
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // el nuevo SDK v11 de la API de Google usa getFusedLocationProviderClient (this)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getFusedLocationProviderClient(this).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // trabaja aquí
                        // onLocationChanged (locationResult . getLastLocation ());
                        if (locationResult!=null) {
                            latitudmap = locationResult.getLastLocation().getLatitude();
                            longitudmap = locationResult.getLastLocation().getLongitude();


                          //  LatLng sydney = new LatLng(latitudmap, longitudmap);
                            //mMap.addMarker(new MarkerOptions().position(sydney).title("Domicilio") .draggable(true));
                            //mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(sydney.latitude, sydney.longitude), 16.0f));

                        }

                        }
                },
                Looper.myLooper());
    }


}