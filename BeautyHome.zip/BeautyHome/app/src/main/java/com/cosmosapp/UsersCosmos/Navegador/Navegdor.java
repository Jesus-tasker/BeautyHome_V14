package com.cosmosapp.UsersCosmos.Navegador;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Map_location;
import com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav.Fragmento_Domicilios;
import com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav.Fragment_carrito;
import com.cosmosapp.UsersCosmos.Fragments.riders.frag_Nav.Inicio_pedidos;
import com.cosmosapp.UsersCosmos.actividades.Login_iniciarcesion;
import com.cosmosapp.UsersCosmos.actividades.Perfil_Usuario;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;


public class Navegdor extends AppCompatActivity {


    BottomNavigationView bottomNavigationView;

    //locacion en firebase en tiempo real
    private FusedLocationProviderClient fusedLocationProviderClient;
    DatabaseReference reference_localizacion;
    int MY_PERMISSIONS_REQUEST_READ_CONTACTS; //int para permisos de localizacion

    LocationManager mLocationManager;

    private LocationRequest mLocationRequest;

    private long update_interval = 10 * 1000;   // 10 segundos
    private long FASTEST_INTERVAL = 2000;   //2 segundos


    Double latitud,longitud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegdor);

        mostrarFragmentoSeleccionado(new Fragment_carrito()); //aqui inicio el fragment para que siempre inicie en este

        reference_localizacion = FirebaseDatabase.getInstance().getReference().child(Constantes.Nodo_localizacion);
        fusedLocationProviderClient = getFusedLocationProviderClient(this);
        startLocationUpdates();
        //subir_lat_long_firebase(); //funciona pero noe s util ahroa


        bottomNavigationView = (BottomNavigationView) findViewById(R.id.navegador_button);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.clientes_inicio_item) { //aqui señala si pulso sobre el primer item

                    mostrarFragmentoSeleccionado(new Fragment_carrito());

                }
                if (menuItem.getItemId() == R.id.mensajeria) { //aqui señala si pulso sobre el primer item

                   mostrarFragmentoSeleccionado(new Inicio_pedidos());

                }
                if (menuItem.getItemId() == R.id.lista_chats_organizada2) { //aqui señala si pulso sobre el primer item

                    mostrarFragmentoSeleccionado(new Fragmento_Domicilios());

                }



                return true;
            }
        });


        //codigo para el menu deplegable


    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_folder, menu);
        return true;

    }

    private void startLocationUpdates() {

        // Cree la solicitud de ubicación para comenzar a recibir actualizaciones
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(update_interval);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Cree el objeto LocationSettingsRequest utilizando la solicitud de ubicación
        LocationSettingsRequest.Builder constructor = new LocationSettingsRequest.Builder();
        constructor.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = constructor.build();


        // Verifique si la configuración de ubicación se cumple
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // el nuevo SDK v11 de la API de Google usa getFusedLocationProviderClient (this)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getFusedLocationProviderClient(this).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // trabaja aquí
                        // onLocationChanged (locationResult . getLastLocation ());
                        latitud=locationResult.getLastLocation().getLatitude();
                        longitud=locationResult.getLastLocation().getLongitude();
                    }
                },
                Looper.myLooper());
    }


    //eniamos longitud y latitud a firebase directametne
    private void subir_lat_long_firebase() {
        // fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(getContext());

        //aqui creamos la condicional para que pida el permiso si la aplicacion puede usar geolocalizacion en este caso pide el permiso al usuario con un dialogo
       //basicamente pide acceso a localizacion
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){


            //aqui pedimos el permiso sobre qeu tipo de permiso en este caso fine location puede ser camera u otro
            ActivityCompat.requestPermissions(Navegdor.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);

                return;

        }

        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {

                            //aqui obtubo latitud y longitud sin usar google maps
                            Log.e("Latitud: ",+location.getLatitude()+"\n"+" Longitud: "+location.getLongitude()); //ejemplo calro para obtener los datos en timepo real

                            if (location.getLongitude()!=0&& location.getLongitude()!=0) {
                                Map_location map1 = new Map_location();
                                map1.setLatitud(location.getLatitude());
                                map1.setLongitud(location.getLongitude());

                                latitud=map1.getLatitud();
                                longitud=map1.getLongitud();
                                reference_localizacion.child(Usuario_DAO.getInstance().getKeyUsuario()).setValue(map1);
                            }


                        }
                    }
                });

    }

    /*
    public  void obtenerlocalizacion2(){


        LocationManager locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 10, locationListenerGPS);
        LocationListener locationListenerGPS=new LocationListener() {
            @Override
            public void onLocationChanged(android.location.Location location) {
                double lat=location.getLatitude();
                double lon=location.getLongitude();
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

    }

    */


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();//recuperamos el item seleccionado para salir d ela app

        if(id == R.id.quienes_somos){

            WebView web = new WebView(this);
            setContentView(web);
            web.loadUrl("https://beautyhomehairlove.wixsite.com/beautyandhome");
            web.getSettings().setJavaScriptEnabled(true);
            web.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url){
                    view.loadUrl(url);
                    return true;
                }
            });

        }
        if(id == R.id.perfil_userto){

            //ya pasamos el bundle con lat ylan
            if (latitud!=null&&longitud!=null){

          //  startActivity(new Intent(Navegdor.this, Ubicacion_Perfil_User.class));
                Intent i = new Intent(Navegdor.this, Perfil_Usuario.class);
                // LatLng fromPosition = new LatLng(9385853.0094, 23123123.234 );

                LatLng toPosition = new LatLng(latitud, longitud);


                Bundle args = new Bundle();
                //args.putParcelable("from_position", fromPosition);
                args.putParcelable("to_position", toPosition);

                i.putExtra("bundle_domicilio", args);


                startActivity(i);


                finish();
            }else{

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Off");
                builder.setMessage("Hola, para continuar debes encender la localizacion del dispositivo o trata de nuevo");
                builder.setPositiveButton("Aceptar", null);

                AlertDialog dialog = builder.create();
              //  startLocationUpdates();
                dialog.show();

            }

            //El código que se ejecutara al hacer click en esa opción

        }
        if(id == R.id.salida_config){
            FirebaseAuth.getInstance().signOut();
            //El código que se ejecutara al hacer click en esa opción
            AuthUI.getInstance()
                    .signOut(this)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        public void onComplete(@NonNull Task<Void> task) {
                            // user is now signed out
                            startActivity(new Intent(Navegdor.this, Login_iniciarcesion.class));

                            finish();
                        }
                    });


        }

        return super.onOptionsItemSelected(item);
    }


    //creo unm methodo que eligue el fragmento que se eligiio
    private void  mostrarFragmentoSeleccionado(Fragment fragment){
        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .commit();
    }


}