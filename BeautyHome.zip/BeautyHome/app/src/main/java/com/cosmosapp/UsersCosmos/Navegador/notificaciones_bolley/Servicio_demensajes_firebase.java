package com.cosmosapp.UsersCosmos.Navegador.notificaciones_bolley;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Random;

public class Servicio_demensajes_firebase extends FirebaseMessagingService {

    //1.usamos el toque dle dispositivo
      String tiponotifi;
     String nombre;
     String key;
     String foto_us;
     String notifiuser2;

    @Override
    public void onNewToken(@NonNull String s) {
        super.onNewToken(s);

        Log.e("token","mi token es "+ s);
        //nota el token se activa cuando se llama asi qeu debemos desinstalar la app si no tiene este codigo
        //nace cuando  se crea la app

          //  guardartoken(s); //no quiso guardarlo en firebase provaremos con otro en shared preference
        guardarensharedpreference(s);

    }

    private void guardarensharedpreference(String s) {

        SharedPreferences myPreferences_lat_long
                = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor myEditor = myPreferences_lat_long.edit();



        SharedPreferences sharedPreferences3=getSharedPreferences("notificacion_p", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences3.edit();
        editor.putString("notificacion",s);


        myEditor.commit();


    }

    private void guardartoken(String s) {
        DatabaseReference db= FirebaseDatabase.getInstance().getReference().child(Constantes.token);
        db.child("jesus").setValue(s);

    }

    //2.onmensaje recibido
    //3. en el manifest Servicio_demensajes_firebase
    /* //4. en el manifes debe declararse las notificaciones
     <service android:name=".Navegador.notificaciones_bolley.Servicio_demensajes_firebase" android:exported="false">
           <intent-filter>
               <action android:name="com.google.firebase.MESSAGING_EVENT"/>

           </intent-filter>*/
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        String from=remoteMessage.getFrom();
        Log.e("TAG","mensajerecibido de "+ from);

        /*
        if (remoteMessage.getNotification()!=null){

            Log.e("TAG","titulo"+ remoteMessage.getNotification().getTitle());

            Log.e("TAG","detalle"+ remoteMessage.getNotification().getBody());
        }*/
        if(remoteMessage.getData().size()>0){
            //aqui recibiriamos informacion del panel de firebase cloud funcitions
            Log.e("TAG","Titulo recibido:  "+ remoteMessage.getData().get(Constantes.Titulo)); //ej a clase es titulo obtiene el objeto
            Log.e("TAG","detalle encadenado  budy; "+ remoteMessage.getData().get(Constantes.Detalle));
            Log.e("TAG","color  budy; "+ remoteMessage.getData().get("Color"));
            Log.e("TAG","key budy; "+ remoteMessage.getData().get("uid"));
            Log.e("TAG","key notifi; "+ remoteMessage.getData().get("notifi2"));
            Log.e("TAG","foto ; "+ remoteMessage.getData().get("fotouser"));

            String titulo=remoteMessage.getData().get(Constantes.Titulo);
            String detalle=remoteMessage.getData().get(Constantes.Detalle);
            String tiponotificacion=remoteMessage.getData().get(Constantes.tiponotificaion);
            String nombrenoti=remoteMessage.getData().get("nombre");
            String key_noti=remoteMessage.getData().get("uid");
            String foto_noti=remoteMessage.getData().get("fotouser");
            String notifi_notifi=remoteMessage.getData().get("notifi2");
            key=key_noti;
            nombre=nombrenoti;
            foto_us=foto_noti;
            notifiuser2=notifi_notifi;





            //los canales d enotificacion se realizan solo de oreo en adelante de no ser asi ene l video muestran como poner uno
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

                    mayorqueoreo(titulo, detalle,tiponotificacion);



                //con esto ya pòdemos recibir notificaciones d efirebase y con bolley decimos a quienes enviar qahora
            }


            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) {

                menorqueoreo(titulo, detalle,tiponotificacion);

                //es igua pero sin usar los coanales esos canales son para oreo en adelante
              // menorqueoreo(titulo, detalle);
                //con esto ya pòdemos recibir notificaciones d efirebase y con bolley decimos a quienes enviar qahora
            }


        }



    }

    private void menorqueoreo(String titulo, String detalle, String tipo_notifi) {
        String id="mensajes";
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder buitel = new NotificationCompat.Builder(this, id);

                if (tipo_notifi.equals("corazon")) {

                    Log.e("TAG", "noti menor oreo 8 " + titulo);

                    buitel.setAutoCancel(true)
                            .setWhen(System.currentTimeMillis())
                            .setContentTitle(titulo)
                            .setSmallIcon(R.mipmap.ic_launcher)
                           // .setBadgeIconType(R.mipmap.imagen_yesroom)
                            .setStyle(new NotificationCompat.BigTextStyle())
                            .setContentText(detalle)
                            .setContentIntent(clicknoti_report_v2())
                            .setContentInfo("Nuevo");


                    Random random = new Random();
                    int id_aleato = random.nextInt(8000);


                    nm.notify(id_aleato, buitel.build());
                }

        if (tipo_notifi.equals("eliminado")) {

            Log.e("TAG", "noti menor oreo 8 " + titulo);

            buitel.setAutoCancel(true)
                    .setWhen(System.currentTimeMillis())
                    .setContentTitle(titulo)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    //.setBadgeIconType(R.mipmap.imagen_yesroom)
                    .setStyle(new NotificationCompat.BigTextStyle())
                    .setContentText(detalle)
                  //  .setContentIntent(notifica_reporte())
                    .setContentInfo("Nuevo");


            Random random = new Random();
            int id_aleato = random.nextInt(8000);


            nm.notify(id_aleato, buitel.build());
        }
        if (tipo_notifi.equals("reportado")) {

            Log.e("TAG", "noti menor oreo 8 " + titulo);

            buitel.setAutoCancel(true)
                    .setWhen(System.currentTimeMillis())
                    .setContentTitle(titulo)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    //.setBadgeIconType(R.mipmap.imagen_yesroom)
                    .setStyle(new NotificationCompat.BigTextStyle())
                    .setContentText(detalle)
                 //   .setContentIntent(notifica_reporte())
                    .setContentInfo("Nuevo");


            Random random = new Random();
            int id_aleato = random.nextInt(8000);


            nm.notify(id_aleato, buitel.build());
        }

        if (tipo_notifi.equals("mensaje")) {

            Log.e("TAG", "noti menor oreo 8 " + titulo);

            buitel.setAutoCancel(true)
                    .setWhen(System.currentTimeMillis())
                    .setContentTitle(titulo)
                    .setSmallIcon(R.mipmap.ic_launcher)

                    //.setBadgeIconType(R.mipmap.imagen_yesroom)
                    .setStyle(new NotificationCompat.BigTextStyle())
                    .setContentText(detalle)

                   // .setContentIntent(clicknoti())
                    .setContentInfo("Nuevo");


            Random random = new Random();
            int id_aleato = random.nextInt(8000);


            nm.notify(id_aleato, buitel.build());
        }


    }

    private void mayorqueoreo(String titulo, String detalle, String tipo_notificacion) {
        //si la version del sdk usar esta opcion
        String id="mensajes";
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder buitel=new NotificationCompat.Builder(this,id);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel=new NotificationChannel(id,"nuevo", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setShowBadge(true); //por si es mayor que oreo
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{0,1000,500,1000});//patron d enotificaion en canales
            //notificationChannel.setSound();//direccion del sonido
            notificationChannel.setShowBadge(true); //en versiones mayores a api 26 se mostrara la notificacion en el icono


            assert  nm!=null;
            nm.createNotificationChannel(notificationChannel); //al final creamos la notificacion
            Log.e("TAG","noti mayor a oreo 8 "+titulo);

        }
        try {
            //aqui trae todos los datos del componente
            buitel.setAutoCancel(true)
                    .setWhen(System.currentTimeMillis())
                    .setContentTitle(titulo)
                    .setSmallIcon(R.mipmap.ic_launcher)

                    .setStyle(new NotificationCompat.BigTextStyle())
                    .setContentText(detalle)
                   // .setContentIntent(clicknoti())
                    .setContentInfo("Nuevo");
            //se crea un valor random para la notificacion
            Random random=new Random();
            int id_aleato=random.nextInt(8000);

            assert nm != null; //evita que sea nulo para que no colapse
            nm.notify(id_aleato, buitel.build());

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public PendingIntent clicknoti_report_v2(){

        //aqui podremos poner informacion que el usuario recibiria en la actividad

        Intent notificacion = new Intent(getApplicationContext(), Navegdor.class);




        //notificacion.putExtra("key_receptor", key);

// notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, notificacion, PendingIntent.FLAG_UPDATE_CURRENT);



    }


/*
    //con esto al pulsar sobre una notificacion recibimos datos
    public PendingIntent clicknoti(){

        //aqui podremos poner informacion que el usuario recibiria en la actividad

        Intent notificacion = new Intent(getApplicationContext(), MEnsajeria_firestore.class);

        Bundle bundle = new Bundle();
        bundle.putString("key_receptor", key);
        bundle.putString("nombre", nombre);
        bundle.putString("foto", foto_us);
        bundle.putString("notifi",notifiuser2);
        Log.e("TAG","key: "+key);

        notificacion.putExtras(bundle);
        //notificacion.putExtra("key_receptor", key);

// notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, notificacion, PendingIntent.FLAG_UPDATE_CURRENT);



    }
    public PendingIntent clicknoti_report(){

        //aqui podremos poner informacion que el usuario recibiria en la actividad

        Intent notificacion = new Intent(getApplicationContext(), Navegdor.class);




        //notificacion.putExtra("key_receptor", key);

// notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, notificacion, PendingIntent.FLAG_UPDATE_CURRENT);



    }

    public PendingIntent notifica_reporte() {


        //aqui podremos poner informacion que el usuario recibiria en la actividad

            Intent notificacion = new Intent(getApplicationContext(), MEnsajeria_firestore.class);

            Bundle bundle = new Bundle();
            bundle.putString("key_receptor", key);
            bundle.putString("nombre", nombre);


            notificacion.putExtras(bundle);
            //notificacion.putExtra("key_receptor", key);

// notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            return PendingIntent.getActivity(this, 0, notificacion, PendingIntent.FLAG_UPDATE_CURRENT);


    }
    public PendingIntent aceptarchat(){

        //aqui podremos poner informacion que el usuario recibiria en la actividad

        Intent notificacion = new Intent(getApplicationContext(), MEnsajeria_firestore.class);

        Bundle bundle = new Bundle();
        bundle.putString("key_receptor", key);
        bundle.putString("nombre", nombre);
        bundle.putString("foto", foto_us);
        bundle.putString("notifi",notifiuser2);
        Log.e("TAG","key: "+key);

        notificacion.putExtras(bundle);
        //notificacion.putExtra("key_receptor", key);

// notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificacion.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, notificacion, PendingIntent.FLAG_UPDATE_CURRENT);



    }

     */
}
//https://www.youtube.com/watch?v=zmiDl4aK7mo clase virtual