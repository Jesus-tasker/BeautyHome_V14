package com.cosmosapp.UsersCosmos.actividades;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;

import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Map_location;
import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;
import com.cosmosapp.UsersCosmos.Navegador.GeoHash;
import com.cosmosapp.UsersCosmos.Navegador.MAps.Maps_desechabe_Carrito_confirmar;
import com.cosmosapp.UsersCosmos.Navegador.MAps.Ubicacion_Perfil_User;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.google.android.gms.location.LocationServices.getFusedLocationProviderClient;

public class Perfil_Usuario extends AppCompatActivity {



    CircleImageView foto_usuario_perfil;
    String profesion_seleccionada, nombreusuario;
    TextView tv_profesion_seleccionada, texto_profesion;
    Spinner sp_profesion;
    EditText descipcion_trabajo, telefono_usuario, nombreusuario_edittex;
    ImageView guardar;
    private final static String[] profesiones = {"chat casual", "chat hot", "conocer",
            "curiosidad", "quizas esta mi vecino/a"};

    private int PICK_IMAGE_REQUEST = 1; //para foto perfil
    private Uri foto_de_perfilURI_enviar;
    private String foto_perfil_string_URI_enviada;
    private String nombre_uso_de_firebase, telefono_firebase, descripcion_firebase;

    FirebaseAuth mAuth;//methodo onresume
    FirebaseUser firebaseUser;
    DatabaseReference reference_data;

    double latitud;
    double longitud;
    int MY_PERMISSIONS_REQUEST_READ_CONTACTS; //int para permisos de localizacion

    private long update_interval = 10 * 1000;   // 100 segundos
    private long FASTEST_INTERVAL = 2000;   //2 segundos

    private LocationRequest mLocationRequest;
    String fotorecuperada;
    String hash;
    private FusedLocationProviderClient fusedLocationProviderClient;


    Switch aSwitch_chat;
    private boolean chatactivado;
    private String genero;


    CheckBox gen1, gen2, gen3;
    CheckBox bus1, bus2, bus3;
    private String notifiuid;
    private String cargo="Administrador";


    public static final String FCM_MESSAGE_URL = "https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil__usuario);
        foto_usuario_perfil = (CircleImageView) findViewById(R.id.usuario_foto_perfil_circulo);
        nombreusuario_edittex = findViewById(R.id.nombre_usuario_Edittex);
        telefono_usuario = (EditText) findViewById(R.id.telefono_usu_Actual);

        descipcion_trabajo = findViewById(R.id.descripcion_profesional);
        guardar = findViewById(R.id.guardar_info_usuario);
        mAuth = FirebaseAuth.getInstance();

/*
        SharedPreferences myPreferences_lat_long
                = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        SharedPreferences preferences = getSharedPreferences("notificacion_p",Context.MODE_PRIVATE);

        String notificacion_uid=preferences.getString("notificacion","no existe la informacion");
        Toast.makeText(Perfil_Usuario.this, "notifi"+notificacion_uid, Toast.LENGTH_LONG).show();

 */
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(Perfil_Usuario.this, new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                String newToken = instanceIdResult.getToken();
                notifiuid = newToken;
                //  Toast.makeText(Perfil_Usuario.this, "notifi"+notifiuid, Toast.LENGTH_LONG).show();
                //Log.e("newToken",newToken);
                //funciona
            }
        });

        //   ogenero_personal();
        cargarinfo_usu();

        fusedLocationProviderClient = getFusedLocationProviderClient(this);
        startLocationUpdates(); //location
        obtenerubicacion();


        //  Toast.makeText(Perfil_Usuario.this, "hash: "+hash, Toast.LENGTH_LONG).show();

        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();//aqui obtenermos realmente nuestro usuario con autenticacion de usuario
        reference_data = FirebaseDatabase.getInstance().getReference(Constantes.Nodo_Usuario).child(firebaseUser.getUid()); //aqui trabajamos con el uid d no se si es el mismo Usuario_DAO.getInstance().getKeyUsuario();
        //  final DatabaseReference reference_data_ventas = FirebaseDatabase.getInstance().getReference(Constantes.Nodo_venta_general); //aqui trabajamos con el uid d no se si es el mismo Usuario_DAO.getInstance().getKeyUsuario();


        foto_usuario_perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        final ArrayAdapter adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, profesiones);

//        sp_profesion.setAdapter(adapter);
  //8o      profesion_seleccionada = sp_profesion.getSelectedItem().toString();//texto seleccionado
        // Toast.makeText(Usuario_Informacion.this, profesion_seleccionada, Toast.LENGTH_LONG).show();




        // guardarnotificaciondeepruebatodos();


        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String profesion = profesion_seleccionada;
                final String descripcion_usuario = descipcion_trabajo.getText().toString().trim();
                final String telefono_actual = telefono_usuario.getText().toString().trim();
                Map_location map_location = new Map_location();
                map_location.setLatitud(latitud);
                map_location.setLongitud(longitud);

                GeoHash geoHash = GeoHash.fromLocation(map_location, 6);
                hash = geoHash.toString();
                Toast.makeText(Perfil_Usuario.this, "hash: " + hash, Toast.LENGTH_LONG).show();


                if (TextUtils.isEmpty(descripcion_usuario)) {

                    Toast.makeText(Perfil_Usuario.this, "describe que buscas", Toast.LENGTH_LONG).show();

                }
                if (latitud==0&&longitud==0){
                    Toast.makeText(Perfil_Usuario.this, "Activar Localizacion", Toast.LENGTH_SHORT).show();

                }


                if (valida_descripcion_usuario(descripcion_usuario) && valida_telefono(telefono_actual)&&latitud!=0&&longitud!=0) {


                    if (foto_de_perfilURI_enviar != null) {
                        //si el usuario no sube foto de perfil se cargara na por defecto tipo uri
                        //aqui llamamos a la ubicacion  y conextion e tiempo real de el almacenamiento de la foto de perfil su URI se almacenrara

                        //aqui trabaja con el methodo uri como foto de perfil y trabaja con una interfaz interna para conectarse


                        Usuario_DAO.getInstance().subirfotoUri(foto_de_perfilURI_enviar, new Usuario_DAO.IDdevolverURLfoto() {
                            @Override
                            public void urlfoto(String url) {

                                Toast.makeText(Perfil_Usuario.this, "usuario actualizado", Toast.LENGTH_LONG).show();


                                Usuario usuario = new Usuario();
                                usuario.setUsuario_nombre(nombre_uso_de_firebase);
                                usuario.setFotodePerfilURI(foto_perfil_string_URI_enviada);
                                usuario.setTeleono_usuario(telefono_actual);
                                usuario.setProfesion(profesion);
                                usuario.setHabilidad_profesional(descripcion_usuario);
                                usuario.setKey_usuario(Usuario_DAO.getInstance().getKeyUsuario());
                                usuario.setKey_busqueda(hash);
                                usuario.setCargo(cargo);
                                usuario.setLatidu(latitud);
                                usuario.setLatidu(longitud);
                                usuario.setNotifi_uid(notifiuid);
                                Toast.makeText(Perfil_Usuario.this, "registro foto nueva", Toast.LENGTH_LONG).show();

                                guardarnombre();
                                Usuario_DAO.getInstance().actualizar_info_usuario_y_foto(FirebaseAuth.getInstance().getCurrentUser().getUid(), usuario);

                                LatLng toPosition = new LatLng(latitud, longitud);

                                Intent i = new Intent(Perfil_Usuario.this, Ubicacion_Perfil_User.class);

                                Bundle bundle1 = new Bundle();
                                bundle1.putParcelable("to_position_v2", toPosition); //este dice que sirve
                                i.putExtra("bundle_domicilio_v2", bundle1);
                                Toast.makeText(Perfil_Usuario.this, ""+latitud+"  "+longitud, Toast.LENGTH_SHORT).show();


                                startActivity(i);

                                // startActivity(new Intent(Perfil_Usuario.this, Navegdor.class));


                                finish(); //con esto cada vez que termine se cierra y retorna al login



                            }
                        });


                    } else if (fotorecuperada != null) {


                        Usuario usuario = new Usuario();

                        usuario.setFotodePerfilURI(fotorecuperada);
                        usuario.setUsuario_nombre(nombre_uso_de_firebase);
                        usuario.setTeleono_usuario(telefono_actual);
                        usuario.setProfesion(profesion);
                        usuario.setHabilidad_profesional(descripcion_usuario);
                        usuario.setKey_usuario(Usuario_DAO.getInstance().getKeyUsuario());
                        usuario.setKey_busqueda(hash);
                        usuario.setLatidu(latitud);
                        usuario.setLongitud(longitud);
                        usuario.setCargo(cargo);

                        usuario.setNotifi_uid(notifiuid);

                        guardarnombre();

                        Usuario_DAO.getInstance().actualizar_info_usuario_y_foto(FirebaseAuth.getInstance().getCurrentUser().getUid(), usuario);
                        Toast.makeText(Perfil_Usuario.this, "registro foto recuperada", Toast.LENGTH_LONG).show();

                        LatLng toPosition = new LatLng(latitud, longitud);

                        Intent i = new Intent(Perfil_Usuario.this, Ubicacion_Perfil_User.class);

                        Bundle bundle1 = new Bundle();
                        bundle1.putParcelable("to_position_v2", toPosition); //este dice que sirve
                        i.putExtra("bundle_domicilio_v2", bundle1);


                        Toast.makeText(Perfil_Usuario.this, ""+latitud+"  "+longitud, Toast.LENGTH_SHORT).show();
                        startActivity(i);

                        // startActivity(new Intent(Perfil_Usuario.this, Navegdor.class));


                        finish(); //con esto cada vez que termine se cierra y retorna al login


                    } else if (foto_de_perfilURI_enviar==null && fotorecuperada.equals(null)) {


                        Toast.makeText(Perfil_Usuario.this, "registro correctamente", Toast.LENGTH_LONG).show();
                        Usuario usuario = new Usuario();

                        usuario.setFotodePerfilURI(Constantes.URL_foto_por_defecto_usuario);
                        usuario.setUsuario_nombre(nombre_uso_de_firebase);
                        usuario.setTeleono_usuario(telefono_actual);
                        usuario.setProfesion(profesion);
                        usuario.setHabilidad_profesional(descripcion_usuario);
                        usuario.setKey_usuario(Usuario_DAO.getInstance().getKeyUsuario());
                        usuario.setKey_busqueda(hash);
                        usuario.setLatidu(latitud);
                        usuario.setLongitud(longitud);
                        usuario.setCargo(cargo);

                        usuario.setNotifi_uid(notifiuid);
                        guardarnombre();

                        Usuario_DAO.getInstance().actualizar_info_usuario_y_foto(FirebaseAuth.getInstance().getCurrentUser().getUid(), usuario);

                        LatLng toPosition = new LatLng(latitud, longitud);

                        Intent i = new Intent(Perfil_Usuario.this, Ubicacion_Perfil_User.class);

                        Bundle bundle1 = new Bundle();
                        bundle1.putParcelable("to_position_v2", toPosition); //este dice que sirve
                        i.putExtra("bundle_domicilio_v2", bundle1);
                        Toast.makeText(Perfil_Usuario.this, ""+latitud+"  "+longitud, Toast.LENGTH_SHORT).show();


                        startActivity(i);

                        // startActivity(new Intent(Perfil_Usuario.this, Navegdor.class));

 finish(); //con esto cada vez que termine se cierra y retorna al login
                    }


                }


            }


        });
    }



    private void startLocationUpdates() {

        // Cree la solicitud de ubicación para comenzar a recibir actualizaciones
        mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(update_interval);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);

        // Cree el objeto LocationSettingsRequest utilizando la solicitud de ubicación
        LocationSettingsRequest.Builder constructor = new LocationSettingsRequest.Builder();
        constructor.addLocationRequest(mLocationRequest);
        LocationSettingsRequest locationSettingsRequest = constructor.build();


        // Verifique si la configuración de ubicación se cumple
        // https://developers.google.com/android/reference/com/google/android/gms/location/SettingsClient
        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);

        // el nuevo SDK v11 de la API de Google usa getFusedLocationProviderClient (this)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getFusedLocationProviderClient(this).requestLocationUpdates(mLocationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        // trabaja aquí
                        // onLocationChanged (locationResult . getLastLocation ());
                    }
                },
                Looper.myLooper());
    }
    private void obtenerubicacion() {
        // fusedLocationProviderClient= LocationServices.getFusedLocationProviderClient(getContext());

        //aqui creamos la condicional para que pida el permiso si la aplicacion puede usar geolocalizacion en este caso pide el permiso al usuario con un dialogo
        //basicamente pide acceso a localizacion
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){


            //aqui pedimos el permiso sobre qeu tipo de permiso en este caso fine location puede ser camera u otro
            ActivityCompat.requestPermissions(Perfil_Usuario.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);

            return;

        }

        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            //aqui obtubo latitud y longitud sin usar google maps
                            Log.e("Latitud: ",+location.getLatitude()+"Longitud: "+location.getLongitude()); //ejemplo calro para obtener los datos en timepo real


                            //guardo en shared latitud y longitud
                            SharedPreferences myPreferences_lat_long
                                    = PreferenceManager.getDefaultSharedPreferences(Perfil_Usuario.this);
                            SharedPreferences.Editor myEditor = myPreferences_lat_long.edit();


                           // String lat= String.valueOf(location.getLatitude());
                            //String llot= String.valueOf(location.getLatitude());
                            //myEditor.putString("latitud_string",lat);
                            //myEditor.putString("longitud_string",llot);

                            myEditor.putLong("Latitude_1", Double.doubleToLongBits(location.getLatitude()));
                            myEditor.putLong("longitude_1", Double.doubleToLongBits(location.getLongitude()));

                            //myEditor.putLong("lat_shared_busqueda", (long) location.getLatitude());
                            //myEditor.putLong("lot_shared_busqueda", (long) location.getLongitude());
                            Map_location map_location = new Map_location();
                            map_location.setLatitud(latitud);
                            map_location.setLongitud(longitud);
                            GeoHash geoHash = GeoHash.fromLocation(map_location, 6);
                            myEditor.putString("geohash",geoHash.toString().trim());

                            myEditor.commit();
                            latitud=location.getLatitude();
                            longitud=location.getLongitude();


                        }
                    }
                });

    }
    private  void guardarnombre(){
        //guardo en shared latitud y longitud
        SharedPreferences myPreferences_lat_long
                = PreferenceManager.getDefaultSharedPreferences(Perfil_Usuario.this);
        SharedPreferences.Editor myEditor = myPreferences_lat_long.edit();
        myEditor.putString("nombrefinal",nombre_uso_de_firebase);
      //  myEditor.putString("fotofinal_URI",foto_perfil_string_URI_enviada);


        myEditor.commit();

    }

    public void chooseImage() { //selecciona una imagen del circleview para l fotod d e perfil
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //  Bitmap bib=(Bitmap)data.getExtras().get("datacamera");
        //foto_de_perfil.setImageBitmap(bib);


        //comprovamos si se selecciono una foto de la galeria para el perfil
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK ) {

            //imagepicked:submit(data);

            Uri uri = data.getData();
            foto_de_perfilURI_enviar=uri;//uri
            FirebaseStorage storage_foto_cliente= FirebaseStorage.getInstance();
            StorageReference storage_Reference_cliente=storage_foto_cliente.getReference("fotos_perfil_USuario").child(Usuario_DAO.getInstance().getKeyUsuario()); //nombre de la carpeta en firebase que almacenara todas las imagenes

            final StorageReference foto_referencia=storage_Reference_cliente.child(uri.getLastPathSegment()); //esste obtiene la llave de nuestra foto en este caso U para que todas las fotos sean diferentes a las demas

            foto_referencia.putFile(uri).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if(!task.isSuccessful()){
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                            throw Objects.requireNonNull(task.getException());//atrapador de excepciones

                        }
                    }
                    return foto_referencia.getDownloadUrl();//obtene la url d ela foto que sube actilmentee
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() { //addonclick listener
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()){

                        Uri downloadUrl = task.getResult(); //reconoce el ury

                        foto_perfil_string_URI_enviada=downloadUrl.toString();

                    }
                }
            });


            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                // Log.d(TAG, String.valueOf(bitmap));


                foto_usuario_perfil.setImageBitmap(bitmap);
                //ImageView imageView = findViewById(R.id.imageView2);
                //  imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
            //validar si seleccionamos una foto de la galeria , nota podemos ahcerlo como en el viedeo o usando un archivo aparte

        }
    }

    public void cargarinfo_usu(){
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // enviar.setEnabled(true); //esto dice que antes de reclamar los datos el boton debe estar inabilitado
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference(Constantes.Nodo_Usuario + "/" + currentUser.getUid());

            //  DatabaseReference reference=database.getReference("Usuarios/"+currentUser.getUid()); //se concadena con el UID de firebase que es un codigo largo de id
            //con el anterior referencia podemos reclamar el nombre y el correo de firebase de el path usuarios
            FirebaseStorage storage_usu_foto = FirebaseStorage.getInstance();
            //StorageReference storageReference2=storage_usu_foto.getReference("Foto_Ususarios").child(Usuario_DAO.getInstance().getKeyUsuario());
            StorageReference storageReference3 = storage_usu_foto.getReference("fotos_perfil_USuario").child(Usuario_DAO.getInstance().getKeyUsuario());


            reference.addListenerForSingleValueEvent(new ValueEventListener() {


                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) { //datasnappshop es el qeu recupera los datos


                    //String value = dataSnapshot.getValue(String.class);
                    Usuario usu = dataSnapshot.getValue(Usuario.class);//pone la referencia

                    if (usu != null) {
                        String usu2 = usu.getUsuario_nombre();
                        String foto_ussss = usu.getFotodePerfilURI();
                        String profesion = usu.getProfesion();


                        nombre_uso_de_firebase = usu.getUsuario_nombre();

                        final String foto_perfil_URI2 = usu.getFotodePerfilURI();
                        if (usu.getFotodePerfilURI() != null) {
                            Glide.with(Perfil_Usuario.this).load(usu.getFotodePerfilURI()).into(foto_usuario_perfil);
                            fotorecuperada = foto_ussss;
                        }

                        if (usu.getUsuario_nombre()!=null){

                            nombre_uso_de_firebase = usu.getUsuario_nombre().trim(); //string
                            nombreusuario_edittex.setText(nombre_uso_de_firebase);
                        }else {
                            nombreusuario_edittex.setText("");
                        }
                        if (usu.getTeleono_usuario()!=null){
                        telefono_firebase = usu.getTeleono_usuario().trim();
                        telefono_usuario.setText(telefono_firebase);
                        }else {
                            telefono_usuario.setText("");
                        }
                        if (usu.getHabilidad_profesional()!=null){

                            descripcion_firebase = usu.getHabilidad_profesional();
                            descipcion_trabajo.setText(descripcion_firebase);

                        }else {
                            descipcion_trabajo.setText("");
                        }



                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        } else {
            //returnLogin();
        }


    }






    public boolean valida_telefono(String telefono){
        return  !telefono.isEmpty();
    }
    public boolean valida_descripcion_usuario(String descripcion_usaurio){
        return  !descripcion_usaurio.isEmpty();
    }
}

