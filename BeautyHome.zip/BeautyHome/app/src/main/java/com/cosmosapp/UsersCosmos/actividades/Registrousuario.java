package com.cosmosapp.UsersCosmos.actividades;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.cosmosapp.R;
import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Usuario;
import com.cosmosapp.UsersCosmos.Navegador.Navegdor;
import com.cosmosapp.UsersCosmos.persistencias_firebase.Usuario_DAO;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registrousuario extends AppCompatActivity {
    private EditText crear_correo2;
    private EditText crerar_contrasena2, contrasena2,nombreusuario;

    private Button registrar12, atras_crear_cuetna;

    private FirebaseAuth firebaseAuth;
    private DatabaseReference reference,referenceUsuario;
    private FirebaseDatabase database;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrousuario);
        crear_correo2 = (EditText) findViewById(R.id.correo_usuario2);
        crerar_contrasena2 = (EditText) findViewById(R.id.contraasena2);
        contrasena2 = (EditText) findViewById(R.id.contraasena_repite2);
        nombreusuario = (EditText) findViewById(R.id.nombre_usuario2);
        registrar12 = (Button) findViewById(R.id.guardar_cuenta_nueva2);
        database= FirebaseDatabase.getInstance();
        firebaseAuth= FirebaseAuth.getInstance();
        referenceUsuario=database.getReference(Constantes.Nodo_Usuario) ;//nodo principal donde almacena los usuarios


        progressDialog=new ProgressDialog(this);//barra de progreso

        registrar12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String correo = crear_correo2.getText().toString().trim();
                final String nombre=nombreusuario.getText().toString().trim();
                final String answ_1 = contrasena2.getText().toString().trim();

                if (TextUtils.isEmpty(correo)) {

                    Toast.makeText(Registrousuario.this, "ingresar correo", Toast.LENGTH_LONG).show();

                }

                if (TextUtils.isEmpty(answ_1)) {

                    Toast.makeText(Registrousuario.this, "ingresar contraseña", Toast.LENGTH_LONG).show();

                }


                if (isValidEmail(correo) && validar_contrasena()&& valida_nombre(nombre)) {

                    //aqui debemos ubicar el acepto terminos y condiciones
                    //View checkBoxView = View.inflate(Registrousuario.this, R.layout.item_terminos_y_condiciones, null);

                    AlertDialog.Builder builder_categorias = new AlertDialog.Builder(view.getContext());

                    LayoutInflater inflater=LayoutInflater.from(view.getContext());//inflador de vista
                    View dialogView = (View) inflater.inflate(R.layout.item_terminos_y_condiciones, null); //la vista inflada


                    builder_categorias.setView(dialogView);
                    //terminos,chechbox,boton
                    TextView texto_terminosycondiciones=(TextView)dialogView.findViewById(R.id.texto_terminos_y_conidiciones);
                    CheckBox checkBox=(CheckBox)dialogView.findViewById(R.id.checkbox_terminos);
                    Button bton_Aceptarterminos=(Button)dialogView.findViewById(R.id.aceptar_terminos);
                    texto_terminosycondiciones.setText(Constantes.terminosycondicion);
                    boolean aceptar_terminos=false;

                    bton_Aceptarterminos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (checkBox.isChecked()){//si no esta chechbox on

                                progressDialog.setMessage("realizando registro en linea... ");
                                progressDialog.show();

                                final String contrasena = crerar_contrasena2.getText().toString().trim();


                                firebaseAuth.createUserWithEmailAndPassword(correo, contrasena) //autentica correo y contrasena
                                        .addOnCompleteListener(Registrousuario.this, new OnCompleteListener<AuthResult>() {
                                            @Override
                                            public void onComplete(@NonNull Task<AuthResult> task) {




                                                ProgressDialog progressDialog=new ProgressDialog(Registrousuario.this);
                                                progressDialog.setMessage("cargando...");
                                                progressDialog.show();



                                                if (task.isSuccessful()){

                                                    Usuario_DAO.getInstance();
                                                    Usuario usuario2=new Usuario();
                                                    usuario2.setCorreo_usuario(correo);
                                                    usuario2.setUsuario_nombre(nombre);

                                                    FirebaseUser currentUser2 = firebaseAuth.getCurrentUser();

                                                    DatabaseReference referenceusu2=database.getReference(Constantes.Nodo_Usuario+"/"+currentUser2.getUid()); //se concadena con el UID de firebase que es un codigo largo de id


                                                    referenceusu2.setValue(usuario2).addOnCompleteListener(new OnCompleteListener<Void>() { //para enviar la informacion probamos con la clase hashmap
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {

                                                            if (task.isSuccessful()){

                                                                startActivity(new Intent(Registrousuario.this, Navegdor.class));
                                                                finish(); //con esto cada vez que termine se cierra y retorna al login


                                                            }
                                                            startActivity(new Intent(Registrousuario.this, Perfil_Usuario.class));
                                                            finish(); //con esto cada vez que termine se cierra y retorna al login

                                                        }
                                                    });



                                                }else {
                                                    progressDialog.dismiss();
                                                    Toast.makeText(Registrousuario.this, "error al registrarse", Toast.LENGTH_SHORT).show();


                                                }


                                            }
                                        });
                                Toast.makeText(Registrousuario.this, "Terminos Acemptados", Toast.LENGTH_SHORT).show();


                            }

                            else{
                                Toast.makeText(Registrousuario.this, "Debes Aceptar los terminos para registrarte", Toast.LENGTH_SHORT).show();
                            }


                        }
                    });



                    builder_categorias.create();
                    builder_categorias.show();





                }else {
                    Toast.makeText(Registrousuario.this, "Comletar campos", Toast.LENGTH_SHORT).show();
                }



            }

        });
    }

    private boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
    public boolean valida_nombre(String nombre){
        return  !nombre.isEmpty();
    }

    public Boolean validar_contrasena() {

        String contra1, contrarepiteee1;
        contra1 = crerar_contrasena2.getText().toString();
        contrarepiteee1 = contrasena2.getText().toString();
        if (contra1.equals(contrarepiteee1) && (contra1.length() >= 6 && contra1.length() <= 16)) {
            return  true;

        }else {return false;}


    }
}
