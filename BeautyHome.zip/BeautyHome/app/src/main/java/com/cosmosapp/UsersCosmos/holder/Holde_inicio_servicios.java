package com.cosmosapp.UsersCosmos.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cosmosapp.R;

public class Holde_inicio_servicios extends RecyclerView.ViewHolder  {

    ImageView fotocatefgoria;
    TextView categoria_titulo;
    TextView preciodesde;

    ImageView men1,men2,men3;
    ImageView mas1,mas2,mas3;
    TextView count1,count2,count3;


    public Holde_inicio_servicios(@NonNull View itemView) {
        super(itemView);

        fotocatefgoria=itemView.findViewById(R.id.foto_serv);
        categoria_titulo=itemView.findViewById(R.id.categoria_serv);
        preciodesde=itemView.findViewById(R.id.precios_Serv);
        men1=itemView.findViewById(R.id.dism1);
        men2=itemView.findViewById(R.id.dism2);
        men3=itemView.findViewById(R.id.dism3);

        mas1=itemView.findViewById(R.id.more1);
        mas2=itemView.findViewById(R.id.more2);
        mas3=itemView.findViewById(R.id.more3);
        count1=itemView.findViewById(R.id.texm1);
        count2=itemView.findViewById(R.id.texm2);
        count3=itemView.findViewById(R.id.texm3);
    }

    public ImageView getFotocatefgoria() {
        return fotocatefgoria;
    }

    public void setFotocatefgoria(ImageView fotocatefgoria) {
        this.fotocatefgoria = fotocatefgoria;
    }

    public TextView getCategoria_titulo() {
        return categoria_titulo;
    }

    public void setCategoria_titulo(TextView categoria_titulo) {
        this.categoria_titulo = categoria_titulo;
    }

    public TextView getPreciodesde() {
        return preciodesde;
    }

    public void setPreciodesde(TextView preciodesde) {
        this.preciodesde = preciodesde;
    }

    public ImageView getMen1() {
        return men1;
    }

    public void setMen1(ImageView men1) {
        this.men1 = men1;
    }

    public ImageView getMen2() {
        return men2;
    }

    public void setMen2(ImageView men2) {
        this.men2 = men2;
    }

    public ImageView getMen3() {
        return men3;
    }

    public void setMen3(ImageView men3) {
        this.men3 = men3;
    }

    public ImageView getMas1() {
        return mas1;
    }

    public void setMas1(ImageView mas1) {
        this.mas1 = mas1;
    }

    public ImageView getMas2() {
        return mas2;
    }

    public void setMas2(ImageView mas2) {
        this.mas2 = mas2;
    }

    public ImageView getMas3() {
        return mas3;
    }

    public void setMas3(ImageView mas3) {
        this.mas3 = mas3;
    }

    public TextView getCount1() {
        return count1;
    }

    public void setCount1(TextView count1) {
        this.count1 = count1;
    }

    public TextView getCount2() {
        return count2;
    }

    public void setCount2(TextView count2) {
        this.count2 = count2;
    }

    public TextView getCount3() {
        return count3;
    }

    public void setCount3(TextView count3) {
        this.count3 = count3;
    }
}
