package com.cosmosapp.UsersCosmos.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cosmosapp.R;


public class Holder_Facetura_cliente_Model extends RecyclerView.ViewHolder {

    ImageView foto;


    ImageView eliminar;
    ImageView ver;
    ImageView contactar;
    ImageView vermaps;
    TextView fecha;


    public Holder_Facetura_cliente_Model(@NonNull View itemView) {
        super(itemView);

        foto=(ImageView)itemView.findViewById(R.id.foto_fac);


        ver=(ImageView)itemView.findViewById(R.id.ver_fac);
        contactar=(ImageView)itemView.findViewById(R.id.contactar_fac);
        vermaps=(ImageView)itemView.findViewById(R.id.mp_fac);
        eliminar=(ImageView)itemView.findViewById(R.id.eliminar_fac);
        fecha=(TextView)itemView.findViewById(R.id.irv_ffecha);
    }

    public ImageView getEliminar() {
        return eliminar;
    }

    public void setEliminar(ImageView eliminar) {
        this.eliminar = eliminar;
    }

    public ImageView getVer() {
        return ver;
    }

    public void setVer(ImageView ver) {
        this.ver = ver;
    }

    public ImageView getContactar() {
        return contactar;
    }

    public void setContactar(ImageView contactar) {
        this.contactar = contactar;
    }

    public ImageView getVermaps() {
        return vermaps;
    }

    public void setVermaps(ImageView vermaps) {
        this.vermaps = vermaps;
    }

    public TextView getFecha() {
        return fecha;
    }

    public void setFecha(TextView fecha) {
        this.fecha = fecha;
    }

    public ImageView getFoto() {
        return foto;
    }

    public void setFoto(ImageView foto) {
        this.foto = foto;
    }
}
