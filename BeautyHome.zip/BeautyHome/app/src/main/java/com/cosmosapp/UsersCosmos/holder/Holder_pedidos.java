package com.cosmosapp.UsersCosmos.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.cosmosapp.R;

import de.hdodenhof.circleimageview.CircleImageView;


public class Holder_pedidos extends RecyclerView.ViewHolder {
    TextView codigofactura;
    TextView info_user;
    TextView domicilio;
    TextView hora;
    CircleImageView fotousuario;
    TextView asignar_profesional;


    ImageView dom_recibido;
    ImageView dom_preparacion;
    ImageView dom_enviar;
    ImageView eliminar;
    TextView completar_serv;

    public Holder_pedidos(@NonNull View itemView) {
        super(itemView);
        fotousuario=(CircleImageView)itemView.findViewById(R.id.fotousuario_pedido);
        codigofactura=(TextView) itemView.findViewById(R.id.codigo_factura);
        eliminar=(ImageView)itemView.findViewById(R.id.eliminar_pedi_holder);
        asignar_profesional=(TextView)itemView.findViewById(R.id.asignar_profesional);
       // dom_recibido = (ImageView) itemView.findViewById(R.id.dom1);
        //dom_preparacion= (ImageView) itemView.findViewById(R.id.dom2);
        //dom_enviar= (ImageView) itemView.findViewById(R.id.dom3);
        info_user = (TextView) itemView.findViewById(R.id.verinforuserdomicilio);
        domicilio = (TextView) itemView.findViewById(R.id.revisarlistaproductosdomicilio);
        hora = (TextView) itemView.findViewById(R.id.hora_domiciilio);
        completar_serv=(TextView)itemView.findViewById(R.id.complete);

    }

    public TextView getCodigofactura() {
        return codigofactura;
    }

    public void setCodigofactura(TextView codigofactura) {
        this.codigofactura = codigofactura;
    }

    public TextView getInfo_user() {
        return info_user;
    }

    public void setInfo_user(TextView info_user) {
        this.info_user = info_user;
    }

    public TextView getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(TextView domicilio) {
        this.domicilio = domicilio;
    }

    public TextView getHora() {
        return hora;
    }

    public void setHora(TextView hora) {
        this.hora = hora;
    }

    public CircleImageView getFotousuario() {
        return fotousuario;
    }

    public void setFotousuario(CircleImageView fotousuario) {
        this.fotousuario = fotousuario;
    }

    public TextView getAsignar_profesional() {
        return asignar_profesional;
    }

    public void setAsignar_profesional(TextView asignar_profesional) {
        this.asignar_profesional = asignar_profesional;
    }

    public ImageView getDom_recibido() {
        return dom_recibido;
    }

    public void setDom_recibido(ImageView dom_recibido) {
        this.dom_recibido = dom_recibido;
    }

    public ImageView getDom_preparacion() {
        return dom_preparacion;
    }

    public void setDom_preparacion(ImageView dom_preparacion) {
        this.dom_preparacion = dom_preparacion;
    }

    public ImageView getDom_enviar() {
        return dom_enviar;
    }

    public void setDom_enviar(ImageView dom_enviar) {
        this.dom_enviar = dom_enviar;
    }

    public ImageView getEliminar() {
        return eliminar;
    }

    public void setEliminar(ImageView eliminar) {
        this.eliminar = eliminar;
    }

    public TextView getCompletar_serv() {
        return completar_serv;
    }

    public void setCompletar_serv(TextView completar_serv) {
        this.completar_serv = completar_serv;
    }
}