package com.cosmosapp.UsersCosmos.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.cosmosapp.R;

import de.hdodenhof.circleimageview.CircleImageView;


public class Holder_room_ventas extends RecyclerView.ViewHolder {
    CircleImageView foto_principal;
    ImageView foto_serv1;
    ImageView foto_serv2;
    TextView nombre;
    TextView precio;
    TextView caligficaion;
    TextView tex_serv1;
    TextView texserv_2;
    TextView tipo;


    public Holder_room_ventas(@NonNull View itemView) {
        super(itemView);

        foto_principal=(CircleImageView) itemView.findViewById(R.id.foto_room_venta_vr);
        foto_serv1=(ImageView)itemView.findViewById(R.id.img_serv1);
        foto_serv2=(ImageView)itemView.findViewById(R.id.image_ser2);
        nombre=(TextView)itemView.findViewById(R.id.irv_nombre);
        precio=(TextView)itemView.findViewById(R.id.irv_precio);
        caligficaion=(TextView)itemView.findViewById(R.id.irv_calificacion);
        tex_serv1=(TextView)itemView.findViewById(R.id.tx_servicio1);
        texserv_2=(TextView)itemView.findViewById(R.id.tx_serv_2);
        tipo=(TextView)itemView.findViewById(R.id.tipo);

    }

    public TextView getTipo() {
        return tipo;
    }

    public void setTipo(TextView tipo) {
        this.tipo = tipo;
    }

    public CircleImageView getFoto_principal() {
        return foto_principal;
    }

    public void setFoto_principal(CircleImageView foto_principal) {
        this.foto_principal = foto_principal;
    }

    public ImageView getFoto_serv1() {
        return foto_serv1;
    }

    public void setFoto_serv1(ImageView foto_serv1) {
        this.foto_serv1 = foto_serv1;
    }

    public ImageView getFoto_serv2() {
        return foto_serv2;
    }

    public void setFoto_serv2(ImageView foto_serv2) {
        this.foto_serv2 = foto_serv2;
    }

    public TextView getNombre() {
        return nombre;
    }

    public void setNombre(TextView nombre) {
        this.nombre = nombre;
    }

    public TextView getPrecio() {
        return precio;
    }

    public void setPrecio(TextView precio) {
        this.precio = precio;
    }

    public TextView getCaligficaion() {
        return caligficaion;
    }

    public void setCaligficaion(TextView caligficaion) {
        this.caligficaion = caligficaion;
    }

    public TextView getTex_serv1() {
        return tex_serv1;
    }

    public void setTex_serv1(TextView tex_serv1) {
        this.tex_serv1 = tex_serv1;
    }

    public TextView getTexserv_2() {
        return texserv_2;
    }

    public void setTexserv_2(TextView texserv_2) {
        this.texserv_2 = texserv_2;
    }
}
