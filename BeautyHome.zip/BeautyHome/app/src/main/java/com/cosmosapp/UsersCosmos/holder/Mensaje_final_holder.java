package com.cosmosapp.UsersCosmos.holder;

import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.cosmosapp.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Mensaje_final_holder extends RecyclerView.ViewHolder {
    private TextView nombre;
    private TextView mensaje_enviado;
    private TextView hora;
    private CircleImageView foto_perfil;
    private ImageView foto_enviada_en_mensaje;
    private Uri urifotos;



    public Mensaje_final_holder(View itemView1){

        super(itemView1);
        //como se llama al methodo padre debemos llamar al tipo de vista del objeto
        nombre=(TextView)itemView1.findViewById(R.id.nombre_mensaje_ultimo_recibido);
        mensaje_enviado=(TextView)itemView1.findViewById(R.id.mensajes_mensaje_ultimo);
        hora=(TextView)itemView1.findViewById(R.id.hora_mensaje_final);
        foto_perfil=(CircleImageView) itemView1.findViewById(R.id.foto_perfil_mensaje_ultimo_recibido);
     //   foto_enviada_en_mensaje=(ImageView)itemView.findViewById(R.id.mens);
    }



    public TextView getNombre() {
        return nombre;
    }

    public void setNombre(TextView nombre) {
        this.nombre = nombre;
    }

    public TextView getMensaje_enviado() {
        return mensaje_enviado;
    }

    public void setMensaje_enviado(TextView mensaje_enviado) {
        this.mensaje_enviado = mensaje_enviado;
    }

    public TextView getHora() {
        return hora;
    }

    public void setHora(TextView hora) {
        this.hora = hora;
    }

    public CircleImageView getFoto_perfil() {
        return foto_perfil;
    }

    public void setFoto_perfil(CircleImageView foto_perfil) {
        this.foto_perfil = foto_perfil;
    }

    public ImageView getFoto_enviada_en_mensaje() {
        return foto_enviada_en_mensaje;
    }

    public void setFoto_enviada_en_mensaje(ImageView foto_enviada_en_mensaje) {
        this.foto_enviada_en_mensaje = foto_enviada_en_mensaje;
    }

    public Uri getUrifotos() {
        return urifotos;
    }

    public void setUrifotos(Uri urifotos) {
        this.urifotos = urifotos;
    }
}
