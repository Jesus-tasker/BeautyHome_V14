package com.cosmosapp.UsersCosmos.holder;

import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.cosmosapp.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Usuarios_cercanos_holder   extends RecyclerView.ViewHolder{ //no olvidar la extencion
    private CircleImageView foto_perfil_item_usuario;
    private TextView nombre_cliente_item;
    private TextView telefono;
    private ImageView btn_mensajeria,btn_setings,btn_corazon;
    private Uri urifotos;


    public Usuarios_cercanos_holder(@NonNull View itemView) {
        super(itemView);
        foto_perfil_item_usuario=(CircleImageView) itemView.findViewById(R.id.foto_usuario_cercano_cv);
        nombre_cliente_item=(TextView)itemView.findViewById(R.id.nombre_usu_cercano);
        telefono=(TextView)itemView.findViewById(R.id.distancia_cercano_usuario);
        btn_mensajeria=(ImageView)itemView.findViewById(R.id.enviarmensaje_a_usuario_cercano);
        btn_setings=(ImageView)itemView.findViewById(R.id.identificar);
        btn_corazon=(ImageView)itemView.findViewById(R.id.corazon_users);

    }

    public ImageView getBtn_mensajeria() {
        return btn_mensajeria;
    }

    public void setBtn_mensajeria(ImageView btn_mensajeria) {
        this.btn_mensajeria = btn_mensajeria;
    }

    public ImageView getBtn_setings() {
        return btn_setings;
    }

    public void setBtn_setings(ImageView btn_setings) {
        this.btn_setings = btn_setings;
    }

    public CircleImageView getFoto_perfil_item_usuario() {
        return foto_perfil_item_usuario;
    }

    public void setFoto_perfil_item_usuario(CircleImageView foto_perfil_item_usuario) {
        this.foto_perfil_item_usuario = foto_perfil_item_usuario;
    }

    public TextView getNombre_cliente_item() {
        return nombre_cliente_item;
    }

    public void setNombre_cliente_item(TextView nombre_cliente_item) {
        this.nombre_cliente_item = nombre_cliente_item;
    }

    public TextView getTelefono() {
        return telefono;
    }

    public void setTelefono(TextView telefono) {
        this.telefono = telefono;
    }

    public Uri getUrifotos() {
        return urifotos;
    }

    public void setUrifotos(Uri urifotos) {
        this.urifotos = urifotos;
    }

    public ImageView getBtn_corazon() {
        return btn_corazon;
    }

    public void setBtn_corazon(ImageView btn_corazon) {
        this.btn_corazon = btn_corazon;
    }
}
