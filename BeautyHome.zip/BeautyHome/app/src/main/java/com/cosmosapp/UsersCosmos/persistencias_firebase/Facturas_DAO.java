package com.cosmosapp.UsersCosmos.persistencias_firebase;

import androidx.annotation.NonNull;


import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.Reserva_room;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Facturas_DAO {
    private static Facturas_DAO facedao;

    private FirebaseDatabase database,database_chatspersonales;
    private DatabaseReference databaseReference_mensajeria,miSchats;

    public static Facturas_DAO getInstance(){


        if(facedao==null) facedao= new Facturas_DAO();
        return facedao;
      /*  if (usuario_dao==null){ //si el usuario no ha creado su etancia

            usuario_dao=new Usuario_DAO();
            return usuario_dao;
        }

        return getInstance(); */
    }
    private Facturas_DAO(){ //inicia la estancia de firebase
        //chats
        database=FirebaseDatabase.getInstance();
        databaseReference_mensajeria=database.getReference(Constantes.Factura);

        //lista de chats personales
        database_chatspersonales=FirebaseDatabase.getInstance();
        miSchats=database_chatspersonales.getReference(Constantes.Factura);

    }

   public void crear_servicio (String key_cliente, String key_room, final Reserva_room reserva_room){


        final DatabaseReference referencia_guardarroom=databaseReference_mensajeria.child(key_cliente);
        referencia_guardarroom.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                referencia_guardarroom.push().setValue(reserva_room);//bbdd general
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        }); //mi bbdd

        DatabaseReference reference_roomstotales=databaseReference_mensajeria.child(key_room);
        reference_roomstotales.push().setValue(reserva_room);//bbdd general


    }



}
