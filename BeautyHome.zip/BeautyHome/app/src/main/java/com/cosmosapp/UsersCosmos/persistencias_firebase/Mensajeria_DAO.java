package com.cosmosapp.UsersCosmos.persistencias_firebase;



import com.cosmosapp.UsersCosmos.Constantes.Constantes;
import com.cosmosapp.UsersCosmos.Entidades_fire.MensajeChat;
import com.cosmosapp.UsersCosmos.Entidades_fire.Mnsaje_final;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Mensajeria_DAO {
    private static Mensajeria_DAO mensajeria_dao;

    private FirebaseDatabase database,database_chatspersonales;
    private DatabaseReference databaseReference_mensajeria,miSchats;
    private FirebaseStorage storage; //usado para enviar imagenes
    private StorageReference storageReference; //usado para enviar imagenes
    public static Mensajeria_DAO getInstance(){


        if(mensajeria_dao==null) mensajeria_dao= new Mensajeria_DAO();
        return mensajeria_dao;
      /*  if (usuario_dao==null){ //si el usuario no ha creado su etancia

            usuario_dao=new Usuario_DAO();
            return usuario_dao;
        }

        return getInstance(); */
    }
    private Mensajeria_DAO(){ //inicia la estancia de firebase
        //chats
        database=FirebaseDatabase.getInstance();
        databaseReference_mensajeria=database.getReference(Constantes.Mensajes);

        //lista de chats personales
        database_chatspersonales=FirebaseDatabase.getInstance();
        miSchats=database_chatspersonales.getReference(Constantes.Myschats);


        // storage_fotos_de_Oerfuk= FirebaseStorage.getInstance();
        //reference_perfil_foto=storage_fotos_de_Oerfuk.getReference("Fotos/foto_perdiles"+getKeyUsuario()); //aqui crea la carpeta con el id del ussuario correspondiente y almacena una ubicacion para las fotos
        //referenceUsuariosss=database_f.getReference(Constantes.Nodo_Usuario);//el nodo esta en constantedes java alli puse el codigo


    }
    //mensajeria
    //usuario1
    //usuario2
    //usuario2
    //usuario1


    //el siguiente envia el mensaje a ambos emisor y recetro
    public void  nuevomensaje(String key_emisor, String key_receptor, MensajeChat mensaje){

        DatabaseReference referenceEmisore=databaseReference_mensajeria.child(key_emisor).child(key_receptor);
        DatabaseReference referenceReceptor=databaseReference_mensajeria.child(key_receptor).child(key_emisor);
        referenceEmisore.push().setValue(mensaje);
        referenceReceptor.push().setValue(mensaje);

    }
    public void  myschats(String key_emisor, String key_receptor, Mnsaje_final mensaje){



        DatabaseReference referenceEmisore2=miSchats.child(key_emisor).child(key_receptor);
        DatabaseReference referenceReceptor2=miSchats.child(key_receptor).child(key_emisor);
        referenceEmisore2.setValue(mensaje);
        referenceReceptor2.setValue(mensaje);

    }





}
